// na_exam1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "LMatrixTD.h"

typedef double FTYPE;

int _tmain(int argc, _TCHAR* argv[])
{
	int input;

	std::cout << "Use negative lower part (0 for positive, 1 for negative): ";
	std::cin >> input;

	bool negativeLower = (input != 0);

	int i;
	for (i=0; i<2.0/0.01; i++)
	{
		FTYPE beta = (i+1)*0.01;

		if (beta != 1)
		{
			NA::LMatrixTD<FTYPE> matrix(10, beta, negativeLower);

			std::cout << beta << " " << 1/matrix.Cond() << std::endl;
		}
	}

	std::cout << std::endl;

	for (i=5; i<=20; i++)
	{
		NA::LMatrixTD<FTYPE> matrix(i, 1.2, negativeLower);

		std::cout << i << " " << 1/matrix.Cond() << std::endl;
	}

	return 0;
}

