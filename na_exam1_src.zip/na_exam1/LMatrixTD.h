//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LMatrixTD
//
//	Calculates the LU-factorization and condition number in O(n) time
//	for tridiagonal matrices whose elements are a_{(i,i+1)} = beta
//	and a_{(i,i-1)} = alpha, with alpha=beta or -beta.
//
//....................................................................................................................................................................................

#pragma once

#include <cmath>
#include <assert.h>

namespace NA
{

//....................................................................................................................................................................................
template <class T>
class	LMatrixTD
{
public:
	LMatrixTD									(int n, T beta, bool negativeLower) :
		kBeta(beta),
		kNegativeLower(negativeLower),
		kAlpha( (negativeLower) ? (-beta) : (beta) ),
		kN(n)
	{
		assert(n>0);
		assert(beta != 1);

		mL = new T[n-1]; assert(mL);
		mD = new T[n]; assert(mD);

		mInvDiagonal = new T[n]; assert(mInvDiagonal);
		mRowSumAbs = new T[n]; assert(mRowSumAbs);
	}

	~LMatrixTD									()
	{
		delete [] mL;
		delete [] mD;

		delete [] mInvDiagonal;
		delete [] mRowSumAbs;
	}

	// Return the condition number (using infinity norm).
	T					Cond					() { return Norm() * InverseNorm(); }

	// Return the norm of the tridiagonal matrix.
	T					Norm					() { return 2*std::fabs(kBeta) + 1; }

	// Return the norm of the inverse of the tridiagonal matrix.
	T					InverseNorm				()
	{
		// First compute the LU-factorization.
		LU();

		// Then compute the inverse's diagonal.
		InverseDiagonal();

		int i;

		mRowSumAbs[kN-1] = std::fabs(mInvDiagonal[kN-1]);

		// Calculate the row sums from the diagonal and elements to the right.
		for (i=kN-2; i>=0; i--)
		{
			mRowSumAbs[i] = std::fabs(mInvDiagonal[i]) + mRowSumAbs[i+1] * std::fabs(kBeta / mD[i]);
		}

		T max = mRowSumAbs[0];

		for (i=1; i<std::ceil((double)kN/2); i++)
		{
			// Note the index-change because C++ indexes from 0 to n-1
			int otherIndex = kN-i-1;
			T totalRowSum = mRowSumAbs[i] + mRowSumAbs[otherIndex] - std::fabs(mInvDiagonal[i]);

			if (totalRowSum>max)
				max = totalRowSum;
		}

		return max;
	}

protected:
	// Compute the LU-factorization
	void				LU						()
	{
		mL[0] = kAlpha;
		mD[0] = 1;

		for (int i=1; i<kN-1; i++)
		{
			mD[i] = 1 - mL[i-1] * kBeta;
			mL[i] = kAlpha / mD[i];
		}

		mD[kN-1] = 1 - mL[kN-2] * kBeta;
	}

	// Compute the diagonal of the inverse.
	void				InverseDiagonal			()
	{
		// Create the diagonal
		mInvDiagonal[kN-1] = 1/mD[kN-1];

		for (int i=kN-2; i>=0; i--)
		{
			mInvDiagonal[i] = (1 + kBeta * mL[i] * mInvDiagonal[i+1]) / mD[i];
		}
	}

protected:
	const T			kBeta;				// Value of upper-diagonal elements.
	const T			kAlpha;				// Value of lower-diagonal elements.
	const int		kN;					// Dimensionality of the matrix.
	const bool		kNegativeLower;		// Whether kAlpha = -kBeta or kBeta.

	T				*mL;				// l-vector
	T				*mD;				// d-vector
	T				*mInvDiagonal;		// The diagonal of the inverse matrix.
	T				*mRowSumAbs;		// The temporary row-sums.
};
} //end namespace BioInf
