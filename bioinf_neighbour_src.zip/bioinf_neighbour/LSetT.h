//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LSetT
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

#include "LNodeT.h"
#include "LLeafT.h"
#include <vector>
#include <string>

namespace BioInf
{

//....................................................................................................................................................................................
class	LSetT
{
public:
	LSetT										(int numLeafs);
	virtual ~LSetT								();

	// Add a leaf to the set.
	void				AddLeaf					(std::string name);

	// Connect nodes with id's i and j with the given distance.
	void				AddLastEdge				(int i, int j, double dist);

	// Add a new node and connect it to nodes i and j with respective distances.
	void				AddNode					(int i, double distI, int j, double distJ);

	// Return the tree as a string.
	std::string			ToString				();

private:
	typedef std::vector<LNodeT*>		TSet;
	typedef TSet::iterator				TSetItor;

	TSet				mNodes;							// The nodes of the tree.
	LNodeT				*mRoot;							// The root for string-representation.
};
} //end namespace BioInf
