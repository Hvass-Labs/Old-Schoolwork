//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LSetT
//
//__________________________________________________________________________________________

#include "LSetT.h"
#include <assert.h>

namespace BioInf
{

//__________________________________________________________________________________________
LSetT::LSetT					(int numLeafs) :
mRoot(0)
{
	mNodes.reserve(numLeafs*2-2);
}
//__________________________________________________________________________________________
LSetT::~LSetT					()
{
}
//__________________________________________________________________________________________
void
LSetT::AddLeaf					(std::string name)
{
	mNodes.push_back(new LLeafT(name));
}
//__________________________________________________________________________________________
void
LSetT::AddLastEdge				(int i, int j, double dist)
{
	assert(i>=0 && i<mNodes.size());
	assert(j>=0 && j<mNodes.size());

	mNodes[i]->Connect(mNodes[j], dist);
	mNodes[j]->Connect(mNodes[i], dist);
}
//__________________________________________________________________________________________
void
LSetT::AddNode					(int i, double distI, int j, double distJ)
{
	assert(i>=0 && i<mNodes.size());
	assert(j>=0 && j<mNodes.size());

	// Create new node.
	LNodeT *node = new LNodeT();
	LNodeT *nodeI = mNodes[i];
	LNodeT *nodeJ = mNodes[j];

	// Add new node to the set.
	mNodes.push_back(node);

	// Connect new node to nodes i and j with respective distances.
	node->Connect(nodeI, distI);
	node->Connect(nodeJ, distJ);

	// Connect nodes i and j to new node.
	nodeI->Connect(node, distI);
	nodeJ->Connect(node, distJ);

	mRoot = node;
}
//__________________________________________________________________________________________
std::string
LSetT::ToString					()
{
	assert(mRoot);
	return mRoot->ToString(0);
}
//__________________________________________________________________________________________
} //end namespace BioInf
