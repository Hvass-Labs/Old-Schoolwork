//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LScoreMatrix
//
//	### What's it used for?
//	hash_map might be faster than map
//
//....................................................................................................................................................................................

#pragma once

#include "DoubleArray.h"
#include <limits>
#include <fstream>
#include <string>
#include <map>
#include <assert.h>

namespace BioInf
{

//....................................................................................................................................................................................
template <class TName, class TScore>
class	LScoreMatrix
{
public:
	LScoreMatrix								();
	virtual ~LScoreMatrix						();

	TScore				Score					(TName a, TName b) { return GetScore(GetIndex(a), GetIndex(b)); }

	// Return whether 'id' exists in the score-matrix.
	bool				IsValid					(TName id) { return mIndexMap.find(id) != mIndexMap.end(); }

	TName				GetDefaultId			() const { return mAlphabet[0]; }

	TName				GetCharacter			(int index) { assert(index>=0 && index<mAlphabetSize); return mAlphabet[index]; }

	void				ReadFromFile			(char *filename, bool symmetric);

	int					GetAlphabetSize			() { return mAlphabetSize; }

	// Return score 
	TScore				GetScore				(int aIndex, int bIndex) const;

protected:
	// Set the string a to be the index'th element of the 'alphabet'.
	void				SetIndex				(TName s, int index);

	void				SetScore				(int aIndex, int bIndex, TScore score);

private:
	int					GetIndex				(TName s) { assert(IsValid(s)); return mIndexMap[s]; }

	void				DoAllocate				();

	void				DoDelete				();

private:
	std::map<TName, TScore>			mIndexMap;
	TName							*mAlphabet;

	TScore		**mScores;

	int			mAlphabetSize;
};
//__________________________________________________________________________________________
template <class TName, class TScore>
LScoreMatrix<TName,TScore>::LScoreMatrix				() :
mAlphabetSize(0),
mScores(0),
mAlphabet(0)
{
}
//__________________________________________________________________________________________
template <class TName, class TScore>
LScoreMatrix<TName,TScore>::~LScoreMatrix								()
{
	DoDelete();
}
//__________________________________________________________________________________________
template <class TName, class TScore>
void
LScoreMatrix<TName,TScore>::DoAllocate					()
{
	try
	{
		assert(mAlphabetSize>0);

//		mIndexMap = new std::map<TName, TScore>();
		mAlphabet = new TName[mAlphabetSize];
		mScores = ArrayOps::AllocateDoubleArray<TScore>(mAlphabetSize, mAlphabetSize);
	}
	catch (...)
	{
		DoDelete();
		throw;
	}
}
//__________________________________________________________________________________________
template <class TName, class TScore>
void
LScoreMatrix<TName,TScore>::DoDelete					()
{
	ArrayOps::DeleteDoubleArray(mScores, mAlphabetSize); mScores = 0;
	delete [] mAlphabet; mAlphabet = 0;

	mAlphabetSize = 0;
}
//__________________________________________________________________________________________
template <class TName, class TScore>
void
LScoreMatrix<TName,TScore>::ReadFromFile				(char *filename, bool symmetric)
{
	assert(filename);
	int i, j;

	std::ifstream infile(filename); assert(infile);

	infile >> mAlphabetSize; infile.ignore(std::numeric_limits<int>::max(), '\n'); assert(mAlphabetSize>0);

	DoAllocate();

	for (i=0; i<mAlphabetSize; i++)
	{
		TName s;
		infile >> s;
		SetIndex(s, i);

		int upTo = (symmetric) ? (i+1) : (mAlphabetSize);
		for (j=0; j<upTo; j++)
		{
			TScore score;
			infile >> score;
			SetScore(i, j, score);
		}

		infile.ignore(std::numeric_limits<int>::max(), '\n');
	}

	// Duplicate scores to upper triangle, if matrix is symmetric.
	if (symmetric)
	{
		for (i=0; i<mAlphabetSize; i++)
		{
			for (j=i+1; j<mAlphabetSize; j++)
			{
				SetScore(i, j, GetScore(j, i));
			}
		}
	}
}
//__________________________________________________________________________________________
template <class TName, class TScore>
void
LScoreMatrix<TName,TScore>::SetIndex					(TName s, int index)
{
	assert(index>=0 && index<mAlphabetSize);	// Check that the index is valid.
	assert(!IsValid(s));						// Check that the index isn't used.

	mIndexMap[s] = index;
	mAlphabet[index] = s;
}
//__________________________________________________________________________________________
template <class TName, class TScore>
void
LScoreMatrix<TName,TScore>::SetScore					(int aIndex, int bIndex, TScore score)
{
	assert(aIndex>= 0 && aIndex<mAlphabetSize);
	assert(bIndex>= 0 && bIndex<mAlphabetSize);

	mScores[aIndex][bIndex] = score;
}
//__________________________________________________________________________________________
template <class TName, class TScore>
TScore
LScoreMatrix<TName,TScore>::GetScore					(int aIndex, int bIndex) const
{
	assert(aIndex>= 0 && aIndex<mAlphabetSize);
	assert(bIndex>= 0 && bIndex<mAlphabetSize);

	return mScores[aIndex][bIndex];
}
//__________________________________________________________________________________________
} //end namespace BioInf
