//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LSetL
//
//__________________________________________________________________________________________

#include "LSetL.h"
#include "LNodeL.h"
#include <assert.h>
#include <limits>

namespace BioInf
{

//__________________________________________________________________________________________
LSetL::LSetL					(LSetT &setT, int numLeafs) :
mSetT(setT),
mNumActiveNodes(numLeafs),
mNumNodes(numLeafs),
mNodeId(numLeafs)
{
	DoAllocate();
}
//__________________________________________________________________________________________
LSetL::~LSetL					()
{
	DoDelete();
}
//__________________________________________________________________________________________
void
LSetL::DoAllocate				()
{
	try
	{
		mIdMap.reserve(mNumNodes);
		mDistanceSum.reserve(mNumNodes);

		mDistance = new double*[mNumNodes-1];

		int i;
		for (i=0; i<mNumNodes-1; i++)
		{
			mDistance[i] = 0;
		}

		for (i=0; i<mNumNodes-1; i++)
		{
			mDistance[i] = new double[i+1];
		}

		for (i=0; i<mNumNodes; i++)
		{
			mIdMap[i] = i;
		}
	}
	catch (...)
	{
		DoDelete();
		throw;
	}
}
//__________________________________________________________________________________________
void
LSetL::DoDelete				()
{
	if (mDistance)
	{
		for (int i=0; i<mNumNodes-1; i++)
		{
			delete [] mDistance[i]; mDistance[i] = 0;
		}
	}

	delete [] mDistance; mDistance = 0;
}
//__________________________________________________________________________________________
void
LSetL::SetDistance				(int indexI, int indexJ, double distance)
{
	assert(indexI>=1 && indexI<mNumNodes);
	assert(indexJ>=0 && indexJ<mNumNodes);
	assert(indexI>indexJ);

	mDistance[indexI-1][indexJ] = distance;
}
//__________________________________________________________________________________________
void
LSetL::SetDistanceSafe			(int indexI, int indexJ, double distance)
{
	if (indexI<indexJ)
		std::swap(indexI, indexJ);

	SetDistance(indexI, indexJ, distance);
}
//__________________________________________________________________________________________
double
LSetL::GetDistance				(int indexI, int indexJ)
{
	assert(indexI>=1 && indexI<mNumNodes);
	assert(indexJ>=0 && indexJ<mNumNodes);
	assert(indexI>indexJ);

	return mDistance[indexI-1][indexJ];
}
//__________________________________________________________________________________________
double
LSetL::GetDistanceSafe			(int indexI, int indexJ)
{
	if (indexI<indexJ)
		std::swap(indexI, indexJ);

	return GetDistance(indexI, indexJ);
}
//__________________________________________________________________________________________
void
LSetL::CreateNewId				(int index)
{
	int id = mNodeId++;
	mIdMap[index] = id;
}
//__________________________________________________________________________________________
void
LSetL::RemoveNode				(int index)
{
	assert(index>=0 && index<mNumNodes);

	int i;
	for (i=0; i<index; i++)
	{
		if (mIdMap[i] != -1)
		{
			mDistanceSum[i] -= GetDistance(index, i);
		}
	}

	for (i=index+1; i<mNumNodes; i++)
	{
		if (mIdMap[i] != -1)
		{
			mDistanceSum[i] -= GetDistance(i, index);
		}
	}

	mIdMap[index] = -1;

	mNumActiveNodes--;
}
//__________________________________________________________________________________________
void
LSetL::InitDistanceSum			()
{
	for (int i=0; i<mNumNodes; i++)
	{
		double sum = 0;

		int j;
		for (j=0; j<i; j++)
		{
			sum += GetDistanceSafe(i,j);
		}

		for (j=i+1; j<mNumNodes; j++)
		{
			sum += GetDistanceSafe(j,i);
		}

		mDistanceSum[i] = sum;
	}
}
//__________________________________________________________________________________________
void
LSetL::AddNode					(int indexI, int indexJ, double frac)
{
	assert(indexI>=0 && indexI<mNumNodes && mIdMap[indexI] != -1);
	assert(indexJ>=0 && indexJ<mNumNodes && mIdMap[indexJ] != -1);

	// Add new node k to the T-set.
	double distanceIJ = GetDistance(indexI, indexJ);
	double distanceIK = 0.5 * (distanceIJ + frac * (mDistanceSum[indexI] - mDistanceSum[indexJ]));
	double distanceJK = distanceIJ - distanceIK;
	int idI = mIdMap[indexI];
	int idJ = mIdMap[indexJ];
	mSetT.AddNode(idI, distanceIK, idJ, distanceJK);

	// Remove nodes i and j from L-set. Individual distances are kept.
	RemoveNode(indexI);
	RemoveNode(indexJ);

	// Create node k in i's place.
	int indexK = indexI;
	CreateNewId(indexK);
	mNumActiveNodes++;

	double distanceSum = 0;

	// Set distances from node k to all other nodes in L.
	for (int m=0; m<mNumNodes; m++)
	{
		if ((m != indexK) && (mIdMap[m] != -1))
		{
			double distance = 0.5 * (GetDistanceSafe(indexI, m) + GetDistanceSafe(indexJ, m) - distanceIJ);
			SetDistanceSafe(indexK, m, distance);

			// Accumulate the distance-sum for node k.
			distanceSum += distance;

			// Add distance to node m's distance-sum.
			mDistanceSum[m] += distance;
		}
	}

	// Set the distance sum for node k.
	mDistanceSum[indexK] = distanceSum;
}
//__________________________________________________________________________________________
void
LSetL::FindMinDistance			(int &indexI, int &indexJ, double frac)
{
	assert(mNumActiveNodes>=2);

	double minD = std::numeric_limits<double>::max();

	for (int i=0; i<mNumNodes; i++)
	{
		if (mIdMap[i] != -1)
		{
			int j;
			for (j=0; j<i; j++)
			{
				if (mIdMap[j] != -1)
				{
					double D = GetDistance(i, j) - frac * (mDistanceSum[i] + mDistanceSum[j]);

					if (D < minD)
					{
						indexI = i;
						indexJ = j;
						minD = D;
					}
				}
			}
		}
	}

	assert(indexI>indexJ);
}
//__________________________________________________________________________________________
void
LSetL::FindLastTwoNodes			(int &indexI, int &indexJ, int &idI, int &idJ)
{
	int i=0;

	do
	{
		assert(i<mNumNodes);
		idJ = mIdMap[i];
		i++;
	} while (idJ == -1);

	indexJ = i-1;

	do
	{
		assert(i<mNumNodes);
		idI = mIdMap[i];
		i++;
	} while (idI == -1);

	indexI = i-1;
}
//__________________________________________________________________________________________
void
LSetL::Process					()
{
	while (mNumActiveNodes>=2)
	{
		int indexI, indexJ;

		if (mNumActiveNodes > 2)
		{
			double frac = 1.0/(mNumActiveNodes-2);
			FindMinDistance(indexI, indexJ, frac);
			AddNode(indexI, indexJ, frac);
		}
		else // (mNumActiveNodes == 2), termination.
		{
			// Find the two remaining nodes.
			int idI, idJ;
			FindLastTwoNodes(indexI, indexJ, idI, idJ);
			double distanceIJ = GetDistance(indexI, indexJ);
			mSetT.AddLastEdge(idI, idJ, distanceIJ);
			break;
		}
	}
}
//__________________________________________________________________________________________
} //end namespace BioInf
