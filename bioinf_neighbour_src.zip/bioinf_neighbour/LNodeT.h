//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LNodeT
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

#include <sstream>
#include <utility>
#include <list>

namespace BioInf
{

//....................................................................................................................................................................................
class	LNodeT
{
public:
	LNodeT										();
	virtual ~LNodeT								();

	// Connect otherNode with the given distance.
	void				Connect					(LNodeT *otherNode, double distance);

	virtual std::string	ToString				(LNodeT *caller);

private:
	typedef std::list<std::pair<LNodeT*,double> >	TSet;
	typedef TSet::iterator							TSetItor;

	TSet				mConnections;
};
} //end namespace BioInf
