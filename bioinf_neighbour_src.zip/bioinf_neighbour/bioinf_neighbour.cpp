// bioinf_neighbour.cpp : Defines the entry point for the console application.
//

//#define TESTING

#include "stdafx.h"
#include "LScoreMatrix.h"
#include "LSetL.h"
#include "LSetT.h"
#include <sstream>
#include <ctime>

using namespace BioInf;

char	*gFilenameDistanceMatrix;

void GetParameters(int argc, _TCHAR* argv[])
{
#ifndef TESTING

	if (argc != 2)
	{
		std::cout << "bioinf_neighbour distance-matrix" << std::endl;
		exit(1);
	}
	else
	{
		gFilenameDistanceMatrix = argv[1];
	}

#else

	gFilenameDistanceMatrix = "Acyl_transf_2.phylip";

#endif
}

int _tmain(int argc, _TCHAR* argv[])
{
	std::cout << "Neighbour Joining - Magnus E. H. Pedersen, Algortihms in BioInformatics 2004.\n" << std::endl;
	GetParameters(argc, argv);

	// Read the distance matrix.
	LScoreMatrix<std::string,double> score;
	score.ReadFromFile(gFilenameDistanceMatrix, true);

	// Create sets.
	int numLeafs = score.GetAlphabetSize();
	LSetT setT(numLeafs);
	LSetL setL(setT, numLeafs);

	// Add nodes from the distance-matrix to the T-set.
	int i;
	for (i=0; i<numLeafs; i++)
	{
		setT.AddLeaf(score.GetCharacter(i));
	}

	// Add nodes from the distance-matrix to the L-set.
	for (i=1; i<numLeafs; i++)
	{
		for (int j=0; j<i; j++)
		{
			setL.SetDistance(i, j, score.GetScore(i, j));
		}
	}

	// Initialize the L-set once nodes have been added.
	setL.InitDistanceSum();

	std::clock_t beginTime, endTime;
	beginTime = std::clock();

	// Compute the neighbour joining tree.
	setL.Process();

	endTime = std::clock();

	// Display various output, incl. tree in Newick format.
	std::cout << setT.ToString() << ";\n" << std::endl;
	std::cout << "Number of nodes: " << score.GetAlphabetSize() << ", computed in " << endTime-beginTime << " msecs." << std::endl;

	return 0;
}
