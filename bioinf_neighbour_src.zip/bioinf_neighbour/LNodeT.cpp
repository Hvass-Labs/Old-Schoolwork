//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LNodeT
//
//__________________________________________________________________________________________

#include "LNodeT.h"

namespace BioInf
{

//__________________________________________________________________________________________
LNodeT::LNodeT			()
{
}
//__________________________________________________________________________________________
LNodeT::~LNodeT			()
{
}
//__________________________________________________________________________________________
void
LNodeT::Connect					(LNodeT *otherNode, double distance)
{
	mConnections.push_back(std::pair<LNodeT*,double>(otherNode, distance));
}
//__________________________________________________________________________________________
std::string
LNodeT::ToString				(LNodeT *caller)
{
	std::ostringstream ost;

	ost << "(";

	bool hasOutput = false;
	for (TSetItor itor = mConnections.begin(); itor != mConnections.end(); itor++)
	{
		LNodeT *node = itor->first;

		if (node != caller)
		{
			if (hasOutput)
				ost << ",";

			ost << node->ToString(this) << ":" << itor->second;

			hasOutput = true;
		}
	}

	ost << ")";

	return ost.str();
}
//__________________________________________________________________________________________
} //end namespace BioInf
