//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LSetL
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

#include "LSetT.h"
#include <vector>
#include <string>

namespace BioInf
{

//....................................................................................................................................................................................
class	LSetL
{
public:
	LSetL										(LSetT &setT, int numLeafs);
	virtual ~LSetL								();

	void				SetDistance				(int indexI, int indexJ, double distance);
	void				SetDistanceSafe			(int indexI, int indexJ, double distance);

	void				InitDistanceSum			();

	void				Process					();

protected:
	double				GetDistance				(int indexI, int indexJ);
	double				GetDistanceSafe			(int indexI, int indexJ);

	// Add index to the map of id's, and return the id.
	void				CreateNewId				(int index);

	void				FindMinDistance			(int &indexI, int &indexJ, double frac);

	void				FindLastTwoNodes		(int &indexI, int &indexJ, int &idI, int &idJ);

	void				RemoveNode				(int index);

	// frac = 1/(|L|-2)
	void				AddNode					(int indexI, int indexJ, double frac);

private:
	void				DoAllocate				();
	void				DoDelete				();

private:
	double					**mDistance;
	std::vector<double>		mDistanceSum;
	std::vector<int>		mIdMap;

	int						mNumNodes;				// Max number of nodes.
	int						mNumActiveNodes;		// Number of currently active nodes.
	int						mNodeId;				// Id for the lastly created node.
	LSetT					&mSetT;
};
} //end namespace BioInf
