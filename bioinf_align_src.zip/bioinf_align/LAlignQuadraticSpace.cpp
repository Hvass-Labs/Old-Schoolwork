//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LAlignQuadraticSpace
//
//__________________________________________________________________________________________

#include "LAlignQuadraticSpace.h"
#include <assert.h>

namespace BioInf
{

//__________________________________________________________________________________________
LAlignQuadraticSpace::LAlignQuadraticSpace				(char *S1, char *S2, int N, int M) :
LAlign(S1, S2, N, M)
{
	mV = new int*[N+1];
	assert(mV);

	mTraceTable = new char*[N+1];
	assert(mTraceTable);

	for (int i=0; i<N+1; i++)
	{
		mV[i] = new int[M+1];
		assert(mV[i]);

		mTraceTable[i] = new char[M+1];
		assert(mTraceTable[i]);
	}
}
//__________________________________________________________________________________________
LAlignQuadraticSpace::~LAlignQuadraticSpace				()
{
	for (int i=0; i<kN+1; i++)
	{
		delete [] mV[i];
		delete [] mTraceTable[i];
	}

	delete [] mV;
	delete [] mTraceTable;
}
//__________________________________________________________________________________________
int
LAlignQuadraticSpace::Trace					(char **outS1, char **outS2)
{
	int i, j;
	int length = 0;

	// Conditional expression shouldn't be necessary if alignment is correct.
	for (i=kN, j=kM; true; length++)
	{
		assert(i>=0 && j>=0);

		if (IsTraceDiagonal(i, j))
		{
			i--;
			j--;
		}
		else if (IsTraceUp(i, j))
		{
			i--;
		}
		else if (IsTraceLeft(i, j))
		{
			j--;
		}
		else
		{
			// should only happen for (0,0)'th cell.
			assert(i==0 && j==0);
			break;
		}
	}

	char *out1 = new char[length+1];
	assert(out1);
	out1[length] = 0; // terminate string.
	*outS1 = out1;

	char *out2 = new char[length+1];
	assert(out2);
	out2[length] = 0; // terminate string.
	*outS2 = out2;

	int k=length-1;

	for (i=kN, j=kM; true; k--)
	{
		assert(i>=0 && j>=0);
		char ch1, ch2;

		if (IsTraceDiagonal(i, j))
		{
			ch1 = GetS1(i);
			ch2 = GetS2(j);

			i--;
			j--;
		}
		else if (IsTraceUp(i, j))
		{
			ch1 = GetS1(i);
			ch2 = '-';

			i--;
		}
		else if (IsTraceLeft(i, j))
		{
			ch1 = '-';
			ch2 = GetS2(j);

			j--;
		}
		else
		{
			// should only happen for (0,0)'th cell.
			assert(i==0 && j==0);
			break;
		}

		out1[k] = ch1;
		out2[k] = ch2;
	}

	return length;
}
//__________________________________________________________________________________________
int
LAlignQuadraticSpace::Calculate		()
{
	int i, j;

	// Reset the (0,0)-cell
	SetV(0, 0, 0);
	ResetTrace(0, 0);

	// Reset the first row.
	for (j=1; j<kM+1; j++)
	{
		InitFirstRowCell(j);
		ResetTrace(0, j);
		AddTrace(0, j, eTraceLeft);
	}

	// Reset the first column.
	for (i=1; i<kN+1; i++)
	{
		InitFirstColumnCell(i);
		ResetTrace(i, 0);
		AddTrace(i, 0, eTraceUp);
	}

	// Fill in the rest of the table.
	for (i=1; i<kN+1; i++)
	{
		for (j=1; j<kM+1; j++)
		{
			int scoreUp = GetScoreUp(i, j);
			int scoreLeft = GetScoreLeft(i, j);
			int scoreDiagonal = GetScoreDiagonal(i, j);

			// Find the minimum score.
			int maxScore = scoreUp;

			if (scoreLeft > maxScore)
				maxScore = scoreLeft;

			if (scoreDiagonal > maxScore)
				maxScore = scoreDiagonal;

			// Set the score for the cell.
			SetV(i, j, maxScore);

			// Reset trace-back.
			ResetTrace(i, j);

			// Add relevant trace-backs.
			if (scoreUp == maxScore)
				AddTrace(i, j, eTraceUp);

			if (scoreLeft == maxScore)
				AddTrace(i, j, eTraceLeft);

			if (scoreDiagonal == maxScore)
				AddTrace(i, j, eTraceDiagonal);
		}
	}

	return GetV(kN, kM);
}
//__________________________________________________________________________________________
} //end namespace BioInf
