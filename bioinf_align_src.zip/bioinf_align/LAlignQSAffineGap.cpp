//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LAlignQSAffineGap
//
//__________________________________________________________________________________________

#include "LAlignQSAffineGap.h"
#include <assert.h>

namespace BioInf
{

//__________________________________________________________________________________________
LAlignQSAffineGap::LAlignQSAffineGap				(char *S1, char *S2, int N, int M, int Wg, int Ws) :
LAlignQSConstantGap(S1, S2, N, M, Wg),
kWs(Ws)
{
//	assert(kWs>0); // Otherwise use LAlignConstantGap

	mE = new int*[N+1];
	assert(mE);

	mF = new int*[N+1];
	assert(mF);

	for (int i=0; i<N+1; i++)
	{
		mE[i] = new int[M+1];
		assert(mE[i]);

		mF[i] = new int[M+1];
		assert(mF[i]);
	}
}
//__________________________________________________________________________________________
LAlignQSAffineGap::~LAlignQSAffineGap				()
{
	for (int i=0; i<kN+1; i++)
	{
		delete [] mE[i];
		delete [] mF[i];
	}

	delete [] mE;
	delete [] mF;
}
//__________________________________________________________________________________________
int
LAlignQSAffineGap::GetScoreUp		(int i, int j)
{
	int score1 = GetF(i-1, j);
	int score2 = GetV(i-1, j) - kWg;

	int scoreMax = (score1>score2) ? (score1): (score2);
	int scoreTotal = scoreMax - kWs;

	SetF(i, j, scoreTotal);

	return scoreTotal;
}
//__________________________________________________________________________________________
int
LAlignQSAffineGap::GetScoreLeft	(int i, int j)
{
	int score1 = GetE(i, j-1);
	int score2 = GetV(i, j-1) - kWg;

	int scoreMax = (score1>score2) ? (score1): (score2);
	int scoreTotal = scoreMax - kWs;

	SetE(i, j, scoreTotal);

	return scoreTotal;
}
//__________________________________________________________________________________________
} //end namespace BioInf
