//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LAlign
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

#include "LScore.h"

namespace BioInf
{

	enum
	{
		eTraceLeft = 1,			// (i, j-1)
		eTraceDiagonal = 2,		// (i-1, j-1)
		eTraceUp = 4			// (i-1, j)
	};

//....................................................................................................................................................................................
class	LAlign
{
public:
	LAlign										(char *S1, char *S2, int N, int M);
	virtual ~LAlign								() {}

	// Set the score-matrix.
	void				SetScoreMatrix			(LScore *score) { mScore = score; }

	// Perform the alignment and return the score.
	virtual int			Calculate				() = 0;

	// ### and return the length of the aligned strings.
	virtual int			Trace					(char **outS1, char **outS2) = 0;

protected:
	LScore			*mScore;				// Score-matrix for comparing characters.
	char			*mS1, *mS2;				// Strings to be aligned.
	const int		kN, kM;					// Length of S1 and S2 respectively.
};
} //end namespace BioInf
