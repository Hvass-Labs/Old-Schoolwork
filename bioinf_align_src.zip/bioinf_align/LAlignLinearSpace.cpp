//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LAlignLinearSpace
//
//__________________________________________________________________________________________

#include "LAlignLinearSpace.h"
#include <assert.h>
#include <algorithm>

namespace BioInf
{

//__________________________________________________________________________________________
LAlignLinearSpace::LAlignLinearSpace				(char *S1, char *S2, int N, int M) :
LAlign(S1, S2, N, M)
{
	mV = new int[M+1]; assert(mV);
	mVR = new int[M+1]; assert(mVR);
	mVP = new int[M+1]; assert(mVP);

	mTrace = new char[M+1]; assert(mTrace);
	mTraceR = new char[M+1]; assert(mTraceR);

	mSR1 = StrCopyReverse(mS1, N);
	mSR2 = StrCopyReverse(mS2, M);
}
//__________________________________________________________________________________________
LAlignLinearSpace::~LAlignLinearSpace				()
{
	delete [] mV;
	delete [] mVR;
	delete [] mVP;

	delete [] mTrace;
	delete [] mTraceR;

	delete [] mSR1;
	delete [] mSR2;
}
//__________________________________________________________________________________________
char*
LAlignLinearSpace::StrCopyReverse			(char *str, int len)
{
	assert(str);

	char *strR = new char[len]; assert(strR);

	int i, j;

	for (i=0, j=len-1; i<len; i++, j--)
	{
		strR[i] = str[j];
	}

	return strR;
}
//__________________________________________________________________________________________
int
LAlignLinearSpace::Trace					(char **outS1, char **outS2)
{
	int i, j;
	int length = (int) mTracePath.size();

	char *out1 = new char[length+1];
	assert(out1);
	out1[length] = 0; // terminate string.
	*outS1 = out1;

	char *out2 = new char[length+1];
	assert(out2);
	out2[length] = 0; // terminate string.
	*outS2 = out2;

	int k=length-1;

	for (i=kN, j=kM; true; k--)
	{
		assert(i>=0 && j>=0);
		assert(k>=0);
		char ch1, ch2;

		if (IsTraceDiagonal(mTracePath[k]))
		{
			ch1 = GetS1(mS1, i);
			ch2 = GetS2(mS2, j);

			i--;
			j--;
		}
		else if (IsTraceUp(mTracePath[k]))
		{
			ch1 = GetS1(mS1, i);
			ch2 = '-';

			i--;
		}
		else if (IsTraceLeft(mTracePath[k]))
		{
			ch1 = '-';
			ch2 = GetS2(mS2, j);

			j--;
		}
		else
		{
			break;
		}

		out1[k] = ch1;
		out2[k] = ch2;
	}

	return length;
}
//__________________________________________________________________________________________
int
LAlignLinearSpace::TwoPartScore		(int *V, int *VR, int h, int k, int kR)
{
	return V[h, k] + VR[h, kR];
}
//__________________________________________________________________________________________
int
LAlignLinearSpace::FindPath			(char *traceRow, int k, std::vector<char> &traceSubPath)
{
	int j = 0;

	while (true)
	{
		if (IsTraceUp(traceRow[k-j]))
		{
			traceSubPath.push_back(eTraceUp);
			break;
		}
		else if (IsTraceDiagonal(traceRow[k-j]))
		{
			traceSubPath.push_back(eTraceDiagonal);
			j++;
			break;
		}
		else // Assume IsTraceLeft()
		{
			traceSubPath.push_back(eTraceLeft);
			j++;
		}
	}

	return j;
}
//__________________________________________________________________________________________
int
LAlignLinearSpace::FindPathR		(char *traceRow, int k, std::vector<char> &traceSubPath)
{
	std::vector<char> tempSubPath;

	int j = FindPath(traceRow, k, tempSubPath);

	int pathLength = tempSubPath.size();

	for (int i=0; i<pathLength; i++)
	{
		traceSubPath.push_back(tempSubPath[pathLength-i-1]);
	}

	return j;
}
//__________________________________________________________________________________________
int
LAlignLinearSpace::Calculate		()
{
	// Clear the trace-path
	mTracePath.erase(mTracePath.begin(), mTracePath.end());

	int score = DoCalculate(1, kN, 1, kM);
	return score;
}
//__________________________________________________________________________________________
int
LAlignLinearSpace::DoCalculate		(int l1, int l2, int r1, int r2)
{
	int i, j, k;

	int h = (l2+l1)/2; // ### rounding?

	// ### 
	int *V = DoAlign(mS1, mS2, mV, mVP, mTrace, l1, h, r1, r2);
	int *VR = DoAlign(mSR1, mSR2, mVR, mVP, mTraceR, l1, h, r1, r2);

	int bestK = r1;
	int bestScore = TwoPartScore(V, VR, h, bestK, r2-bestK);

	// Find optimal-path index.
	for (k=r1+1; k<=r2; k++)
	{
		int score = TwoPartScore(V, VR, h, k, r2-k);

		if (score>bestScore)
		{
			bestScore = score;
			bestK = k;
		}
	}

	int k1, k2; // Row-index in previous and next row, respectively.
	std::vector<char> traceSubPath;

	// Since traceSubPath is used as a stack, we must find the subpath for the reverse string first.
	k2 = bestK+FindPathR(mTraceR, bestK, traceSubPath);
	k1 = bestK-FindPath(mTrace, bestK, traceSubPath);

	assert(k1<=bestK && bestK<=k2);

	if (l1<=h-1 && r1<=k1)
		DoCalculate(l1, h-1, r1, k1);

	// Output path
	for (i=0; i<traceSubPath.size(); i++)
		mTracePath.push_back(traceSubPath[i]);

	if (h+1<=l2 && k2<=r2)
		DoCalculate(h+1, l2, k2, r2);

	return bestScore;
}
//__________________________________________________________________________________________
int*
LAlignLinearSpace::DoAlign			(char *s1, char *s2, int *VC, int *VP, char *traceRow, int l1, int l2, int r1, int r2)
{
	assert(l1>=1 && l1<=l2 && l2<=kN);
	assert(r1>=1 && r1<=r2 && r2<=kM);

	int i, j;

	VP[r1-1] = 0;

	// Reset the previous row.
	for (j=r1; j<=r2; j++)
	{
		VP[j] = j-r1+1; // ### What should this be???
	}

	for (i=l1; i<=l2; i++) // ###
	{
		VC[r1-1] = i-l1+1; // ### what should this be???

		for (j=r1; j<=r2; j++) // ###
		{
			int scoreUp = VP[j] + 1;
			int scoreLeft = VC[j-1] + 1; // ###
			int scoreDiagonal = VP[j-1] + CharScore(s1, s2, i, j);

			// Find the minimum score.
			int maxScore = scoreUp;

			if (scoreLeft > maxScore)
				maxScore = scoreLeft;

			if (scoreDiagonal > maxScore)
				maxScore = scoreDiagonal;

			// Set the score for the cell.
			VC[j] = maxScore;

			if (i == l2)
			{
				// Reset trace-back.
				ResetTrace(traceRow, j);

				// Add relevant trace-backs.
				if (scoreUp == maxScore)
					AddTrace(traceRow, j, eTraceUp);

				if (scoreLeft == maxScore)
					AddTrace(traceRow, j, eTraceLeft);

				if (scoreDiagonal == maxScore)
					AddTrace(traceRow, j, eTraceDiagonal);
			}
		}

		std::swap(VP, VC);
	}

	return VP;
}
//__________________________________________________________________________________________
} //end namespace BioInf
