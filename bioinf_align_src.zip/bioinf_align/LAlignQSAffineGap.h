//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LAlignQSAffineGap
//
//	Affine gap-weight alignment.
//
//....................................................................................................................................................................................

#pragma once

#include "LAlignQSConstantGap.h"

namespace BioInf
{

//....................................................................................................................................................................................
class	LAlignQSAffineGap : public LAlignQSConstantGap
{
public:
	LAlignQSAffineGap							(char *S1, char *S2, int N, int M, int Wg, int Ws);
	virtual ~LAlignQSAffineGap					();

protected:
	virtual int			GetScoreUp				(int i, int j);

	virtual int			GetScoreLeft			(int i, int j);

	virtual void		InitFirstRowCell		(int j) { SetV(0, j, -kWg - j*kWs); }

	virtual void		InitFirstColumnCell		(int i) { SetV(i, 0, -kWg - i*kWs); }

protected:
	int					GetE					(int i, int j) { return mE[i][j]; }
	void				SetE					(int i, int j, int score) { mE[i][j] = score; }

	int					GetF					(int i, int j) { return mF[i][j]; }
	void				SetF					(int i, int j, int score) { mF[i][j] = score; }

private:
	int				**mE;					// Score table E.
	int				**mF;					// Score table F.

protected:
	const int		kWs;					// Space-weight.
};
} //end namespace BioInf
