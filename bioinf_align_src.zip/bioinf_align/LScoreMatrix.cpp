//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LScoreMatrix
//
//__________________________________________________________________________________________

#include "LScoreMatrix.h"
#include <limits>
#include <assert.h>

namespace BioInf
{

//__________________________________________________________________________________________
LScoreMatrix::LScoreMatrix				(unsigned char alphabetSize) :
LScore(),
kAlphabetSize(alphabetSize)
{
	int maxNumChars = std::numeric_limits<unsigned char>::max();

	mIndexMap = new int[maxNumChars];
	assert(mIndexMap);

	mScores = new int*[kAlphabetSize];
	assert(mScores);

	mAlphabet = new char[kAlphabetSize];
	assert(mAlphabet);

	for (int i=0; i<kAlphabetSize; i++)
	{
		mScores[i] = new int[kAlphabetSize];
		assert(mScores[i]);
	}

	// Initialize index-map
	for (int i=0; i<maxNumChars; i++)
	{
		mIndexMap[i] = -1;
	}
}
//__________________________________________________________________________________________
LScoreMatrix::~LScoreMatrix				()
{
	for (int i=0; i<kAlphabetSize; i++)
	{
		delete [] mScores[i];
	}

	delete [] mScores;
	delete [] mIndexMap;
	delete [] mAlphabet;
}
//__________________________________________________________________________________________
void
LScoreMatrix::SetCharIndex				(char a, int index)
{
	assert(index>=0 && index<kAlphabetSize);	// Check that the index is valid.
	assert(GetIndex(a) == -1);					// Check that the index isn't used.

	mIndexMap[a] = index;
	mAlphabet[index] = a;
}
//__________________________________________________________________________________________
void
LScoreMatrix::SetScore					(int aIndex, int bIndex, int score)
{
	assert(aIndex>= 0 && aIndex<kAlphabetSize);
	assert(bIndex>= 0 && bIndex<kAlphabetSize);

	mScores[aIndex][bIndex] = score;
}
//__________________________________________________________________________________________
int
LScoreMatrix::Score						(char a, char b)
{
	int aIndex = GetIndex(a);
	int bIndex = GetIndex(b);

	assert(aIndex != -1);
	assert(bIndex != -1);

	return mScores[aIndex][bIndex];
}
//__________________________________________________________________________________________
} //end namespace BioInf
