//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LAlignQSConstantGap
//
//	Constant gap-weight alignment.
//
//....................................................................................................................................................................................

#pragma once

#include "LAlignQuadraticSpace.h"
#include <assert.h>

namespace BioInf
{

//....................................................................................................................................................................................
class	LAlignQSConstantGap : public LAlignQuadraticSpace
{
public:
	LAlignQSConstantGap							(char *S1, char *S2, int N, int M, int Wg) : LAlignQuadraticSpace(S1, S2, N, M), kWg(Wg)
	{
		assert(Wg>0);
	}

protected:
	virtual int			GetScoreUp				(int i, int j) { return GetV(i-1, j) - kWg; }

	virtual int			GetScoreLeft			(int i, int j) { return GetV(i, j-1) - kWg; }

	virtual void		InitFirstRowCell		(int j) { SetV(0, j, -kWg); }

	virtual void		InitFirstColumnCell		(int i) { SetV(i, 0, -kWg); }

protected:
	const int		kWg;					// Gap-weight.
};
} //end namespace BioInf
