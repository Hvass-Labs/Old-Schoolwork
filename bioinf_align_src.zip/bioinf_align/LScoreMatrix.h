//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LScoreMatrix
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

#include "LScore.h"
#include <limits>

namespace BioInf
{

//....................................................................................................................................................................................
class	LScoreMatrix : public LScore
{
public:
	LScoreMatrix								(unsigned char alphabetSize);
	~LScoreMatrix								();

	// Set the character a to be the index'th element of the alphabet
	void				SetCharIndex			(char a, int index);

	void				SetScore				(int aIndex, int bIndex, int score);

	virtual int			Score					(char a, char b);

	virtual bool		IsValid					(char a) { return mIndexMap[a] != -1; }

	virtual char		GetDefaultChar			() { return mAlphabet[0]; }

private:
	int					GetIndex				(char a) { return mIndexMap[a]; }

private:
	int			**mScores;
	int			*mIndexMap;
	char		*mAlphabet;

	const int	kAlphabetSize;
};
} //end namespace BioInf
