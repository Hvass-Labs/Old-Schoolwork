//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LAlignQuadraticSpace
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

#include "LScore.h"
#include "LAlign.h"

namespace BioInf
{

//....................................................................................................................................................................................
class	LAlignQuadraticSpace : public LAlign
{
public:
	LAlignQuadraticSpace						(char *S1, char *S2, int N, int M);
	virtual ~LAlignQuadraticSpace				();

	// Set the score-matrix.
	void				SetScoreMatrix			(LScore *score) { mScore = score; }

	// Perform the alignment and return the score.
	virtual int			Calculate				();

	// ### and return the length of the aligned strings.
	virtual int			Trace					(char **outS1, char **outS2);

protected:
	virtual int			GetScoreUp				(int i, int j) { return GetV(i-1, j) + 1; }

	virtual int			GetScoreLeft			(int i, int j) { return GetV(i, j-1) + 1; }

	virtual int			GetScoreDiagonal		(int i, int j) { return GetV(i-1, j-1) + CharScore(i, j); }

	virtual void		InitFirstRowCell		(int j) { SetV(0, j, j); }

	virtual void		InitFirstColumnCell		(int i) { SetV(i, 0, i); }

	// Set the score for the (i,j)'th cell.
	void				SetV					(int i, int j, int score) { mV[i][j] = score; }

	// Return the score for the (i,j)'th cell.
	int					GetV					(int i, int j) { return mV[i][j]; }

	// The score of comparing two characters.
	int					CharScore				(int i, int j) { return mScore->Score(GetS1(i), GetS2(j)); }

private:
	// Reset the (i,j)'th cell so that it has no trace-back.
	void				ResetTrace				(int i, int j) { mTraceTable[i][j] = 0; }

	// Add a trace-back to the (i,j)'th cell. See enum above.
	// ### Use binary OR
	void				AddTrace				(int i, int j, char trace) { mTraceTable[i][j] |= trace; }

	char				GetTrace				(int i, int j) { return mTraceTable[i][j]; }

	bool				IsTraceUp				(int i, int j) { return (GetTrace(i,j) & eTraceUp) != 0; }

	bool				IsTraceLeft				(int i, int j) { return (GetTrace(i,j) & eTraceLeft) != 0; }

	bool				IsTraceDiagonal			(int i, int j) { return (GetTrace(i,j) & eTraceDiagonal) != 0; }

	// Return S1[i] where i is in the range [1,N]
	char				GetS1					(int i) { return mS1[i-1]; }

	// Return S2[j] where j is in the range [1,M]
	char				GetS2					(int j) { return mS2[j-1]; }

private:
	int				**mV;					// Score table V.
	char			**mTraceTable;			// Trace-back table.
};
} //end namespace BioInf
