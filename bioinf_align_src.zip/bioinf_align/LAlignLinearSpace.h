//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LAlignLinearSpace
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

#include "LAlign.h"
#include <vector>

namespace BioInf
{

//....................................................................................................................................................................................
class	LAlignLinearSpace : public LAlign
{
public:
	LAlignLinearSpace							(char *S1, char *S2, int N, int M);
	virtual ~LAlignLinearSpace					();

	// Perform the alignment and return the score.
	virtual int			Calculate				();

	// ### and return the length of the aligned strings.
	virtual int			Trace					(char **outS1, char **outS2);

protected:
	char				*StrCopyReverse			(char *str, int len);

	// Return distance from k ###
	int					FindPath				(char *traceRow, int k, std::vector<char> &traceSubPath);

	// Return distance from k ###
	int					FindPathR				(char *traceRow, int k, std::vector<char> &traceSubPath);

	virtual int			DoCalculate				(int l1, int l2, int r1, int r2);

	int					TwoPartScore			(int *V, int *VR, int h, int k, int kR);

	int					*DoAlign				(char *s1, char *s2, int *VC, int *VP, char *traceRow, int l1, int l2, int r1, int r2);	

//	virtual int			GetScoreUp				(int i, int j) { return GetV(j) + 1; }

//	virtual int			GetScoreLeft			(int i, int j) { return GetV(i, j-1) + 1; }

//	virtual int			GetScoreDiagonal		(int j) { return GetV(j-1) + CharScore(i, j); }

//	virtual void		InitFirstRowCell		(int j) { SetV(0, j, j); }

//	virtual void		InitFirstColumnCell		(int i) { SetV(i, 0, i); }

	// Set the score for the (i,j)'th cell.
//	void				SetV					(int j, int score) { mV[i][j] = score; }

	// Return the score for the (i,j)'th cell.
//	int					GetV					(int j) { return mV[j]; }

	// The score of comparing two characters.
	int					CharScore				(char *s1, char *s2, int i, int j) { return mScore->Score(GetS1(s1, i), GetS2(s2, j)); }

private:
	// Reset the (i,j)'th cell so that it has no trace-back.
	void				ResetTrace				(char *traceRow, int j) { traceRow[j] = 0; }

	// Add a trace-back to the (i,j)'th cell. See enum above.
	// ### Use binary OR
	void				AddTrace				(char *traceRow, int j, char trace) { traceRow[j] |= trace; }

	bool				IsTraceUp				(char traceCh) { return (traceCh & eTraceUp) != 0; }

	bool				IsTraceLeft				(char traceCh) { return (traceCh & eTraceLeft) != 0; }

	bool				IsTraceDiagonal			(char traceCh) { return (traceCh & eTraceDiagonal) != 0; }

	// Return S1[i] where i is in the range [1,N]
	char				GetS1					(char *s1, int i) { return s1[i-1]; }

	// Return S2[j] where j is in the range [1,M]
	char				GetS2					(char *s2, int j) { return s2[j-1]; }

private:
	std::vector<char>	mTracePath;				// Complete trace-back

	int				*mV;					// Score _row_.
	int				*mVR;					// Score _row_ for the reverse strings.
	int				*mVP;					// Previous score row.

	char			*mTrace;				// Trace-back _row_.
	char			*mTraceR;				// Trace-back _row_ for the reverse strings.

	char			*mSR1, *mSR2;			// Reverse strings to be aligned.
};
} //end namespace BioInf
