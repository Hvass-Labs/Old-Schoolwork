// bioinf_align.cpp : Defines the entry point for the console application.
//

//#define TESTING

#include "stdafx.h"
#include <fstream>
#include <ctime>

#include "seqio.h"

#include "LAlign.h"
#include "LAlignQSAffineGap.h"
#include "LAlignQSConstantGap.h"
#include "LAlignLinearSpace.h"
#include "LScoreMatrix.h"

using namespace BioInf;

const kInputBufSize = 256;

char gFilenameScore[kInputBufSize];
char gFiletypeInput[kInputBufSize];
char gFilenameInput1[kInputBufSize];
char gFilenameInput2[kInputBufSize];
char gFiletypeOutput[kInputBufSize];
char gFilenameOutput[kInputBufSize];

char gFilenameStatScore[kInputBufSize];
char gFilenameStatGapLength[kInputBufSize];
char gFilenameStatNumGaps[kInputBufSize];
char gFilenameStatTime[kInputBufSize];

int gUseAffineGapWeight = 1;
int gUseQuadraticSpace = 1;

int gGapWeight = 10;
int gSpaceWeight = 2;

int gMaxSquareLength = 5000*5000;
LScore *gScore = 0;

void Error(const char *p, const char *p2 = "")
{
	std::cerr << p << ' ' << p2 << std::endl;
	std::exit(1);
}

// Skip to the next line.
void SkipToNewline(std::ifstream &infile)
{
	char ch=' ';

	while (ch != '\n')
	{
		infile.get(ch);
	}
}

// Return lowercase(ch) if ch is an uppercase character, else return ch.
// Assumes characters are coded consecutively (e.g. as in ASCII)
char LowerCase(char ch)
{
	char retVal;

	if (ch >= 'A' && ch <= 'Z')
		retVal = ch-'A'+'a';
	else
		retVal = ch;

	return retVal;
}

LScoreMatrix *ReadScoreMatrix(char *filename)
{
	assert(filename);

	std::ifstream infile(filename);

	if (!infile)
		Error("Cannot open input file", filename);

	int alphabetSize;

	infile >> alphabetSize;
	SkipToNewline(infile);

	LScoreMatrix *scoreMatrix = new LScoreMatrix(alphabetSize);

	// ### lowercase letters?
	for (int i=0; i<alphabetSize; i++)
	{
		char ch;
		infile.get(ch);
		scoreMatrix->SetCharIndex(LowerCase(ch), i);

		for (int j=0; j<alphabetSize; j++)
		{
			int score;
			infile >> score;
			scoreMatrix->SetScore(i, j, score); // ###
		}

		SkipToNewline(infile);
	}

	return scoreMatrix;
}

// Make sequence in lowercase and replace unknown char n with a
void ProcessSequence(char *seq, int length)
{
	for (int i=0; i<length; i++)
	{
		seq[i] = LowerCase(seq[i]);

		// Assign default char to all invalid (i.e. unknown) characters in the sequence.
		if (!gScore->IsValid(seq[i]))
			seq[i] = gScore->GetDefaultChar();
	}
}

int CountGaps(char *seqo, int outputLength, int *sumGapLength)
{
	int sumLength=0;
	int numGaps=0;
	int i=0;

	while (i<outputLength)
	{
		if (seqo[i] == '-')
		{
			numGaps++;

			// Skip gap, adding to total sum of gap-length.
			while (i<outputLength && seqo[i] == '-')
			{
				i++;
				sumLength++;
			}
		}
		else
		{
			i++;
		}
	}

	*sumGapLength = sumLength;

	return numGaps;
}

void GetParameters()
{
#ifndef TESTING
	std::cout << "Filename for score-matrix (in Phylip format): ";
	std::cin >> gFilenameScore;

	std::cout << "Filetype for input (e.g. GenBank or FASTA): ";
	std::cin >> gFiletypeInput;

	std::cout << "Filename for sequence-file 1: ";
	std::cin >> gFilenameInput1;

	std::cout << "Filename for sequence-file 2: ";
	std::cin >> gFilenameInput2;

	std::cout << "Filetype for output (e.g. GenBank or FASTA): ";
	std::cin >> gFiletypeOutput;

	std::cout << "Filename for sequence output file: ";
	std::cin >> gFilenameOutput;

	std::cout << "Filename for score statistics file: ";
	std::cin >> gFilenameStatScore;

	std::cout << "Filename for gap-length statistics file: ";
	std::cin >> gFilenameStatGapLength;

	std::cout << "Filename for number-of-gaps statistics file: ";
	std::cin >> gFilenameStatNumGaps;

	std::cout << "Filename for time statistics file: ";
	std::cin >> gFilenameStatTime;

	std::cout << "Max sequence-length multiplum accepted (e.g. 25000000): ";
	std::cin >> gMaxSquareLength;

	std::cout << "Use affine or constant gap-weight (1 for affine, 0 for constant): ";
	std::cin >> gUseAffineGapWeight;

	std::cout << "Gap-weight (e.g. 10): ";
	std::cin >> gGapWeight;

	if (gUseAffineGapWeight)
	{
		std::cout << "Space-weight (e.g. 2): ";
		std::cin >> gSpaceWeight;
	}

//	std::cout << "Use quadratic or linear space algorithms (1 for quadratic, 0 for linear): ";
//	std::cin >> gUseQuadraticSpace;
	gUseQuadraticSpace = 1;

#else

	strcpy(gFilenameScore, "score01.txt");
	strcpy(gFiletypeInput, "GenBank");
	strcpy(gFilenameInput1, "human.seq");
	strcpy(gFilenameInput2, "mouse.seq");
	strcpy(gFiletypeOutput, "FASTA");
	strcpy(gFilenameOutput, "output.FASTA");
	strcpy(gFilenameStatScore, "statScore.txt");
	strcpy(gFilenameStatGapLength, "statGapLength.txt");
	strcpy(gFilenameStatNumGaps, "statNumGaps.txt");
	strcpy(gFilenameStatTime, "statTime.txt");
	strcpy(gFilenameStatScore, "statScore.txt");

	gMaxSquareLength = 25000000;

	gUseAffineGapWeight = 1;
	gGapWeight = 10;
	gSpaceWeight = 2;
	gUseQuadraticSpace = 1;

#endif
}

LAlign *CreateAlign(char *seq1, char *seq2, int len1, int len2)
{
	LAlign *align;

#ifndef TESTING
	if (gUseAffineGapWeight)
	{
		if (gUseQuadraticSpace)
			align = new LAlignQSAffineGap(seq1, seq2, len1, len2, gGapWeight, gSpaceWeight);
//		else
//			align = new LAlignLSAffineGap(seq1, seq2, len1, len2, gGapWeight, gSpaceWeight);
	}
	else
	{
		if (gUseQuadraticSpace)
			align = new LAlignQSConstantGap(seq1, seq2, len1, len2, gGapWeight);
//		else
//			align = new LAlignLSConstantGap(seq1, seq2, len1, len2, gGapWeight);
	}

#else

	align = new LAlignLinearSpace(seq1, seq2, len1, len2);
//	align = new LAlignQuadraticSpace(seq1, seq2, len1, len2);

#endif

	align->SetScoreMatrix(gScore);

	return align;
}

int _tmain(int argc, _TCHAR* argv[])
{
	int len1, len2;
	char *seq1, *seq2, *seqo1, *seqo2;
	SEQFILE *sfp1, *sfp2, *sfpo;
	SEQINFO *info;

	std::cout << "Global Alignment - Magnus E. H. Pedersen, Algortihms in BioInformatics 2004.\nUsing SEQIO (c) 1996 James Knight, for reading and writing sequences.\n" << std::endl;
	GetParameters();

	gScore = ReadScoreMatrix(gFilenameScore);

	// open input sequence files.
	if ((sfp1 = seqfopen(gFilenameInput1, "r", gFiletypeInput)) == NULL)
		exit (1);

	if ((sfp2 = seqfopen(gFilenameInput2, "r", gFiletypeInput)) == NULL)
		exit (1);

	// open output sequence file.
	if ((sfpo = seqfopen(gFilenameOutput, "w", gFiletypeOutput)) == NULL)
		exit(1);

	// Open streams used for statistics output.
	std::fstream statScoreStream(gFilenameStatScore, std::ios_base::out|std::ios_base::trunc);
	std::fstream statGapLengthStream(gFilenameStatGapLength, std::ios_base::out|std::ios_base::trunc);
	std::fstream statNumGapsStream(gFilenameStatNumGaps, std::ios_base::out|std::ios_base::trunc);
	std::fstream statTimeStream(gFilenameStatTime, std::ios_base::out|std::ios_base::trunc);

	if (!statScoreStream.is_open() || !statGapLengthStream.is_open() || !statNumGapsStream.is_open() || !statTimeStream.is_open())
		exit(1);

	// Number of sequence-pairs that were found, and aligned.
	int numSeq=0;
	int numSeqAligned=0;

	// Variables used for overall statistics.
	std::clock_t totalTime=0;
	int totalNumGaps1=0, totalNumGaps2=0;
	int totalGapLength1=0, totalGapLength2=0;
	int totalScore=0;

	do
	{
		// Read the next sequences from the input files.
		seq1 = seqfgetseq(sfp1, &len1, 0);
		seq2 = seqfgetseq(sfp2, &len2, 0);

		// If there were two sequences, process them.
		if (seq1 != NULL && seq2 != NULL)
		{
			numSeq++;

			// Ensure all chars are lowercase, and they are valid.
			ProcessSequence(seq1, len1);
			ProcessSequence(seq2, len2);

			std::cout << "\nAligning sequence-pair no. " << numSeq << ":\n- " << seqfmainid(sfp1, 0) << "\n- " << seqfmainid(sfp2, 0) << std::endl;
			std::cout << "- of length: " << len1 << " and " << len2 << ", respectively." << std::endl;

			if (len1*len2 > gMaxSquareLength)
			{
				std::cout << "- sequences too long, skipping this pair!" << std::endl;

				statScoreStream << numSeq << " " << 0 << std::endl;
				statGapLengthStream << numSeq << " " << 0 << std::endl;
				statNumGapsStream << numSeq << " " << 0 << std::endl;
			}
			else
			{
				std::clock_t beginTime, endTime, diffTime;
				LAlign *align = CreateAlign(seq1, seq2, len1, len2);

				std::cout << "- performing alignment .. ";

				beginTime = std::clock();

				int score = align->Calculate();

				endTime = std::clock();
				diffTime = endTime-beginTime;
				totalTime += diffTime;

				std::cout << "done in " << ((double) diffTime)/1000 << " seconds." << std::endl;

				int outputLength = align->Trace(&seqo1, &seqo2);

				delete align;

				int numGaps1, numGaps2;
				int sumGapLength1, sumGapLength2;

				numGaps1 = CountGaps(seqo1, outputLength, &sumGapLength1);
				numGaps2 = CountGaps(seqo2, outputLength, &sumGapLength2);

				statScoreStream << numSeq << " " << score << std::endl;
				statGapLengthStream << numSeq << " " << sumGapLength1+sumGapLength2 << std::endl;
				statNumGapsStream << numSeq << " " << numGaps1+numGaps2 << std::endl;
				statTimeStream << len1*len2 << " " << diffTime << std::endl;

				// Update total counters for various overall statistics.
				totalScore += score;

				totalNumGaps1 += numGaps1;
				totalNumGaps2 += numGaps2;

				totalGapLength1 += sumGapLength1;
				totalGapLength2 += sumGapLength2;

				// Display statistics for this alignment.
				std::cout << "- Alignment score/similarity: " << score << std::endl;
				std::cout << "- Aligned length: " << outputLength << std::endl;
				std::cout << "- Number of gaps: " << numGaps1 << " and " << numGaps2 << ", sum of gap-lengths: " << sumGapLength1 << " and " << sumGapLength2 << std::endl;

				// Write the aligned sequences to file.
				info = seqfinfo(sfp1, 0);
				seqfwrite(sfpo, seqo1, outputLength, info);

				info = seqfinfo(sfp2, 0);
				seqfwrite(sfpo, seqo2, outputLength, info);

				delete [] seqo1;
				delete [] seqo2;

				numSeqAligned++;
			}
		}
	} while (seq1 != NULL && seq2 != NULL);

	// close sequence files.
	seqfclose(sfp1);
	seqfclose(sfp2);
	seqfclose(sfpo);

	// Close streams used for statistics files.
	statScoreStream.close();
	statGapLengthStream.close();
	statNumGapsStream.close();
	statTimeStream.close();

	std::cout << "\nNumber of sequence pairs: " << numSeq << ", aligned: " << numSeqAligned << std::endl;
	std::cout << "Total time usage: " << ((double) totalTime)/1000 << " seconds, average usage per alignment: " << ((double) totalTime)/(1000*numSeqAligned) << std::endl;
	std::cout << "Total score: " << totalScore << std::endl;
	std::cout << "Total number of gaps for sequences in " << gFilenameInput1 << ": " << totalNumGaps1 << ", total gap-length: " << totalGapLength1 << std::endl;
	std::cout << "Total number of gaps for sequences in " << gFilenameInput2 << ": " << totalNumGaps2 << ", total gap-length: " << totalGapLength2 << std::endl;

	int totalNumGaps = totalNumGaps1+totalNumGaps2;
	double avgNumGaps = ((double) totalNumGaps)/ numSeqAligned;
	double avgGapLength = ((double) (totalGapLength1+totalGapLength2))/ totalNumGaps;

	std::cout << "Average number of gaps per sequence: " << avgNumGaps << ", average gap-length: " << avgGapLength << std::endl;

	return 0;
}

