// aoop_mandatory2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "LFilterIIR_LP1_HC.h"
#include "LFilterIIR_LP1.h"
#include "LFilterIIR_HP1.h"
#include "LFilterIIR_BP1.h"
#include "LFilterIIR_BR1.h"
#include <cmath>
#include <blitz/array.h>
#include "LVectorMini.h"
#include "DotProductFlat.h"

#include <functional>

using namespace blitz;
using namespace ArrayOps;

int _tmain(int argc, _TCHAR* argv[])
{
#if 0
	const kSize = 4;
	//LVectorMini<double, kSize> A, B, C;
	blitz::Array<double, 1> A(kSize), B(kSize), C(kSize);

	for (int i=0; i<kSize; i++)
	{
		A(i) = i+1;
		B(i) = A(i)*10;
		C(i) = B(i)*10;
		//A[i] = i+1;
		//B[i] = A[i]*10;
		//C[i] = B[i]*10;
	}

	A = A + B + C;

	std::cout << A << std::endl;

	//for (int i=0; i<kSize; i++)
	//{
	//	std::cout << A[i] << std :: endl;
	//}
#endif
	const int kIterations = 10;
	const double kCutoff = 0.85;
	const double kSlope = 0.05;

	typedef blitz::Array<double,1> T;
	const kSize = 4;
	T a(kSize), x(kSize);

	for (int i=0; i<kSize; i++)
	{
		a(i) = i+1;
	}
	//typedef double T;
	//T a, x;
	//a = 1;
	x = 0;

	DSP::LFilterIIR_LP1_HC<T, double> filter(a);
	//DSP::LFilterIIR_LP1<T, double> filter(a);
	//DSP::LFilterIIR_BP1<T, double> filter(a);
	//DSP::LFilterIIR_BR1<T, double> filter(a);
	//DSP::LFilterIIR_HP1<T, double> filter(a);

	//filter.SetParameters(kCutoff, kSlope);
	filter.SetParameters(kCutoff);

	for (int i=0; i<kIterations; i++)
	{
		//y = filter.Process(x);
		std::cout << filter(x) << std::endl;
	}

	return 0;
}

