//....................................................................................................................................................................................
//
//	Copyright (C) 2001-2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LFilterIIR_LP1_HC
//
//	???
//
//	T is the datatype for the input/output.
//	U is the datatype for the coefficients.
//
//....................................................................................................................................................................................

#pragma once

namespace DSP
{
//....................................................................................................................................................................................
template <class T, typename U>
class	LFilterIIR_LP1_HC
{
public:
	LFilterIIR_LP1_HC					(T& init) : mY(init) {}

	template <class Exp>
	inline T const&		operator()		(Exp const& x)
	{
		return mY = mA * x + mB * mY;
	}

	// Set the cutoff of the filter, c is [0,1].
	template <class Exp>
	inline void			SetParameters	(Exp const& c)
	{
		mA = 1-c;
		mB = c;
	}

protected:
	T					mY;			// Previous output.
	U					mA, mB;		// Coefficients.
};
//....................................................................................................................................................................................
} //end namespace DSP
