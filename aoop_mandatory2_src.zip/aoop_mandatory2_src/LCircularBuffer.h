//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LCircularBuffer
//
//	Implements a data-structure for a circular buffer, in which elements can be inserted,
//	and elements can be indexed relative to the lastly inserted element.
//	
//	The datatype for the elements is a template argument T, and so is the size of the
//	buffer, kSize, which must therefore be known at compile-time.
//
//	An empty buffer can also be created, but it throws exceptions on all access. However,
//	the ability to create empty buffers is sometimes useful, and the reason it is made as
//	a specialized implementation of the class, is that the regular LCircularBuffer creates
//	an array as in, T mStorage[kSize], which would not be legal with kSize==0.
//
//....................................................................................................................................................................................

#pragma once

#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................
template <class T, int kSize>
class	LCircularBuffer
{
public:
	LCircularBuffer						(T const& init) : mIndex(0)
	{
		for (int i=0; i<kSize; i++)
		{
			mBuffer[i] = init;
		}
	}

	// Return reference to lastly inserted element.
	inline T const&			top			() const
	{
		return mBuffer[mIndex];
	}

	// Insert the given element.
	template <class Exp>
	inline void				push_back	(Exp const& elm)
	{
		// Update index (move back).
		--mIndex;
		mIndex += kSize;
		mIndex %= kSize;

		// Update element at that index.
		mBuffer[mIndex] = elm;
	}

	// Same as push_back(elm) and returning top().
	template <class Exp>
	inline T const&			push_peek	(Exp const& elm)
	{
		push_back(elm);
		return top();
	}

	// Return reference to the element indexed by i,
	// where i is relative to the lastly inserted element, so that
	// the element returned when i==0 is the same as top().
	inline T const&			operator[]	(unsigned int i) const
	{
		assert(i<kSize);

		return mBuffer[(mIndex + i) % kSize];
	}

protected:
	T					mBuffer[kSize];		// Storage.

	unsigned int		mIndex;				// Index into mBuffer for
											// lastly inserted element.
};
//....................................................................................................................................................................................
template <class T>
class	LCircularBuffer<T, 0>
{
public:
	LCircularBuffer<T, 0>		(T const& init) { /* OK, we may init an empty buffer */ }

	template <class Exp>
	inline void				push_back	(Exp const& elm) { /* OK, no access is made */ }

	template <class Exp>
	inline Exp const&		push_peek	(Exp const& elm) { return elm; }

	// Throw an exception on all access to buffer.
	inline T const&			top			() const { throw; }
	inline T const&			operator[]	(unsigned int i) const { throw; }
};
//....................................................................................................................................................................................
} //end namespace Yggdrasil
