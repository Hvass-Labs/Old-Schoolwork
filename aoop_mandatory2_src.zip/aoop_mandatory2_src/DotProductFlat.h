//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	DotProductFlat
//
//	???
//
//....................................................................................................................................................................................

#pragma once

#include <cassert>

namespace ArrayOps
{

//....................................................................................................................................................................................
// Use this function, as template arguments U and V can be automatically deduced.
template <unsigned int i, class T, class U, class V> inline
T DotProductFlat(U const& a, V const& b)
{
	return LDotProductFlat<T, U, V>::Do<i>(a, b);
}
//....................................................................................................................................................................................
template <class T, class U, class V>
class	LDotProductFlat
{
public:
	template <unsigned int i>
	static inline T Do (U const& a, V const& b)
	{
		return a[i-1] * b[i-1] + Do<i-1>(a, b);
	}

	template <>
	static inline T Do<0> (U const& a, V const& b)
	{
		return 0;
	}
};
//....................................................................................................................................................................................
} //end namespace ArrayOps
