//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LVectorMini
//
//	Data-structure used for storing small vectors whose size is known at compile-time.
//	Template functions supporting the meta-programming of ArrayOpsMeta.h are also
//	provided, so that one may write arithmetic expressions on vectors as: A = B + C;
//
//	The arithmetic expression is first evaluated on assignment, which is implemented
//	without the use of a for-loop in LVectorMini. This class should therefore be used
//	for vectors of smaller sizes (say, 8 or maybe 16 elements, depending on the machine).
//
//....................................................................................................................................................................................

#pragma once

#include "ArrayOpsMeta.h"
#include <cassert>

namespace ArrayOps
{
//....................................................................................................................................................................................
template <class T, unsigned int kSize>
class	LVectorMini_Imp
{
public:
	LVectorMini_Imp				() {}

	// Element lookup.
	inline T&	operator[]		(unsigned int i) { assert(i<kSize); return mStorage[i]; }

	// Element lookup, const.
	inline
	T const&	operator[]		(unsigned int i) const { assert(i<kSize); return mStorage[i]; }

private:
	// For testing: Ensure no implicit assignments take place. ???
	LVectorMini_Imp				(LVectorMini_Imp const& vector) { throw; }

protected:
	T			mStorage[kSize];
};

template <class T, unsigned int kSize>
class LVectorMini : public Expression<T, LVectorMini_Imp<T, kSize> >
{
public:
	LVectorMini () : Expression<T, LVectorMini_Imp<T, kSize> >() {}

	// Assignment from any kind of data-structure or expression supporting operator[] lookup.
	template <class Expr> inline
	LVectorMini& operator=		(Expr& x)
	{
		// ??? A loop should get automatically unrolled if compiler decides it is beneficial.
		for (int i=0; i<kSize; i++)
		{
			(*this)[i] = x[i];
		}
		//MAssign<Expr,kSize>::Do(*this, x);
		return *this;
	}

protected:
	// ----------------------------------------------------
	// Meta-programming, assignment.
	template <class Expr, unsigned int i>
	class MAssign
	{
	public:
		static inline void Do (LVectorMini<T,kSize>& v, Expr& x)
		{
			v[i-1] = x[i-1];
			MAssign<Expr, i-1>::Do(v, x);
		}
	};

	template <class Expr>
	class MAssign<Expr, 0>
	{
	public:
		static inline void Do (LVectorMini<T,kSize>& v, Expr const& x) { /* Do nothing. */ }
	};
};
//....................................................................................................................................................................................
} //end namespace ArrayOps
