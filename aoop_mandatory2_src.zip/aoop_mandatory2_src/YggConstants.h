//....................................................................................................................................................................................
//
//	Copyright�2001-2003 by Thurs. All rights reserved.
//
//	YggConstants
//
//	Constant declarations.
//
//	Mac:	Make sure to set the init entry-point to __initialize
//
//	Magnus EH Pedersen
//
//....................................................................................................................................................................................

#pragma once

#include <cmath>
#include <limits.h>

namespace Yggdrasil
{
//	const double			kAbsZero = 5e-11;				// Absolute zero
	const double			kAbsZero = 0;					// Absolute zero

	const double			kPi = 2*std::acos((double) 0);	// pi
	const double			kPi2 = 2*kPi;					// 2*pi

	const double			kE = std::exp((double)1);

	const double			kRMSTimeConst = 0.0001;

	const double			kOneF = (double) 1.0;
	const bool				kFalse = false;

	const double			kShort2double = 1.0/SHRT_MAX;
	const double			kdouble2Short = SHRT_MAX;

	const double			kULong2Double = 1.0/ULONG_MAX;
	const double			kLong2Double = 1.0/LONG_MAX;

} //end namespace Yggdrasil
