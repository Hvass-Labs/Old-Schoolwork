//....................................................................................................................................................................................
//
//	Copyright (C) 2001-2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LFilterIIR
//
//	Implements the general Infinite Impulse Response (IIR) filter, which computes:
//
//	y[n] = a0 * x[n] + a1 * x[n-1] + a2 * x[n-2] + ...
//                   + b1 * y[n-1] + b2 * y[n-2] + ...
//
//	Where y is the output sequence, and x is the input sequence. The class supports
//	arbitrary datatypes for these sequences, and meta-programming is used to obtain
//	flattening of the summation 'loops'. The template-arguments are as follows:
//
//		T is the datatype for the input/output.
//		U is the datatype for the coefficients.
//		kNumX is the number of input samples used.
//		kNumY is the number of output samples used.
//
//	We can assume that both kNumX and kNumY are greater than or equal 1, otherwise
//	it is not an IIR filter!
//
//....................................................................................................................................................................................

#pragma once

#include "LCircularBuffer.h"
#include "DotProductFlat.h"

namespace DSP
{
//....................................................................................................................................................................................
template <class T, typename U, int kNumY, int kNumX>
class	LFilterIIR
{
public:
	LFilterIIR							(T const& init) : mX(init), mY(init) {}

	// Process one input-sample and return a reference to the output-sample.
	// The input can be any expression that evaluates to type T in an assignment.
	// This assignment for x, is carried out only once, inside the push_peek()
	// function of LCircularBuffer. Similarly, the computation of the output is
	// also carried out only once, inside the push_peek() function of LCircularBuffer.
	template <class Exp>
	inline T const&		operator()		(Exp const& x)
	{
		return mY.push_peek( GetA0() * mX.push_peek(x)
									+ DotProductFlat<kNumX-1, T>(mA, mX)
									+ DotProductFlat<kNumY,   T>(mB, mY) );
	}

protected:
	// Return the filter coefficient for the current input sample x[n].
	inline U const&		GetA0			() const { return mA[kNumX-1]; }

	// Set the filter coefficient a[i], with 1 <= i <= kNumX-1.
	template <unsigned int i>
	inline void			SetA			(U const& a) { assert(i<kNumX); mA[i-1] = a; }

	// Set the filter coefficient a[0].
	template <>
	inline void			SetA<0>			(U const& a) { mA[kNumX-1] = a; }

	// Set the filter coefficient a[i], with 1 <= i <= kNumY
	template <unsigned int i>
	inline void			SetB			(U const& b) { assert(i<=kNumY); mB[i-1] = b; }

	// Set the filter coefficient b[0].
	template <>
	inline void			SetB<0>			(U const& b) { throw; } // Error!

protected:
	Yggdrasil::LCircularBuffer<T, kNumX-1>	mX;		// Previous input.
	Yggdrasil::LCircularBuffer<T, kNumY>	mY;		// Previous output.

	U				mA[kNumX];		// Coefficients for input.
	U				mB[kNumY];		// Coefficients for output.
};
//....................................................................................................................................................................................
} //end namespace DSP
