//....................................................................................................................................................................................
//
//	Copyright (C) 2001-2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LFilterIIR_BR1
//
//	???
//
//....................................................................................................................................................................................

#pragma once

#include "LFilterIIR_BP1.h"

namespace DSP
{
//....................................................................................................................................................................................
template <class T, typename U>
class	LFilterIIR_BR1 : public LFilterIIR_BP1<T, U>
{
public:
	LFilterIIR_BR1						(T& init) : LFilterIIR_BP1<T, U>(init) {}

	// Set the cutoff and bandwidth/slope of the filter, c and s are [0, 1/2].
	template <class Exp1, class Exp2>
	void				SetParameters	(Exp1 const& c, Exp2 const& s)
	{
		U r, rSquared, cosFreq2, k;
		CalcConstants(c, s, r, rSquared, cosFreq2, k);

		SetA<0>( k );
		SetA<1>( -cosFreq2 );
		SetA<2>( k );

		SetB<1>( r * cosFreq2 );
		SetB<2>( -rSquared );
	}
};
//....................................................................................................................................................................................
} //end namespace DSP
