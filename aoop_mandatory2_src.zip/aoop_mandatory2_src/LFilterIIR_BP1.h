//....................................................................................................................................................................................
//
//	Copyright (C) 2001-2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LFilterIIR_BP1
//
//	???
//
//....................................................................................................................................................................................

#pragma once

#include "LFilterIIR.h"
#include "YggConstants.h"
#include <cmath>

namespace DSP
{
//....................................................................................................................................................................................
template <class T, typename U>
class	LFilterIIR_BP1 : public LFilterIIR<T, U, 2, 3>
{
public:
	LFilterIIR_BP1						(T& init) : LFilterIIR<T, U, 2, 3>(init) {}

	// Set the cutoff and bandwidth/slope of the filter, c and s are [0, 1/2].
	template <class Exp1, class Exp2>
	void				SetParameters	(Exp1 const& c, Exp2 const& s)
	{
		U r, rSquared, cosFreq2, k;
		CalcConstants(c, s, r, rSquared, cosFreq2, k);

		SetA<0>( 1-k );
		SetA<1>( (k-r) * cosFreq2 );
		SetA<2>( rSquared - k );

		SetB<1>( r * cosFreq2 );
		SetB<2>( -rSquared );
	}

protected:
	template <class Exp1, class Exp2>
	void				CalcConstants	(Exp1 const& c, Exp2 const& s, U& r, U& rSquared, U& cosFreq2, U& k)
	{
		r = 1 - 3*s;
		rSquared = r * r;
		cosFreq2 = 2 * std::cos(Yggdrasil::kPi2 * c);
		k = (1 - r * cosFreq2 + rSquared) / (2 - cosFreq2);
	}
};
//....................................................................................................................................................................................
} //end namespace DSP
