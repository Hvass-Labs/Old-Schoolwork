//....................................................................................................................................................................................
//
//	Copyright (C) 2001-2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	ArrayOpsMeta
//
//	Basic data-structures used in facilitating socalled template meta-programming
//	of numerical arrays/vectors. Combined with LVector.h and LVectorMini.h this
//	allows one to use simple notation for vector-arithmetics, e.g.: A = B + C;
//	where A, B, and C are all vectors of some length and of some arbitrary datatype T.
//	This implementation only features the addition operator, but others are implemented
//	analogously.
//
//	Recall that a struct in C++ is simply a class whose members are all public.
//
//....................................................................................................................................................................................

#pragma once

#include <functional>

namespace ArrayOps
{
//....................................................................................................................................................................................

// The abstract representation of an expression.
template <typename T, class S>
class Expression : public S
{
public:
	Expression () : S() {}
};

//....................................................................................................................................................................................

// The class holding a binary expression.
template <typename T, class L, class Op, class R>
class BinExp 
{
public:
	BinExp() : mL(0), mR(0) {}

	inline T operator[] (unsigned int index)
	{
		assert (mL && mR);

		// Create operator function-object.
		Op op;

		// Apply operator and return result.
		return op((*mL)[index], (*mR)[index]);
	};

	void Set(L* l, R* r)
	{
		// Set the left- and right-hand expressions.
		mL = l;
		mR = r;
	}

	L*  mL;		// Left expression.
	R*  mR;		// Right expression.
};

// The class of a binary expression.
template <typename T, class L, class Op, class R>
class BinaryExpression : public Expression<T, BinExp<T, L, Op, R> >
{
public:
	BinaryExpression(L& l, R& r) : Expression<T, BinExp<T, L, Op, R > >()
	{
		BinExp<T, L, Op, R>::Set(&l, &r);
	}
};
//....................................................................................................................................................................................
// The operator overloadings used for iteratively creating new expressions out of others.

template <typename T, class S1, class S2>
BinaryExpression<T, Expression<T, S1>,
					std::plus<T>,
					Expression<T, S2> >
operator+(Expression<T, S1>& l, Expression<T, S2>& r)
{
	return BinaryExpression<T, Expression<T, S1>,
								std::plus<T>,
								Expression<T, S2> >(l, r);
};

template <typename T, class S1, class S2>
BinaryExpression<T, Expression<T, S1>,
					std::multiplies<T>,
					Expression<T, S2> >
operator*(Expression<T, S1>& l, Expression<T, S2>& r)
{
	return BinaryExpression<T, Expression<T, S1>,
								std::multiplies<T>,
								Expression<T, S2> >(l, r);
};
//....................................................................................................................................................................................
} //end namespace ArrayOps
