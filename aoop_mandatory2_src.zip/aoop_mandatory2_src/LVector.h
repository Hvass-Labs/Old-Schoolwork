//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LVector
//
//	Data-structure used for storing arbitrarily large and resizable vectors, while
//	providing template functions supporting the meta-programming of ArrayOpsMeta.h,
//	so that one may use simple notation such as: A = B + C; where A, B, and C are
//	vectors with elements of some type T, and with high performance (depending on
//	compiler).
//
//	The actual storage is by way of std::vector<T>, whose operations can also be
//	used as normal.
//
//	The expression is evaluated only on assignment, and as this version uses a for-loop
//	to run through the elements, it is recommend only for larger vectors (say, more than
//	8 or perhaps 16 elements, depending on the machine in question). Otherwise use
//	LVectorMini.
//
//	Support is also implemented for combining instances of LVector and LVectorMini in
//	arithmetic expressions. The programmer is assumed to keep track on whether the
//	vector-sizes match, as this checking is not done automatically in the classes.
//
//....................................................................................................................................................................................

#pragma once

#include "ArrayOpsMeta.h"
#include "LVectorMini.h"
#include <vector>

namespace ArrayOps
{
//....................................................................................................................................................................................
template <class T>
class	LVector : public std::vector<T>
{
public:
	LVector					(unsigned int size=0) : std::vector<T>(size) {}

	// Assignment from any kind of data-structure or expression supporting operator[] lookup.
	template <class Expr> inline
	LVector& operator=		(Expr& x)
	{
		int i = 0;

		for (iterator itor = begin(); itor != end(); itor++, i++)
		{
			*itor = x[i];
		}

		return *this;
	}
};
//....................................................................................................................................................................................

// Template functions that along with ArrayOpsMeta.h facilitate
// meta-programming of LVector.

template <typename T>
Expression<T, LVector<T>, OpPlus<T>, LVector<T> >
operator+(LVector<T>& l, LVector<T>& r)
{
	return Expression<T, LVector<T>, OpPlus<T>, LVector<T> >(l, r);
};

template <typename T, class Expr>
Expression<T, LVector<T>, OpPlus<T>, Expr>
operator+(LVector<T>& l, Expr& r)
{
	return Expression<T, LVector<T>, OpPlus<T>, Expr>(l, r);
};

template <typename T, class Expr>
Expression<T, Expr, OpPlus<T>, LVector<T> >
operator+(Expr& l, LVector<T>& r)
{
	return Expression<T, Expr, OpPlus<T>, LVector<T> >(l, r);
};
//....................................................................................................................................................................................

// Template functions that along with ArrayOpsMeta.h facilitate
// combined meta-programming of LVector and LVectorMini.

template <typename T, unsigned int kSize>
Expression<T, LVector<T>, OpPlus<T>, LVectorMini<T,kSize> >
operator+(LVector<T>& l, LVectorMini<T,kSize>& r)
{
	return Expression<T, LVector<T>, OpPlus<T>, LVectorMini<T,kSize> >(l, r);
};

template <typename T, unsigned int kSize>
Expression<T, LVectorMini<T,kSize>, OpPlus<T>, LVector<T> >
operator+(LVectorMini<T,kSize>& l, LVector<T>& r)
{
	return Expression<T, LVectorMini<T,kSize>, OpPlus<T>, LVector<T> >(l, r);
};
//....................................................................................................................................................................................
} //end namespace ArrayOps
