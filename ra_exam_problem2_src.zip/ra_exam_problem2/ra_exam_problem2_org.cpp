// ra_exam_problem2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "random.h"
#include <cmath>
#include <cassert>

Yggdrasil::LYggRandom2 gRandom(1234567);

int			gMaxN;				// Maximum number of questions.
const int	kR = 2996;			// Number of simulations for each 'n'.

void GetRandomSeed()
{
	long seed;

	std::cout << "Random seed: ";
	std::cin >> seed;

	gRandom.Initialize(seed);
}

void GetParameters()
{
	std::cout << "Maximum number of questions (denoted n): ";
	std::cin >> gMaxN;
}

// Return the score for a test with 'n' questions, 'm' guesses, of which 'X' were answered correctly.
int GetScore(int n, int m, int X)
{
	// A correct answer scores 2 points.
	// A wrong answer scores -1 point.
	return 2*(n-m) + 3*X - m;
}

int SimulateX(int m)
{
	int X = 0;

	for (int i=0; i<m; i++)
	{
		if (gRandom.RandUni() < 0.25)
			X++;
	}

	return X;
}

int SimulateY(int n, int m)
{
	int Yn = 0;

	for (int i=0; i<kR; i++)
	{
		int X = SimulateX(m);
		int score = GetScore(n, m, X);

		if (score >= n)
			Yn++;
	}

	return Yn;
}

int _tmain(int argc, _TCHAR* argv[])
{
	std::cout << "Randomized Algorithms - Takehome Exam 2005, Problem 2.\nMagnus Pedersen (u971055@daimi.au.dk)" << std::endl << std::endl;

	GetRandomSeed();
	GetParameters();

	std::cout << std::endl;

	double ratio = 1;

	for (int i=1; i<=gMaxN && ratio>0.04; i++)
	{
		int m = std::ceil(3*i/5.0);
		int Yn = SimulateY(i, m);
		ratio = (double)Yn/kR;

		std::cout << "n=" << i << ", m=" << m << "\tStudents passed: " << Yn << " of R=" << kR << " (ratio: " << ratio << ")" << std::endl;
	}

	return 0;
}

