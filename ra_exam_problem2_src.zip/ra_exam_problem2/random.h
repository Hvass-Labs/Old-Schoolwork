#pragma once

#include "LYggRandom2.h"

extern Yggdrasil::LYggRandom2 gRandom;
