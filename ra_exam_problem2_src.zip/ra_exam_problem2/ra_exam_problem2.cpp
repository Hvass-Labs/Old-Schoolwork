// ra_exam_problem2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "random.h"
#include <cmath>
#include <cassert>

Yggdrasil::LYggRandom2 gRandom(1234567);

const int	kR = 2996;			// Number of simulations for each 'n'.
int			gK;					// Number of choices for a question.
double		gKReciprocal;		// 1.0/k
double		gScore;				// log2(gK), i.e. logarithm with base-2 to gK.

void GetRandomSeed()
{
	long seed;

	std::cout << "Random seed: ";
	std::cin >> seed;

	gRandom.Initialize(seed);
}

void GetParameters()
{
	std::cout << "Number of choices per question (denoted k >= 2): ";
	std::cin >> gK; assert(gK>=2);
}

// Return the score for a test with 'n' questions, 'm' guesses, of which 'X' were answered correctly.
double GetScore(int n, int m, int X)
{
	// A correct answer scores gScore points.
	// A wrong answer scores -1 point.
	return gScore*(n-m) + (gScore+1)*X - m;
}

int SimulateX(int m)
{
	int X = 0;

	for (int i=0; i<m; i++)
	{
		if (gRandom.RandUni() < gKReciprocal)
			X++;
	}

	return X;
}

double Chernoff()
{
	double deltaPlusOne = gK * (gScore/6 + 1) / (gScore + 1);
	double delta = deltaPlusOne - 1;
	double gamma = std::exp(delta) / std::pow(deltaPlusOne, deltaPlusOne);

	return (5 * gK / 3.0) * std::log(0.05) / std::log(gamma);
}

int SimulateY(int n, int m)
{
	int Yn = 0;
	double passScore = gScore * 0.5 * n;

	for (int i=0; i<kR; i++)
	{
		int X = SimulateX(m);
		double score = GetScore(n, m, X);

		if (score >= passScore)
			Yn++;
	}

	return Yn;
}

int _tmain(int argc, _TCHAR* argv[])
{
	std::cout << "Randomized Algorithms - Takehome Exam 2005, Problem 2.\nMagnus Pedersen (u971055@daimi.au.dk)" << std::endl << std::endl;

	GetRandomSeed();
	GetParameters();

	// Compute score.
	gKReciprocal = 1.0/gK;
	gScore = std::log((double)gK)/std::log(2.0);

	double chernoff = Chernoff();
	int maxN = std::ceil(chernoff);
	std::cout << "Chernoff bound: " << chernoff << std::endl;
	std::cout << std::endl;

	double ratio = 1;

	for (int i=1; i<=maxN && ratio>0.04; i++)
	{
		int m = std::ceil(3*i/5.0);
		int Yn = SimulateY(i, m);
		ratio = (double)Yn/kR;

		std::cout << "n=" << i << ", m=" << m << "\tStudents passed: " << Yn << " of R=" << kR << " (ratio: " << ratio << ")" << std::endl;
	}

	return 0;
}

