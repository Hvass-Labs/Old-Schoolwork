//....................................................................................................................................................................................
//
//	Copyright�2001 by Thurs. All rights reserved.
//
//	UYggClip
//
//	Use this for keeping a value within a given range, also known
//	as saturation or hard-clipping.
//
//	An alternative way would be: y = max(min(x, ceiling), floor)
//	This is much slower though.
//
//	Magnus EH Pedersen
//
//....................................................................................................................................................................................

#pragma once

namespace Yggdrasil
{

// return value clipped to floor and ceiling
template <class T> inline T UYggClip(T value, T floor, T ceiling) { return (value<floor) ? (floor) : ((value>ceiling) ? (ceiling) : (value)); }

} //end namespace Yggdrasil
