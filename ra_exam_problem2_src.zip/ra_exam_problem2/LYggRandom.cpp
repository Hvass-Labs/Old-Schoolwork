//__________________________________________________________________________________________
//
//	Copyright (C) 2003-2005 by Thurs. All rights reserved.
//
//	LYggRandom
//
//	Magnus EH Pedersen
//
//__________________________________________________________________________________________

#include "LYggRandom.h"
#include <limits.h>
#include <math.h>

namespace Yggdrasil
{

//__________________________________________________________________________________________
LYggRandom::LYggRandom			() :
mGaussianPending(false)
{
}
//__________________________________________________________________________________________
double
LYggRandom::DoGaussian			()
{
	double retVal;

	if (mGaussianPending)
	{
		retVal = mGaussian;
		mGaussianPending = false;
	}
	else
	{
		double v1, v2, rsq;

		do
		{
			v1 = RandBi();					// pick two uniform numbers in the square extending from -1 to +1 in each direction
			v2 = RandBi();
			rsq = v1*v1 + v2*v2;			// see if they are in the unit circle,
		}
		while (rsq >= 1.0 || rsq == 0.0);	// and if they are not, try again.

		double fac=sqrt(-2.0 * std::log(rsq)/rsq);

		// Now make the Box-Muller transformation to get two normal deviates.
		// Return one and save the other for next time.
		mGaussian = v1*fac;
		mGaussianPending = true;	// Set flag.

		retVal = v2 * fac;
	}

	return retVal;
}
//__________________________________________________________________________________________
} //end namespace Yggdrasil
