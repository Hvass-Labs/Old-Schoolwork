//__________________________________________________________________________________________
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LPoissonMPI
//
//__________________________________________________________________________________________

#include "LPoissonMPI.h"
#include "mpi.h"
#include <cassert>
#include <cstdlib>
#include <algorithm>

namespace Poisson
{
//__________________________________________________________________________________________
LPoissonMPI::LPoissonMPI				(int N, int P, int rank) :
kP(P),
kRank(rank),
kUpNeighbour((rank == P-1) ? (MPI_PROC_NULL) : (rank+1)),
kDownNeighbour((rank == 0) ? (MPI_PROC_NULL) : (rank-1))
{
	assert(rank>=0 && rank<P);
	assert(P>=0 && P<=N);

	// Calculate the height of the sub-grid for each MPI node.
	std::div_t div_result = std::div(N, P);
	int height = div_result.quot;

	// Ensure the computational burden is evenly distributed.
	if (div_result.rem != 0)
	{
		height++;
	}

	// Grid is split into sub-grids of width N and height
	// approximately N/P. That is, the first P-1 nodes have
	// height std::ceil(N/P), and the last node has a sub-grid
	// of height N-(P-1)*std::ceil(N/P).
	int offsetM = rank*height;
	int sizeM = std::min(N-offsetM, height);
	int offsetN = 0;
	int sizeN = N;

	// Create a Poisson sub-grid of this size and offset.
	mPoisson = new LPoisson(N, sizeM, offsetM, sizeN, offsetN);
}
//__________________________________________________________________________________________
LPoissonMPI::~LPoissonMPI				()
{
	delete mPoisson;
}
//__________________________________________________________________________________________
void
LPoissonMPI::Iterate					()
{
	assert(mPoisson);

	mPoisson->Iterate();
	Communicate();
}
//__________________________________________________________________________________________
void
LPoissonMPI::Communicate				()
{
	assert(mPoisson);

	// Conveniece variables and constants from Poisson-object.
	double** u = mPoisson->mU;
	const int N = mPoisson->kN;
	const int offset = mPoisson->kOffsetM;
	const int height = mPoisson->kSizeM;

	// Status-information for MPI.
	MPI_Status status;

	// Send up, receive from below.
	MPI_Sendrecv(	u[height]+1, N, MPI_DOUBLE, kUpNeighbour, 0,
					u[0]+1, N, MPI_DOUBLE, kDownNeighbour, 0,
					MPI_COMM_WORLD, &status);

	// Send down, receive from above.
	MPI_Sendrecv(	u[1]+1, N, MPI_DOUBLE, kDownNeighbour, 0,
					u[height+1]+1, N, MPI_DOUBLE, kUpNeighbour, 0,
					MPI_COMM_WORLD, &status);
}
//__________________________________________________________________________________________
void
LPoissonMPI::OutputGnuPlot				(std::ostream& out) const
{
	assert(mPoisson);

	mPoisson->OutputGnuPlot(out);
}
//__________________________________________________________________________________________
} //end namespace Poisson
