//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LPoissonMPI
//
//	Implements support for distributing the computation of a single iteration of the
//	2D-Poisson problem using the LPoisson-class. Distribution is done through the
//	Message Passing Interface (MPI).
//
//	Assumes the number of processing nodes P, is less than or equal to the grid-size N.
//	This version of LPoissonMPI splits the grid into sub-grids of width N and height M.
//	That is, the grid is block-decomposed row-wise, which makes communication between
//	nodes easy, as we may use the arrays from LPoisson directly, and without any intermediate
//	buffering, as would have been required for column-wise block-decomposition.
//
//	If P does not divide N, then M = std::ceil(N/P), that is, M is rounded up, so as to
//	even out the computational burden amongst the nodes. Otherwise the last node could
//	(in the worst case) have M = std::floor(N/P) + (P-1).
//
//....................................................................................................................................................................................

#pragma once

#include "LPoisson.h"
#include <ostream>

namespace Poisson
{

//....................................................................................................................................................................................
class	LPoissonMPI
{
public:
	LPoissonMPI								(int N,			// Grid-size.
											 int P,			// Number of nodes.
											 int rank);		// Rank of this node {0, .., P-1}.

	virtual ~LPoissonMPI					();

	// Perform a single Gauss-Seidel iteration of the sub-grid and communicate results.
	void				Iterate				();

	// Outputs grid-values in a format readable by GnuPlot and the splot command.
	void				OutputGnuPlot		(std::ostream& out) const;

protected:
	// Communicate boundaries to up- and down-wards neighbours.
	void				Communicate			();

protected:
	LPoisson*			mPoisson;		// Poisson-solver for sub-grid.

	const int			kP;				// Number of nodes.
	const int			kRank;			// This node's rank.
	const int			kUpNeighbour;	// Rank of up-neighbour.
	const int			kDownNeighbour;	// Rank of down-neighbour.
};
//....................................................................................................................................................................................
} //end namespace Poisson
