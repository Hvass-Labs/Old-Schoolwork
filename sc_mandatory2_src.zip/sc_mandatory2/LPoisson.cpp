//__________________________________________________________________________________________
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LPoisson
//
//__________________________________________________________________________________________

#include "LPoisson.h"
#include "DoubleArray.h"
#include <cmath>
#include <cassert>
#include <algorithm>

namespace Poisson
{

//__________________________________________________________________________________________
LPoisson::	LPoisson				(int N,
									 int sizeM, int offsetM,	// Column size and offset.
									 int sizeN, int offsetN) :	// Row size and offset.
kN(N),
kSizeN(sizeN),
kSizeM(sizeM),
kOffsetM(offsetM),
kOffsetN(offsetN),
kDelta2(1.0/(double)(N*N)),
kMappingFactor(2.0/(double)(N+1))
{
	assert(N>0);
	assert(sizeN>=1 && sizeN<=N);
	assert(sizeM>=1 && sizeM<=N);
	assert(offsetN>=0 && offsetN+sizeN<=N);
	assert(offsetM>=0 && offsetM+sizeM<=N);
	assert(kDelta2>0);

	// Allocate double-array for storing numerical 2D-solution.
	mU = ArrayOps::AllocateDoubleArray<double>(kSizeM+2, kSizeN+2);

	// Initialize double-array with boundaries and first solution.
	InitSolution();
	InitBoundaries();
}
//__________________________________________________________________________________________
LPoisson::~LPoisson					()
{
	ArrayOps::DeleteDoubleArray<double>(mU, kSizeM+2);
}
//__________________________________________________________________________________________
void
LPoisson::InitBoundaries			()
{
	// Boundary conditions.
	// These could instead be defined by sub-class.
	const double bottom = 0;
	const double top = 20;
	const double left = 20;
	const double right = 20;

	// Bottom boundary.
	if (kOffsetM == 0)
	{
		#pragma omp parallel for
		for (int j=0; j<=kSizeN+1; j++)
		{
			SetU(kSizeM+1, j, bottom);
		}
	}

	// Top boundary.
	if (kOffsetM+kSizeM == kN)
	{
		#pragma omp parallel for
		for (int j=0; j<=kSizeN+1; j++)
		{
			SetU(kSizeM+1, j, top);
		}
	}

	// Left boundary.
	if (kOffsetN == 0)
	{
		#pragma omp parallel for
		for (int i=0; i<=kSizeM+1; i++)
		{
			SetU(i, 0, left);
		}
	}

	// Right boundary.
	if (kOffsetN+kSizeN == kN)
	{
		#pragma omp parallel for
		for (int i=0; i<=kSizeM+1; i++)
		{
			SetU(i, kSizeN+1, right);
		}
	}
}
//__________________________________________________________________________________________
void
LPoisson::InitSolution				()
{
	// Initialize solution to zero, as we do not assume
	// any special knowledge about the given problem.
	// Note that boundary is also initialized, which is
	// needed when computation is distributed (see e.g.
	// LPoissonMPI).

	#pragma omp parallel for
	for (int i=0; i<=kSizeM+1; i++)
	{
		for (int j=0; j<=kSizeN+1; j++)
		{
			SetU(i, j, 0);
		}
	}
}
//__________________________________________________________________________________________
void
LPoisson::Iterate					()
{
	DoIterate(1, kSizeN);
}
//__________________________________________________________________________________________
void
LPoisson::Iterate					(int blockWidth)
{
	assert(blockWidth>=1);
	blockWidth = std::min(blockWidth, kSizeN);

	#pragma omp parallel for
	for (int J1=1; J1<=kSizeN; J1+=blockWidth)
	{
		int J2 = std::min<int>(J1+blockWidth-1, kSizeN);

		DoIterate(J1, J2);
	}
}
//__________________________________________________________________________________________
void
LPoisson::DoIterate					(const int J1, const int J2)
{
	#pragma omp parallel for
	for (int i=1; i<=kSizeM; i++)
	{
		double y = MapIndexI2Y(i);

		DoIterateRow(i, y, J1, J2);
	}
}
//__________________________________________________________________________________________
void
LPoisson::DoIterateRow				(const int i, const double y, const int J1, const int J2, const int stride)
{
	assert(J1>=1 && J1<=J2 && J2 <=kSizeN);
	assert(stride>=1);

	for (int j=J1; j<=J2; j+=stride)
	{
		double x = MapIndexJ2X(j);
		double u = CalcU(x, y, i, j);

		SetU(i, j, u);
	}
}
//__________________________________________________________________________________________
void
LPoisson::IterateRedBlack			()
{
	DoIterateRedBlack(1, kSizeM, 1, kSizeN);
}
//__________________________________________________________________________________________
void
LPoisson::IterateRedBlack			(int blockWidth, int blockHeight)
{
	assert(blockWidth>=1);
	assert(blockHeight>=1);

	blockWidth = std::min(blockWidth, kSizeN);
	blockHeight = std::min(blockHeight, kSizeM);

	#pragma omp parallel for
	for (int J1=1; J1<=kSizeN; J1+=blockWidth)
	{
		int J2 = std::min<int>(J1+blockWidth-1, kSizeN);

		for (int I1=1; I1<=kSizeM; I1+=blockHeight)
		{
			int I2 = std::min<int>(I1+blockHeight-1, kSizeM);

			DoIterateRedBlack(I1, I2, J1, J2);
		}
	}
}
//__________________________________________________________________________________________
void
LPoisson::DoIterateRedBlack			(const int I1, const int I2, const int J1, const int J2)
{
	assert(I1>=1 && I1<=I2 && I2 <=kSizeM);
	assert(J1>=1 && J1<=J2 && J2 <=kSizeN);

	#pragma omp parallel
	{
		#pragma omp for
		for (int i=I1; i<=I2; i++)
		{
			double y = MapIndexI2Y(i);

			DoIterateRow(i, y, J1+(i+1)%2, J2, 2);
		}

		#pragma omp for
		for (int i=I1; i<=I2; i++)
		{
			double y = MapIndexI2Y(i);

			DoIterateRow(i, y, J1+i%2, J2, 2);
		}
	} /* end omp parallel */
}
//__________________________________________________________________________________________
double
LPoisson::f							(double x, double y) const
{
	assert(std::fabs(x) < 1);
	assert(std::fabs(y) < 1);

	return (std::fabs(x) <= 1.0/3.0 && -2.0/3.0 <= y && y <= -1.0/3.0) ? (200) : (0);
}
//__________________________________________________________________________________________
double
LPoisson::CalcU						(double x, double y, int i, int j) const
{
	return 0.25 * (	GetU(i, j-1) +
					GetU(i, j+1) +
					GetU(i-1, j) +
					GetU(i+1, j) +
					kDelta2 * f(x, y) );
}
//__________________________________________________________________________________________
double
LPoisson::GetU						(int i, int j) const
{
	assert(i>=0 && i<=kSizeM+1);
	assert(j>=0 && j<=kSizeN+1);

	return mU[i][j];
}
//__________________________________________________________________________________________
void
LPoisson::SetU						(int i, int j, double u)
{
	assert(i>=0 && i<=kSizeM+1);
	assert(j>=0 && j<=kSizeN+1);

	mU[i][j] = u;
}
//__________________________________________________________________________________________
double
LPoisson::MapIndexI2Y				(int i) const
{
	// If index+offset==0 Then retVal == -1.
	// If index+offset==N+1 Then retVal == 1.
	// This means retVal = (index+offset)*2/(N+1)-1.

	assert(i>=0 && i+kOffsetM<=kN+1);

	double retVal = (i+kOffsetM)*kMappingFactor-1;

	assert(retVal>=-1 && retVal<=1);

	return retVal;
}
//__________________________________________________________________________________________
double
LPoisson::MapIndexJ2X				(int j) const
{
	// If index+offset==0 Then retVal == -1.
	// If index+offset==N+1 Then retVal == 1.
	// This means retVal = (index+offset)*2/(N+1)-1.

	assert(j>=0 && j+kOffsetN<=kN+1);

	double retVal = (j+kOffsetN)*kMappingFactor-1;

	assert(retVal>=-1 && retVal<=1);

	return retVal;
}
//__________________________________________________________________________________________
void
LPoisson::OutputGnuPlot				(std::ostream& out) const
{
	for (int i=0; i<=kSizeM+1; i++)
	{
		for (int j=0; j<=kSizeN+1; j++)
		{
			double x = MapIndexJ2X(j);
			double y = MapIndexI2Y(i);
			double u = GetU(i, j);

			out << x << " " << y << " " << u << "\n";
		}
	}
}
//__________________________________________________________________________________________
} //end namespace Poisson
