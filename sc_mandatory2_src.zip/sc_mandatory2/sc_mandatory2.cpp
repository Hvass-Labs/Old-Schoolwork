// sc_mandatory2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "LPoisson.h"
#include <fstream>
#include <string>

// Wall-clock routines for non-OpenMP and OpenMP.
#ifdef _OPENMP

#include <omp.h>
typedef double TTime;

TTime GetClock()
{
	return omp_get_wtime();
}

double TimeDiff_Seconds(TTime beginTime, TTime endTime)
{
	return endTime-beginTime;
}

#else // Not OpenMP.

#include <ctime>
typedef std::clock_t TTime;

TTime GetClock()
{
	return std::clock();
}

double TimeDiff_Seconds(TTime beginTime, TTime endTime)
{
	return (double)(endTime-beginTime)/1000;
}
#endif

// Parameters.
int				gN = 0;						// Grid-size.
int				gNumIterations = 0;			// Number of iterations.
bool			gMustOutput = false;		// Output result to a file?
std::string		gOutputFilename;			// Filename for that output.
bool			gUseRedBlack;				// Use Red-Black iteration.
bool			gUseBlockHeight = false;	// Use non-default block-height.
bool			gUseBlockWidth = false;		// Use non-default block-width.
int				gBlockHeight;				// Block-height.
int				gBlockWidth;				// Block-width.

bool GetParameters(int argc, _TCHAR* argv[])
{
	bool hasN = false;
	bool hasNumIterations = false;

	for (int i=1; i<argc; i++)
	{
		std::string arg(argv[i]);

		if (i<argc-1 && (arg == "-n" || arg == "-N"))
		{
			// Grid-size.
			gN = atoi(argv[i+1]);
			i++;
			hasN = true;

			std::cout << "Grid-size (excl. boundaries): " << gN << std::endl;
		}
		else if (i<argc-1 && (arg == "-k" || arg == "-K"))
		{
			// Number of iterations to perform.
			gNumIterations = atoi(argv[i+1]);
			i++;
			hasNumIterations = true;

			std::cout << "Number of iterations: " << gNumIterations << std::endl;
		}
		else if (i<argc-1 && (arg == "-o" || arg == "-O"))
		{
			// Output-file.
			gMustOutput = true;
			gOutputFilename = argv[i+1];
			i++;

			std::cout << "Output to file with name: " << gOutputFilename << std::endl;
		}
		else if (i<argc-1 && (arg == "-w" || arg == "-W"))
		{
			// Block-width.
			gBlockWidth = atoi(argv[i+1]);
			i++;
			gUseBlockWidth = true;

			std::cout << "Block-width set to: " << gBlockWidth << std::endl;
		}
		else if (i<argc-1 && (arg == "-h" || arg == "-H"))
		{
			// Block-height.
			gBlockHeight = atoi(argv[i+1]);
			i++;
			gUseBlockHeight = true;

			std::cout << "Block-height set to: " << gBlockHeight << std::endl;
		}
		else if (arg == "-r" || arg == "-R")
		{
			// Enable red-black iteration
			gUseRedBlack = true;

			std::cout << "Red-Black iteration enabled." << std::endl;
		}
	}

	bool retVal;

	if (hasN && hasNumIterations)
	{
		// Arguments appear OK, now set the default parameters.

		if (!gUseBlockHeight)
		{
			gBlockHeight = gN;
		}

		if (!gUseBlockWidth)
		{
			gBlockWidth = gN;
		}

		retVal = true;
	}
	else
	{
		// Arguments are erroneous, print help-message.

		std::cout << "poisson -n <int> -k <int> [-o <outfile>] [-r] [-w <int>] [-h <int>]\n";
		std::cout << "-n is the grid-size.\n";
		std::cout << "-k is the number of iterations.\n";
		std::cout << "-o is the optional output filename.\n";
		std::cout << "-r enables Red-Black iteration.\n";
		std::cout << "-w is the block-width (defaults to grid-size).\n";
		std::cout << "-h is the block-height (Red-Black only, and defaults to grid-size).\n";
		std::cout << std::endl;

		retVal = false;
	}

	return retVal;
}

using namespace Poisson;

int _tmain(int argc, _TCHAR* argv[])
{
	bool parametersOK = GetParameters(argc, argv);

	if (parametersOK)
	{
		LPoisson poisson(gN, gN, 0, gN, 0);
		TTime beginTime, endTime;

		std::cout << "Processing .. ";

		if (gUseRedBlack)
		{
			// Red-Black iteration.

			if (gUseBlockWidth || gUseBlockHeight)
			{
				// Block-decomposed iteration.

				beginTime = GetClock();

				for (int i=0; i<gNumIterations; i++)
				{
					poisson.IterateRedBlack(gBlockWidth, gBlockHeight);
				}

				endTime = GetClock();
			}
			else
			{
				// Non block-decomposed iteration.

				beginTime = GetClock();

				for (int i=0; i<gNumIterations; i++)
				{
					poisson.IterateRedBlack();
				}

				endTime = GetClock();
			}
		}
		else
		{
			// Normal Gauss-Seidel iteration.

			if (gUseBlockWidth)
			{
				// Block-decomposed iteration.

				beginTime = GetClock();

				for (int i=0; i<gNumIterations; i++)
				{
					poisson.Iterate(gBlockWidth);
				}

				endTime = GetClock();
			}
			else
			{
				// Non block-decomposed iteration.

				beginTime = GetClock();

				for (int i=0; i<gNumIterations; i++)
				{
					poisson.Iterate();
				}

				endTime = GetClock();
			}
		}

		std::cout << "done in " << TimeDiff_Seconds(beginTime, endTime) << " secs." << std::endl;

		if (gMustOutput)
		{
			std::ofstream fout(gOutputFilename.c_str());
			poisson.OutputGnuPlot(fout);
			fout.close();
		}
	}

	return 0;
}

