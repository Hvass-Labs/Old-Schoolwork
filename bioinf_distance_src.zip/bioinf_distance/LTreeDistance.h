//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LTreeDistance
//
//	??? Used for.
//
//....................................................................................................................................................................................

#pragma once

#include "LSpeciesTree.h"
#include <vector>
#include <string>

namespace BioInf
{

//....................................................................................................................................................................................
class	LTreeDistance
{
	friend class LSpeciesTree;

public:
	LTreeDistance								(LSpeciesTree &T, LSpeciesTree &S);
	virtual ~LTreeDistance						();

	// Return the distance between the two trees T and S.
	int					Distance				();

private:
	// Return the distance between subtrees rooted by edges e and f in trees T and S respectively.
	int					GetDistance				(int e, int f);

	// Memory allocation/deallocation with exception handling.
	void				DoAllocate				();
	void				DoDelete				();

private:
	int						**mK;			// Table counting common species between sub-trees of mT and mS.

	LSpeciesTree			&mT, &mS;		// The two species-trees.
};
} //end namespace BioInf
