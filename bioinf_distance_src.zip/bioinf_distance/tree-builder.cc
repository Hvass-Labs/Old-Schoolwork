// Copyright (C) 2003 by BiRC -- Bioinformatics Research Center
//                               University of Aarhus, Denmark
//                               Contact: Thomas Mailund <mailund@birc.dk>
//                                    or: Christian Storm <cstorm@birc.dk>
// Modified 2005 by Magnus EH Pedersen

#include "tree-builder.hh"


void
TreeBuilder::push_internal()
{
	int u = create_inner();

	if (_stack.size() > 0)
		connect(_stack.top(), u);

	_stack.push(u);
}

void
TreeBuilder::pop_internal()
{
	_completed.push_back(_stack.top());
	_stack.pop();
}

void
TreeBuilder::add_leaf(const char *s)
{
	int l = create_leaf(s);
	_completed.push_back(l);

	if (_stack.size() > 0)
		connect(_stack.top(), l);
}
