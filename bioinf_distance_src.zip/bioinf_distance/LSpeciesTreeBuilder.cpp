//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LSpeciesTreeBuilder
//
//__________________________________________________________________________________________

#include "LSpeciesTreeBuilder.h"
#include <cassert>

namespace BioInf
{

//__________________________________________________________________________________________
LSpeciesTreeBuilder::LSpeciesTreeBuilder		(LSpeciesTree &tree,
												std::map<std::string, int> &leafMap,
												bool lookupLeafs) :
TreeBuilder(),
mLeafMap(leafMap),
mTree(tree),
mLookupLeafs(lookupLeafs)
{
}
//__________________________________________________________________________________________
int
LSpeciesTreeBuilder::create_leaf				(const char *s)
{
	int leafId;

	if (mLookupLeafs)
	{
		leafId = mLeafMap[s];
	}
	else
	{
		leafId = mLeafMap.size();
		mLeafMap[s] = leafId;
	}

	return mTree.AddLeaf(leafId);
}
//__________________________________________________________________________________________
} //end namespace BioInf
