//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LSpeciesTree
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

#include <vector>
#include <string>
#include <cassert>

namespace BioInf
{

	class LTreeDistance;

//....................................................................................................................................................................................
class	LSpeciesTree
{
	friend class LTreeDistance;

public:
	LSpeciesTree								();
	virtual ~LSpeciesTree						();

	// Add a new leaf and return its node-id internal to this tree.
	// The id-parameter is common to both trees whose distance is to be computed.
	int					AddLeaf					(int id);

	// Add a new internal node and connect it to node u with edges in both directions.
	// Then return the internal id of the new node.
	int					AddNode					(int u);

	// Add a new internal node, but don't connect it to anything.
	// Then return the internal id of the new node.
	int					AddNode					() { return AddLeaf(-1); }

	// Add one edge connecting node u to v, and one connecting v to u.
	void				AddEdges				(int u, int v);

protected:
	// Recursively computes the sum of the distances between trees rooted in edges e and f.
	// If 'order' is true then traverse edge e, otherwise traverse edge f.
	int					GetDistanceSum			(LTreeDistance *treeDistance, int e, int f, bool order);

	// Return number of edges in this tree. (Includes both directions).
	int					GetNumEdges				() { return (int) mEdges.size(); }

	// Return number of nodes in this tree.
	int					GetNumNodes				() { return (int) mNodes.size(); }

	// Return number of leafs in this tree.
	int					GetNumLeafs				() { return mNumLeafs; }

	// Return the internal id for the node pointed to by edge e.
	int					GetNodeFromEdge			(int e);

	// Return the leaf-id for the node u, or -1 if internal node.
	int					GetLeafId				(int u);

	// Return whether the node pointed to by edge i is a leaf or not.
	bool				IsLeaf					(int i);

	// Return the internal id for the reverse sibling of edge e.
	int					GetReverseEdge			(int e) { assert(e>=0 && e<GetNumEdges()); return mEdges[e].mReverseEdge; }

private:
	class LEdge
	{
	public:
		LEdge(int u, int v) : mU(u), mV(v) {}
		int	mU, mV; // Edge connects node mU to node mV.
		int mReverseEdge;
	};

	class LNode
	{
	public:
		LNode(int id=-1) : mId(id) {}
		std::vector<int> mEdges;
		int mId;
	};

	// Add one edge connecting node u to v. Return id for the new edge.
	int					AddEdge					(int u, int v);

private:
	std::vector<LEdge>		mEdges;			// All edges in tree, incl. both directions.
	std::vector<LNode>		mNodes;			// All nodes in tree, incl. leafs.

	int						mNumLeafs;		// Count of the number of leafs in tree.
};
} //end namespace BioInf
