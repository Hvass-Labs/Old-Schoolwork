//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LSpeciesTree
//
//__________________________________________________________________________________________

#include "LSpeciesTree.h"
#include "LTreeDistance.h"
#include "DoubleArray.h"
#include <cassert>
#include <limits>

namespace BioInf
{

//__________________________________________________________________________________________
LSpeciesTree::LSpeciesTree					() :
mNumLeafs(0)
{
}
//__________________________________________________________________________________________
LSpeciesTree::~LSpeciesTree					()
{
}
//__________________________________________________________________________________________
int
LSpeciesTree::AddLeaf				(int id)
{
	int nodeId = GetNumNodes();

	mNodes.push_back(LNode(id));

	if (id != -1)
		mNumLeafs++;

	return nodeId;
}
//__________________________________________________________________________________________
int
LSpeciesTree::AddNode				(int u)
{
	int v = AddLeaf(-1);

	AddEdges(u, v);

	return v;
}
//__________________________________________________________________________________________
int
LSpeciesTree::AddEdge				(int u, int v)
{
	// Get id for the new edge.
	int i = (int) mEdges.size();

	// Add new edge to the array containing all edges.
	mEdges.push_back(LEdge(u, v));

	// Add the edge to the node u.
	mNodes[u].mEdges.push_back(i);

	return i;
}
//__________________________________________________________________________________________
void
LSpeciesTree::AddEdges				(int u, int v)
{
	int i = AddEdge(u, v);
	int j = AddEdge(v, u);

	mEdges[i].mReverseEdge = j;
	mEdges[j].mReverseEdge = i;
}
//__________________________________________________________________________________________
int
LSpeciesTree::GetNodeFromEdge		(int e)
{
	assert(e>=0 && e<GetNumEdges());

	return mEdges[e].mV;
}
//__________________________________________________________________________________________
int
LSpeciesTree::GetLeafId				(int u)
{
	assert(u>=0 && u<GetNumNodes());

	return mNodes[u].mId;
}
//__________________________________________________________________________________________
bool
LSpeciesTree::IsLeaf				(int i)
{
	assert(i>=0 && i<GetNumEdges());

	LEdge &edge = mEdges[i]; assert(edge.mV>=0 && edge.mV<GetNumNodes());

	return GetLeafId(edge.mV) != -1;
}
//__________________________________________________________________________________________
int
LSpeciesTree::GetDistanceSum		(LTreeDistance *treeDistance, int e, int f, bool order)
{
	assert((order && e>=0 && e<GetNumEdges()) || (!order && f>=0 && f<GetNumEdges()));

	LEdge &edge = (order) ? (mEdges[e]) : (mEdges[f]); assert(edge.mV>=0 && edge.mV<GetNumNodes());
	LNode &node = mNodes[edge.mV];

	int reverseEdge = edge.mReverseEdge; // Do not traverse back through this edge.
	int distance = 0;
	int numEdges = (int) node.mEdges.size();

	for (int k=0; k<numEdges; k++)
	{
		int outgoingEdge = node.mEdges[k];

		// Only accumulate distance for the sub-tree, do not traverse backwards.
		if (outgoingEdge != reverseEdge)
		{
			int recursiveE, recursiveF;

			if (order)
			{
				recursiveE = outgoingEdge;
				recursiveF = f;
			}
			else
			{
				recursiveE = e;
				recursiveF = outgoingEdge;
			}

			distance += treeDistance->GetDistance(recursiveE, recursiveF);
		}
	}

	return distance;
}
//__________________________________________________________________________________________
} //end namespace BioInf
