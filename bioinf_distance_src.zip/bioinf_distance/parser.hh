// Copyright (C) 2003 by BiRC -- Bioinformatics Research Center
//                               University of Aarhus, Denmark
//                               Contact: Thomas Mailund <mailund@birc.dk>
//                                    or: Christian Storm <cstorm@birc.dk>

#ifndef PARSER_HH
#define PARSER_HH

#include "tree-builder.hh"

namespace Parser {

    // exceptions
    class FileOpenError {
	const char *_fname;
    public:
	FileOpenError(const char *fname) : _fname(fname) {}
	const char * fname() const { return _fname; }
    };

    class ParseError {
	const char *_fname;
	int _line_no;
    public:
	ParseError(const char *fname, int line_no)
	    : _fname(fname), _line_no(line_no) {}
	const char * fname() const { return _fname; }
	int line_no() const { return _line_no; }
    };

    void parse_tree(const char *fname, TreeBuilder &builder);

};

#endif // PARSER_HH
