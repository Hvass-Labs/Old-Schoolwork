//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LTreeDistance
//
//__________________________________________________________________________________________

#include "LTreeDistance.h"
#include "DoubleArray.h"
#include <cassert>
#include <limits>

namespace BioInf
{

//__________________________________________________________________________________________
LTreeDistance::LTreeDistance					(LSpeciesTree &T, LSpeciesTree &S) :
mT(T),
mS(S)
{
	DoAllocate();
}
//__________________________________________________________________________________________
LTreeDistance::~LTreeDistance					()
{
	DoDelete();
}
//__________________________________________________________________________________________
void
LTreeDistance::DoAllocate				()
{
	try
	{
		mK = ArrayOps::AllocateDoubleArray<int>(mT.GetNumEdges(), mS.GetNumEdges());
	}
	catch (...)
	{
		DoDelete();
		throw;
	}
}
//__________________________________________________________________________________________
void
LTreeDistance::DoDelete				()
{
	ArrayOps::DeleteDoubleArray(mK, mT.GetNumEdges());
}
//__________________________________________________________________________________________
int
LTreeDistance::Distance				()
{
	int numLeafs = mT.GetNumLeafs(); assert(mS.GetNumLeafs() == numLeafs);
	int numEdgesT = mT.GetNumEdges();
	int numEdgesS = mS.GetNumEdges();

	int e, f;

	ArrayOps::InitDoubleArray<int>(mK, numEdgesT, numEdgesS, -1);

	// Initialize mK-matrix.
	for (e=0; e<numEdgesT; e++)
	{
		int nodeT = mT.GetNodeFromEdge(e);
		int leafT = mT.GetLeafId(nodeT);

		for (f=0; f<numEdgesS; f++)
		{
			if (mK[e][f] == -1)
			{
				int nodeS = mS.GetNodeFromEdge(f);
				int leafS = mS.GetLeafId(nodeS);

				// See if both nodes are leafs.
				if (leafT != -1 && leafS != -1)
				{
					// If they are both leafs, let k reflect whether they are identical.
					int k = (leafT == leafS) ? (1) : (0);

					mK[e][f] = k;

#if 1
					// Compute the mK entries that immediately follow from mK[e][f] = k.
					int reverseE = mT.GetReverseEdge(e);
					int reverseF = mS.GetReverseEdge(f);

					mK[reverseE][reverseF] = numLeafs-1-(1-k);
					mK[reverseE][f] = 1-k;
					mK[e][reverseF] = 1-k;
#endif
				}
			}
		}
	}

	int distance = 0;

	// Compute rest of mK matrix along with distance.
	for (e=0; e<numEdgesT; e++)
	{
		for (f=0; f<numEdgesS; f++)
		{
			GetDistance(e, f);
		}
	}

	// Compute distance between trees.
	// First compute (twice) the number of unique partitions in tree T.
	for (e=0; e<numEdgesT; e++)
	{
		int reverseE = mT.GetReverseEdge(e);
		bool match;

		for (f=0, match=false; f<numEdgesS && !match; f++)
		{
			int reverseF = mS.GetReverseEdge(f);

			int dist1 = GetDistance(e, f);
			int dist2 = GetDistance(reverseE, reverseF);

			match = (dist1 + dist2 == numLeafs);
		}

		if (!match)
			distance++;
	}

	// Compute distance between trees.
	// Then compute (twice) the number of unique partitions in tree S.
	for (f=0; f<numEdgesS; f++)
	{
		int reverseF = mS.GetReverseEdge(f);
		bool match;

		for (e=0, match=false; e<numEdgesT && !match; e++)
		{
			int reverseE = mT.GetReverseEdge(e);

			int dist1 = GetDistance(e, f);
			int dist2 = GetDistance(reverseE, reverseF);

			match = (dist1 + dist2 == numLeafs);
		}

		if (!match)
			distance++;
	}

	return distance/2;
}
//__________________________________________________________________________________________
int
LTreeDistance::GetDistance			(int e, int f)
{
	assert(e>=0 && e<mT.GetNumEdges());
	assert(f>=0 && f<mS.GetNumEdges());
	assert(mK);

	int distance = mK[e][f];

	// If distance has not been computed, then do so recursively. Otherwise just return it.
	if (distance == -1)
	{
		if (!mT.IsLeaf(e))
		{
			distance = mT.GetDistanceSum(this, e, f, true);
		}
		else
		{
			distance = mS.GetDistanceSum(this, e, f, false);
		}

		mK[e][f] = distance;
	}

	return distance;
}
//__________________________________________________________________________________________
} //end namespace BioInf
