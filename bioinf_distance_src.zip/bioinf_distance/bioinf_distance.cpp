// bioinf_distance.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "LSpeciesTree.h"
#include "LTreeDistance.h"
#include "LSpeciesTreeBuilder.h"
#include "parser.hh"
#include <map>
#include <string>

using namespace BioInf;
using namespace std;

char *gFilenameT = 0;
char *gFilenameS = 0;

void GetParameters(int argc, _TCHAR* argv[])
{
	if (argc == 3)
	{
		gFilenameT = argv[1];
		gFilenameS = argv[2];
	}
	else
	{
		std::cout << "bioinf_distance tree1 tree2" << std::endl;
		exit(1);
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	GetParameters(argc, argv);

	LSpeciesTree				T, S;
	std::map<std::string, int>	leafMap;
	LSpeciesTreeBuilder			builderT(T, leafMap, false);
	LSpeciesTreeBuilder			builderS(S, leafMap, true);

    try
	{
	    Parser::parse_tree(gFilenameT, builderT);
	    Parser::parse_tree(gFilenameS, builderS);
	}
    catch (Parser::FileOpenError ferr)
	{
	    cerr << "Could not open file "
		 << ferr.fname() << endl;
	    return 1;
	}
    catch (Parser::ParseError perr)
	{
	    cerr << "Parse error in line " << perr.line_no()
		 << " in file " << perr.fname()
		 << endl;
	    return 2;
	}

	LTreeDistance distance(T, S);

	std::cout << "Symmetric distance: " << distance.Distance() << std::endl;

	return 0;
}

