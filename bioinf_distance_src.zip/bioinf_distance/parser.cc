// Copyright (C) 2003 by BiRC -- Bioinformatics Research Center
//                               University of Aarhus, Denmark
//                               Contact: Thomas Mailund <mailund@birc.dk>
//                                    or: Christian Storm <cstorm@birc.dk>

#include "parser.hh"
#include <cstdio>

int yylex();
int lex_get_line();
extern char *yytext;

static void
parse_branch_length(const char *fname)
{
    switch (yylex())
	{
	case 'f':
	    // ignore the actual length
	    break;

	default:
	    throw Parser::ParseError(fname, lex_get_line());
	}
}

void
Parser::parse_tree(const char *fname, TreeBuilder &builder)
{
    FILE *f = freopen(fname, "r", stdin);
    if (f == 0) throw FileOpenError(fname);

    int token;
    while ( (token = yylex()) != 0)
	{
	    switch (token)
		{
		case '(':
		    builder.push_internal();
		    break;

		case ')':
		    builder.pop_internal();
		    break;

		case 'i':
		    builder.add_leaf(yytext);
		    break;

		case ':':
		    parse_branch_length(fname);
		    break;

		default:
		    throw ParseError(fname, lex_get_line());
		}
	}
    fclose(f);
}
