//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LSpeciesTree
//
//....................................................................................................................................................................................

#pragma once

#include "tree-builder.hh"
#include "LSpeciesTree.h"
#include <map>
#include <string>

namespace BioInf
{

//....................................................................................................................................................................................
class	LSpeciesTreeBuilder : public TreeBuilder
{
public:
	// If lookupLeafs is true, then the map is only used for lookup of leaf-names,
	// otherwise the names are added first.
	LSpeciesTreeBuilder							(LSpeciesTree &tree,
												std::map<std::string, int> &leafMap,
												bool lookupLeafs);

protected:
	virtual int create_inner() { return mTree.AddNode(); }
    virtual int create_leaf(const char *s);
	virtual void connect(int u, int v) { mTree.AddEdges(u, v); }

private:
	LSpeciesTree				&mTree;			// Tree which we are building.
	std::map<std::string, int>	&mLeafMap;
	bool						mLookupLeafs;
};
} //end namespace BioInf
