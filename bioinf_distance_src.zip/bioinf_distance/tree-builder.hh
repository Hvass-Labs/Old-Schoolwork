// Copyright (C) 2003 by BiRC -- Bioinformatics Research Center
//                               University of Aarhus, Denmark
//                               Contact: Thomas Mailund <mailund@birc.dk>
//                                    or: Christian Storm <cstorm@birc.dk>
// Modified 2005 by Magnus EH Pedersen

#ifndef TREE_BUILDER_HH
#define TREE_BUILDER_HH

#include <list>
#include <stack>

class TreeBuilder {
    std::stack<int> _stack;

protected:
    std::list<int>  _completed;

    bool build_completed() const { return _stack.size() == 0; }

    virtual int create_inner() = 0;
    virtual int create_leaf(const char *s) = 0;
	virtual void connect(int u, int v) = 0;

public:
	TreeBuilder() {}
    virtual ~TreeBuilder() {}

    void push_internal();
    void pop_internal();
    void add_leaf(const char *s);
};

#endif // TREE_BUILDER_HH
