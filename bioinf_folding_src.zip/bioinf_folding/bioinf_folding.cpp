// bioinf_folding.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "LProteinFolding.h"
#include "FoldingCoding.h"
#include "LVectorPF.h"
#include "LSwarmGA.h"
#include "LYggRandom1.h"
#include <ctime>

Yggdrasil::LYggRandom1 gRandom;
const int	kSeed = 93858392;

using namespace BioInf;
using namespace SO;

char	*gSequence = 0;
int		gLength = 0;
int		gNumRuns = 0;
int		gNumProblemSteps = 0;
bool	gElitist = true;

LProteinFolding *gProteinFolding = 0;
LSwarm			*gSwarm = 0;

void GetParameters(int argc, _TCHAR* argv[])
{
	if (argc >= 2)
	{
		gSequence = argv[1];
		gLength = strlen(gSequence);

		if (argc == 4)
		{
			gNumRuns = atoi(argv[2]);
			gNumProblemSteps = atoi(argv[3]);
		}
		else
		{
			gNumRuns = 10;
			gNumProblemSteps = gLength*30000;
		}
	}
	else
	{
		std::cout << "hpfold protein-string [#runs #agentsteps]" << std::endl;
		exit(1);
	}
}

LVectorPF *CreateVectorPF()
{
	return new LVectorPF(*gProteinFolding, gLength);
}

void CreateSwarmGA()
{
	LSwarmGA *swarm = new LSwarmGA(*CreateVectorPF(), *CreateVectorPF(), gNumRuns, gNumProblemSteps, gElitist);

	for (int i=0; i<swarm->AllocNumAgents(); i++)
	{
		swarm->AddAgent(CreateVectorPF(), CreateVectorPF());
	}

	gSwarm = swarm;
}

int _tmain(int argc, _TCHAR* argv[])
{
	gRandom.Initialize(kSeed ^ (std::clock() * std::clock()));
	GetParameters(argc, argv);
	gProteinFolding = new LProteinFolding(gSequence, gLength);
	CreateSwarmGA();

	std::clock_t beginTime, endTime;
	beginTime = std::clock();
	gSwarm->Process();
	endTime = std::clock();

	std::cout << "\nBest solution found, energy: " << gSwarm->UBestPosition().Fitness() << " solution:\n" << gSwarm->UBestPosition().GetContents() << std::endl;
	std::cout << "In " << (endTime-beginTime)/1000 << " seconds." << std::endl;

	return 0;
}
