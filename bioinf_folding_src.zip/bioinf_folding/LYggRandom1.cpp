//__________________________________________________________________________________________
//
//	Copyright�2003 by Thurs. All rights reserved.
//
//	LYggRandom1
//
//	Magnus EH Pedersen
//
//__________________________________________________________________________________________

#include "LYggRandom1.h"
#include <limits.h>
#include <math.h>

namespace Yggdrasil
{

const long		IA = 16807;
const long		IQ = 127773;
const long		IR = 2836;
const double	NMUL = ((double) LYggRandom1::NTAB)/(1+(LONG_MAX-1));

//__________________________________________________________________________________________
LYggRandom1::LYggRandom1		(long seed) :
LYggRandom(),
mIdum(seed),
mIy(0)
{
	Initialize(seed);
}
//__________________________________________________________________________________________
void
LYggRandom1::Initialize			(long seed)
{
	LYggRandom::Initialize(seed);

	mIdum = seed;

	// Ensure initial (i.e. seed) mIdum>0
	if (mIdum == 0)
		mIdum = 1;
	else if (mIdum < 0)
		mIdum = -mIdum;

	// Generate initial shuffle table
	DoInitialize();
}
//__________________________________________________________________________________________
void
LYggRandom1::DoInitialize			()
{
	int j;

	// Generate the shuffle table (after 8 warm-ups).
	for (j=0; j<8; j++)
		DoRand();

	for (j=NTAB-1;j>=0;j--)
	{
		DoRand();
		mIv[j] = mIdum;
	}

	mIy=mIv[0];
}
//__________________________________________________________________________________________
void
LYggRandom1::DoRand				()
// ### Show invariant: mIdum != 0
{
	long k=mIdum/IQ;
	mIdum=IA*(mIdum-k*IQ)-IR*k;			// Compute idum=(IA*idum) % LONG_MAX without over-
	if (mIdum < 0) mIdum += LONG_MAX;	// flows by Schrage's method.
}
//__________________________________________________________________________________________
long
LYggRandom1::Rand				()
{
	DoRand();

	{
		int j=mIy*NMUL;				// Will be in the range 0..NTAB-1.
		mIy=mIv[j];					// Output previously stored value and refill the shuffle table.
		mIv[j] = mIdum;
	}

	return mIy;
}
//__________________________________________________________________________________________
} //end namespace Yggdrasil
