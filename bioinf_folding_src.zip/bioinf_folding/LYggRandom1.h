//....................................................................................................................................................................................
//
//	Copyright�2003 by Thurs. All rights reserved.
//
//	LYggRandom1
//
//	Taken from Numerical Recipes in C, chapter 7.1
//	
//	"Minimal" random number generator of Park and Miller with Bays-Durham shuffle and added
//	safeguards. Returns a uniform random deviate.
//
//	Note: This version includes the endpoint 1 but not 0.
//
//	Magnus EH Pedersen
//
//....................................................................................................................................................................................

#pragma once

#include "LYggRandom.h"
#include "YggConstants.h"
#include "YggRound.h"

namespace Yggdrasil
{

//....................................................................................................................................................................................
class	LYggRandom1 : public LYggRandom
{
public:
	LYggRandom1							(long seed=1);

	// Re-initialize.
	virtual void			Initialize	(long seed=1);

	// Generates and returns a new pseudo-random value.
	virtual long			Rand		();

private:
	void					DoInitialize	();

	inline void				DoRand		();

public:
	static const long	NTAB=32;

private:
	long				mIdum;						// Iterative variable.
	long				mIy;
	long				mIv[NTAB];
};
} //end namespace Yggdrasil
