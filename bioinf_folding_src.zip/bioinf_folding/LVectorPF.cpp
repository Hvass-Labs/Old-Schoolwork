//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LVectorPF
//
//__________________________________________________________________________________________

#include "LVectorPF.h"
#include "DoubleArray.h"
#include "FoldingCoding.h"
#include "random.h"

namespace SO
{

//__________________________________________________________________________________________
LVectorPF::LVectorPF		(LProteinFolding &protein, int n) :
LVector(),
kN(n),
mProtein(protein)
{
	assert(n>0);

	DoAllocate();
}
//__________________________________________________________________________________________
LVectorPF::~LVectorPF		()
{
	DoDelete();
}
//__________________________________________________________________________________________
void
LVectorPF::DoAllocate				()
{
	try
	{
		mFolding = new char[kN];
	}
	catch (...)
	{
		DoDelete();
		throw;
	}

	// Initialize the first element with a right-turn.
	mFolding[0] = eFoldingRight;
}
//__________________________________________________________________________________________
void
LVectorPF::DoDelete				()
{
	delete [] mFolding; mFolding = 0;
}
//__________________________________________________________________________________________
std::string
LVectorPF::GetContents			()
{
	char *absolute = new char[kN];
	char *textual = new char[kN+1];

	Relative2AbsoluteSeq(mFolding, absolute, kN);
	Absolute2TextualSeq(absolute, textual, kN);

	std::string retVal(textual);

	delete [] absolute;
	delete [] textual;

	return retVal;
}
//__________________________________________________________________________________________
void
LVectorPF::Initialize			()
{
#if 0
	for (int i=1; i<kN; i++)
	{
		mFolding[i] = eFoldingUp;
	}
#else
	// Create a spiral.
	int k=0, k1=0, k2=0;

	for (int i=1; i<kN; i++)
	{
		mFolding[i] = eFoldingRight;

		for (int j=0; j<k2 && i<kN-1; j++)
		{
			mFolding[++i] = eFoldingUp;
		}

		k=(k+1)%2;
		k1+=k;
		k2 = k1;
	}
#endif
}
//__________________________________________________________________________________________
void
LVectorPF::Assign				(LVector &a)
{
	LVector::Assign(a);

	LVectorPF &aPF = static_cast<LVectorPF&>(a);

	for (int i=1; i<kN; i++)
	{
		mFolding[i] = aPF.mFolding[i];
	}
}
//__________________________________________________________________________________________
void
LVectorPF::Crossover			(LVector &a, LVector &b)
{
	LVectorPF &aPF = static_cast<LVectorPF&>(a);
	LVectorPF &bPF = static_cast<LVectorPF&>(b);

	// Select a random index between 1 and kN-1, used as the crossover-point.
	int index = gRandom.RandIndex(kN-1);
	int i;

	for (i=1; i<index; i++)
	{
		mFolding[i] = aPF.mFolding[i];
	}

	for (; i<kN; i++)
	{
		mFolding[i] = bPF.mFolding[i];
	}
}
//__________________________________________________________________________________________
void
LVectorPF::Crossover			(LVector &a, LVector &b, LVector &otherChild)
{
	LVectorPF &aPF = static_cast<LVectorPF&>(a);
	LVectorPF &bPF = static_cast<LVectorPF&>(b);
	LVectorPF &otherPF = static_cast<LVectorPF&>(otherChild);

	// Select a random index between 1 and kN-1, used as the crossover-point.
	int index = gRandom.RandIndex(kN-1);
	int i;

	for (i=1; i<index; i++)
	{
		mFolding[i] = aPF.mFolding[i];
		otherPF.mFolding[i] = bPF.mFolding[i];
	}

	for (; i<kN; i++)
	{
		mFolding[i] = bPF.mFolding[i];
		otherPF.mFolding[i] = aPF.mFolding[i];
	}
}
//__________________________________________________________________________________________
void
LVectorPF::Mutation				(double p)
{
	const double kP = p/kN;

	for (int i=1; i<kN; i++)
	{
		if (gRandom.RandUni()<kP)
		{
			mFolding[i] = RandomDirection();
		}
	}
}
//__________________________________________________________________________________________
char
LVectorPF::RandomDirection		()
{
	char directions[3] = {eFoldingUp, eFoldingLeft, eFoldingRight};

	return directions[gRandom.RandIndex(3)];
}
//__________________________________________________________________________________________
} //end namespace SO
