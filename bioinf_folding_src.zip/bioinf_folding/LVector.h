//....................................................................................................................................................................................
//
//	2003-2004, Magnus EH Pedersen (971055), University of Aarhus
//
//	LVector
//
//	Specialized for "Protein Folding" project.
//
//....................................................................................................................................................................................

#pragma once

#include <string>
#include <limits>

namespace SO
{

//....................................................................................................................................................................................
class	LVector
{
public:
	LVector								() : mFitness(0) {}
	virtual 			~LVector		() {}

	// Return whether processing was succesful.
	virtual bool		Process			() = 0;

	virtual std::string	GetName			() = 0;

	virtual std::string	GetContents		() = 0;

	// Return whether this is better than "a", in regards to fitness. Defaults to minimization.
	// Use this instead of direct fitness-comparison.
	bool				BetterThan		(LVector *a) { return (Fitness() < a->Fitness()); }

	// Return the fitness.
	int					Fitness			() { return mFitness; }

	// Set the worst fitness (defaults to minimization problems).
	virtual void		SetWorstFitness	() { mFitness = std::numeric_limits<int>::max(); }

	virtual void		Initialize		() {}

	// Use instead of Operator=
	virtual void		Assign			(LVector &a) = 0
	{
		mFitness = a.mFitness;
	}

	virtual void		Crossover		(LVector &a, LVector &b) = 0;

	virtual void		Crossover		(LVector &a, LVector &b, LVector &otherChild) = 0;

	virtual void		Mutation		(double p) = 0;

protected:
	int				mFitness;
};
} //end namespace SO
