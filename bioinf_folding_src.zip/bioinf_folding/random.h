#pragma once

#include "LYggRandom1.h"

extern Yggdrasil::LYggRandom1 gRandom;
