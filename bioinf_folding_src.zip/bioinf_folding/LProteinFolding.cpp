//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LProteinFolding
//
//__________________________________________________________________________________________

#include "LProteinFolding.h"
#include "DoubleArray.h"
#include "FoldingCoding.h"

namespace BioInf
{

//__________________________________________________________________________________________
LProteinFolding::LProteinFolding		(char *proteinSequence, unsigned int length) :
kProtein(proteinSequence),
kN(length)
{
	assert(proteinSequence);
	assert(length>0);

	DoAllocate();
}
//__________________________________________________________________________________________
LProteinFolding::~LProteinFolding		()
{
	DoDelete();
}
//__________________________________________________________________________________________
void
LProteinFolding::DoAllocate				()
{
	try
	{
		mLattice = ArrayOps::AllocateDoubleArray<char>(kN+1, kN+1);
		mAbsoluteFolding = new char[kN-1];
	}
	catch (...)
	{
		DoDelete();
		throw;
	}

	// Initialize allocated data-structures.
	ArrayOps::InitDoubleArray<char>(mLattice, kN+1, kN+1, 0);
}
//__________________________________________________________________________________________
void
LProteinFolding::DoDelete				()
{
	ArrayOps::DeleteDoubleArray(mLattice, kN+1); mLattice = 0;
	delete [] mAbsoluteFolding; mAbsoluteFolding = 0;
}
//__________________________________________________________________________________________
void
LProteinFolding::MapIndex					(int &index)
{
	index = (index+(kN+1)) % (kN+1);
}
//__________________________________________________________________________________________
void
LProteinFolding::MapPosition				(char folding, int &i, int &j)
{
	switch (folding)
	{
	case eFoldingUp:	MapIndex(--i); break;
	case eFoldingDown:	MapIndex(++i); break;
	case eFoldingLeft:	MapIndex(--j); break;
	case eFoldingRight:	MapIndex(++j); break;
	default: assert(false); // error!
	}
}
//__________________________________________________________________________________________
bool
LProteinFolding::EnergyRelative			(char *relativeFolding, int &energy)
{
	Relative2AbsoluteSeq(relativeFolding, mAbsoluteFolding, kN-1);
	return Energy(mAbsoluteFolding, energy);
}
//__________________________________________________________________________________________
bool
LProteinFolding::Energy					(char *absoluteFolding, int &energy)
{
	unsigned int k;
	bool valid;

	// Construct the folding in the lattice.
	valid = LatticeFolding(absoluteFolding, k);

	// 	Compute the energy if folding is valid. Otherwise energy is undefined
	if (valid)
	{
		// Reset energy.
		energy = 0;

		// Now compute the energy of the given folding.
		ComputeEnergy(absoluteFolding, energy);

		// Adjust the computed energy, so each connection is only counted once.
		energy /= 2;
	}
	else
	{
		energy = 1;
	}

	// Now reset the lattice so it is ready for the next call to Energy().
	ResetFolding(absoluteFolding, k);

	return valid;
}
//__________________________________________________________________________________________
void
LProteinFolding::NeighbourEnergy		(char aminoAcid, int i, int j, char prevFolding, char curFolding, int &energy)
{
	if (aminoAcid == 'h')
	{
		// Check for possible connections in all four directions.

		// Up
		EnergyContribution(i, j, eFoldingDown, eFoldingUp, prevFolding, curFolding, energy);

		// Down
		EnergyContribution(i, j, eFoldingUp, eFoldingDown, prevFolding, curFolding, energy);

		// Left
		EnergyContribution(i, j, eFoldingRight, eFoldingLeft, prevFolding, curFolding, energy);

		// Right
		EnergyContribution(i, j, eFoldingLeft, eFoldingRight, prevFolding, curFolding, energy);
	}
}
//__________________________________________________________________________________________
void
LProteinFolding::EnergyContribution		(int i, int j, char prevDirection, char curDirection, char prevFolding, char curFolding, int &energy)
{
	if (prevDirection != prevFolding && curDirection != curFolding)
	{
		int neighbourI = i, neighbourJ = j;
		MapPosition(curDirection, neighbourI, neighbourJ);

		if (IsCellHydrophilic(neighbourI, neighbourJ))
			energy--;
	}
}
//__________________________________________________________________________________________
void
LProteinFolding::ComputeEnergy			(char *folding, int &energy)
{
	int i=0, j=0;
	int k;
	char prevFolding = 0;

	for (k=0; k<kN-1; k++)
	{
		char curFolding = folding[k];

		NeighbourEnergy(kProtein[k], i, j, prevFolding, curFolding, energy);

		prevFolding = curFolding;

		MapPosition(curFolding, i, j);
	}

	// Energy-contribution for the last amino-acid.
	NeighbourEnergy(kProtein[kN-1], i, j, prevFolding, eFoldingNone, energy);
}
//__________________________________________________________________________________________
bool
LProteinFolding::LatticeFolding			(char *folding, unsigned int &k)
{
	int i=0, j=0;
	bool valid = true;

	SetCellKind(0, 0, kProtein[0]);

	for (k=0; k<kN-1 && valid; k++)
	{
		MapPosition(folding[k], i, j);

		if (IsCellFree(i, j))
		{
			SetCellKind(i, j, kProtein[k+1]);
		}
		else
		{
			valid = false;
		}
	}

	return valid;
}
//__________________________________________________________________________________________
void
LProteinFolding::ResetFolding			(char *folding, unsigned int n)
{
	int i=0, j=0;

	ResetCell(0,0);

	for (int k=0; k<n; k++)
	{
		MapPosition(folding[k], i, j);

		ResetCell(i,j);
	}
}
//__________________________________________________________________________________________
} //end namespace BioInf
