//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LProteinFolding
//
//__________________________________________________________________________________________

#include "FoldingCoding.h"
#include <cassert>

namespace BioInf
{

//__________________________________________________________________________________________

	char	Relative2Absolute		(char prevAbsDirection, char relativeDirection)
	{
		assert(relativeDirection != eFoldingDown);

		return (prevAbsDirection + relativeDirection) % 4;
	}

	void	Relative2AbsoluteSeq	(char *relative, char *absolute, int n)
	{
		assert(relative && absolute);
		assert(n>0);

		// The first relative direction must be absolute, i.e. either left or right.
		assert(relative[0] != eFoldingUp);

		absolute[0] = relative[0];

		for (int i=1; i<n; i++)
		{
			absolute[i] = Relative2Absolute(absolute[i-1], relative[i]);
		}
	}

	char	Textual2Absolute		(char textual)
	{
		char retVal;

		switch (textual)
		{
		case 'u': retVal = eFoldingUp; break;
		case 'd': retVal = eFoldingDown; break;
		case 'l': retVal = eFoldingLeft; break;
		case 'r': retVal = eFoldingRight; break;
		default: assert(false); // error!
		}

		return retVal;
	}

	void	Textual2AbsoluteSeq		(char *textual, char *absolute, int n)
	{
		assert(textual && absolute);
		assert(n>0);

		for (int i=0; i<n; i++)
		{
			absolute[i] = Textual2Absolute(textual[i]);
		}
	}

	char	Absolute2Textual		(char absolute)
	{
		char retVal;

		switch (absolute)
		{
		case eFoldingUp:	retVal = 'u'; break;
		case eFoldingDown:	retVal = 'd'; break;
		case eFoldingLeft:	retVal = 'l'; break;
		case eFoldingRight:	retVal = 'r'; break;
		default: assert(false); // error!
		}

		return retVal;
	}

	void	Absolute2TextualSeq		(char *absolute, char *textual, int n)
	{
		assert(absolute && textual);
		assert(n>0);

		for (int i=0; i<n; i++)
		{
			textual[i] = Absolute2Textual(absolute[i]);
		}

		// Zero-terminate string.
		textual[n] = 0;
	}
//__________________________________________________________________________________________
} //end namespace BioInf
