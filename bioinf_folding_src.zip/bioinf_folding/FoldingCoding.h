//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	FoldingCoding
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

namespace BioInf
{
	enum
	{
		eFoldingNone = -1,		// Use this as undefined folding, e.g. for last amino-acid.
		eFoldingUp = 0,			// Means "continue" in terms of relative direction.
		eFoldingLeft = 1,		// Means "turn left" in terms of relative direction.
		eFoldingDown = 2,		// This is invalid as a relative direction.
		eFoldingRight = 3		// Means "turn right" in terms of relative direction.
	};

	// Convert a relative direction to an absolute direction.
	char	Relative2Absolute		(char prevAbsDirection, char relativeDirection);

	// Convert a sequence of relative directions to a sequence of absolute directions.
	// Assumes both arrays are allocated and of length n.
	void	Relative2AbsoluteSeq	(char *relative, char *absolute, int n);

	// Convert a textual directional coding to internal representation.
	char	Textual2Absolute		(char textual);

	// Same as Textual2Absolute() but for a sequence.
	void	Textual2AbsoluteSeq		(char *textual, char *absolute, int n);

	// Convert internal representation for absolute direction, to a textual representation.
	char	Absolute2Textual		(char absolute);

	// Same as Absolute2Textual(), but for a sequence.
	// Assumes both absolute and textual have been allocated,
	// and textual is of length n+1, so the last char is set to zero-termination.
	void	Absolute2TextualSeq		(char *absolute, char *textual, int n);

} //end namespace BioInf
