//....................................................................................................................................................................................
//
//	2003-2004, Magnus EH Pedersen (971055), University of Aarhus
//
//	LVectorPF
//
//	Specialized for "Protein Folding" project.
//
//....................................................................................................................................................................................

#pragma once

#include "LProteinFolding.h"
#include "LVector.h"
#include <string>
#include <limits>

using namespace BioInf;

namespace SO
{

//....................................................................................................................................................................................
class	LVectorPF : public LVector
{
public:
	LVectorPF							(LProteinFolding &protein, int n);
	virtual 			~LVectorPF		();

	// Return whether processing was succesful.
	virtual bool		Process			() { return mProtein.EnergyRelative(mFolding, mFitness); }

	virtual std::string	GetName			() { return "PF"; }

	virtual std::string	GetContents		();

	virtual void		Initialize		();

	// Use instead of Operator=
	virtual void		Assign			(LVector &a);

	virtual void		Crossover		(LVector &a, LVector &b);

	virtual void		Crossover		(LVector &a, LVector &b, LVector &otherChild);

	virtual void		Mutation		(double p);

private:
	// Return a random direction.
	char				RandomDirection	();

	// Memory allocation/de-allocation.
	void				DoAllocate		();
	void				DoDelete		();

protected:
	LProteinFolding		&mProtein;		// The protein-folding.
	char				*mFolding;		// The sequence of folding directions. Size kN.
	const int			kN;				// Number of directions in the folding.
};
} //end namespace SO
