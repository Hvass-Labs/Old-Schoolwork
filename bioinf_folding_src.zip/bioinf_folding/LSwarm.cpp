//__________________________________________________________________________________________
//
//	Copyright (C) 2003-2004, Magnus EH Pedersen (971055)
//
//	LSwarm
//
//__________________________________________________________________________________________

#include "LSwarm.h"
#include "LVector.h"
#include <iostream>

namespace SO
{

//__________________________________________________________________________________________
LSwarm::LSwarm				(LVector &gBestPosition,
							LVector &uBestPosition,
							int numRuns,
							int numProblemSteps) :
mGBestPosition(gBestPosition),
mUBestPosition(uBestPosition),
kNumRuns(numRuns),
kNumProblemSteps(numProblemSteps),
mNumDisplayIterations(5e4),
mDisplay(true),
mDisplayBest(false),
mRun(0),
mProblemSteps(0)
{
}
//__________________________________________________________________________________________
void
LSwarm::AddAgent			(LVector *agent)
{
	mAgents.push_back(agent);
}
//__________________________________________________________________________________________
void
LSwarm::UpdateBest			(LVector &candPos)
{
	if (candPos.BetterThan(&mGBestPosition))
	{
		mGBestPosition.Assign(candPos);

		if (candPos.BetterThan(&mUBestPosition))
		{
			mUBestPosition.Assign(candPos);
		}
	}
}
//__________________________________________________________________________________________
void
LSwarm::Process					()
{
	int problemStepsTotal = 0;

	for (mRun=0; mRun<kNumRuns; mRun++)
	{
		mProblemSteps = 0;

		Restart();

		DisplayRun();

		while (mProblemSteps < kNumProblemSteps)
		{
			DisplayIteration();

			mProblemSteps += DoProcess();
		}

		problemStepsTotal += mProblemSteps;

		DisplayRunEnd();
	}
}
//__________________________________________________________________________________________
void
LSwarm::Restart			()
{
	// Assumes the subclass of LSwarm has re-initialized all the agents!

	int numAgents = mAgents.size();

	if (numAgents>0)
	{
		int i=0;
		LVector *best = mAgents[i];
		i++;

		for (; i<numAgents; i++)
		{
			LVector *curPos = mAgents[i];

			if (curPos->BetterThan(best))
				best = curPos;
		}

		mGBestPosition.Assign(*best);

		if (mGBestPosition.BetterThan(&mUBestPosition))
			mUBestPosition.Assign(mGBestPosition);
	}

	mLastDisplayIteration = 0;
	mLastDisplayFitness = GBestPosition().Fitness();
}
//__________________________________________________________________________________________
void
LSwarm::DisplayIteration		()
{
	if (mDisplay && (GetProblemSteps()-mLastDisplayIteration >= mNumDisplayIterations))
	{
		if (mDisplayBest)
			std::cout << "Best fitness: " << UBestPosition().Fitness() << " position: " << UBestPosition().GetContents() << std::endl;

		std::cout << "Run: " << GetRun() << " iteration: " << GetProblemSteps();
		DisplayFitness();

		if (mLastDisplayFitness != GBestPosition().Fitness())
		{
			std::cout << "\t*";
			mLastDisplayFitness = GBestPosition().Fitness();
		}

		std::cout << std::endl;

		mLastDisplayIteration = GetProblemSteps();
	}
}
//__________________________________________________________________________________________
void
LSwarm::DisplayRun				()
{
	if (mDisplay)
	{
		std::cout << std::endl << "Run: " << GetRun();
		DisplayFitness();
		std::cout << std::endl;
	}
}
//__________________________________________________________________________________________
void
LSwarm::DisplayRunEnd			()
{
	if (mDisplay)
	{
		std::cout << "Run: " << GetRun();
		DisplayFitness();
		std::cout << std::endl;
	}
}
//__________________________________________________________________________________________
void
LSwarm::DisplayFitness			()
{
	std::cout << " gbest: " << GBestPosition().Fitness();
}
//__________________________________________________________________________________________
} //end namespace SO
