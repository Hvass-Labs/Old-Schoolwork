//....................................................................................................................................................................................
//
//	Copyright (C) 2003-2004, Magnus EH Pedersen (971055)
//
//	LSwarm
//
//....................................................................................................................................................................................

#pragma once

#include "LVector.h"
#include <vector>

namespace SO
{

//....................................................................................................................................................................................
class	LSwarm
{
public:
	LSwarm									(LVector &gBestPosition,
											LVector &uBestPosition,
											int numRuns,
											int numProblemSteps);

	virtual void		Process				();

	// ### Return fitness of best position for entire swarm.
	virtual LVector		&GBestPosition		() { return mGBestPosition; }

	// ### Return fitness of best position for entire swarm.
	virtual LVector		&UBestPosition		() { return mUBestPosition; }

	void				AddAgent			(LVector *agent);

	// Update GBest and UBest
	void				UpdateBest			(LVector &candPos);

	// Return the number of agents to allocate (e.g. 20 for a basic PSO swarm).
	int					AllocNumAgents		() { return 0; }

	void				SetNumDisplayIterations	(int num) { mNumDisplayIterations = num; }

	// Set whether to display any progress log at all.
	void				SetDisplay			(bool display) { mDisplay = display; }

	// Set whether to display the best position at each iteration.
	void				SetDisplayBest		(bool displayBest) { mDisplayBest = displayBest; }

protected:
	// Override this instead of Process()
	virtual int			DoProcess			() = 0;

	// Traverse down until the next time kRestarting is true, and call ReInitialize() on the way.
	virtual void		Restart				() = 0;

	virtual int			DoGetNumAgents		() { return (int) mAgents.size(); }
	virtual void		DoSetNumAgents		(int numAgents) { } // Don't do anything here.

	int					GetRun				() { return mRun; }
	int					GetProblemSteps		() { return mProblemSteps; }

	void				DisplayIteration	();
	void				DisplayRun			();
	void				DisplayRunEnd		();
	void				DisplayFitness		();

protected:
	LVector					&mGBestPosition;
	std::vector<LVector*>	mAgents;

private:
	LVector					&mUBestPosition;

	const int				kNumRuns;
	const int				kNumProblemSteps;

	int						mRun;						// Number of runs completed so far.
	int						mProblemSteps;				// Number of problem-steps completed so far.

	int						mNumDisplayIterations;		// Number of iterations between display.
	int						mLastDisplayIteration;		// At what iteration did display last occur.
	double					mLastDisplayFitness;
	bool					mDisplay;
	bool					mDisplayBest;
};
} //end namespace SO
