//....................................................................................................................................................................................
//
//	2003, Magnus EH Pedersen (971055), University of Aarhus
//
//	LSwarmGA
//
//	### Population size of 25
//
//....................................................................................................................................................................................

#pragma once

#include "LSwarm.h"

namespace SO
{

//....................................................................................................................................................................................
class	LSwarmGA : public LSwarm
{
public:
	LSwarmGA								(LVector &gBestPosition,
											LVector &uBestPosition,
											int numRuns,
											int numProblemSteps,
											bool elitist);

	virtual void		AddAgent			(LVector *curPos, LVector *tempPos);

	virtual int			AllocNumAgents		() { return 100; }

	virtual std::string	GetName				() { return "GA"; }

	virtual void		Restart				();

protected:
	virtual int			DoProcess			();

private:
	// Consider 2 randomly picked agents and return the best of them.
	virtual LVector		&Selection			();

	// Hide inherited AddAgent()
	void				AddAgent			(LVector *curPos);

private:
	std::vector<LVector*>	mTempPos;
	bool					mElitist;
};
} //end namespace SO
