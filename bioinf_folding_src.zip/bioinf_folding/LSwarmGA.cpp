//__________________________________________________________________________________________
//
//	2003, Magnus EH Pedersen (971055), University of Aarhus
//
//	LSwarmGA
//
//__________________________________________________________________________________________

#include "LSwarmGA.h"
#include "LVector.h"
#include "YggRound.h"
#include "random.h"
#include <cmath>

namespace SO
{

	const double	kPCrossover = 0.3;		// Crossover-probability.
	const double	kPMutation = 3;			// Mutation probability-factor.

//__________________________________________________________________________________________
LSwarmGA::LSwarmGA		(LVector &gBestPosition,
						LVector &uBestPosition,
						int numRuns,
						int numProblemSteps,
						bool elitist) :
LSwarm(gBestPosition, uBestPosition, numRuns, numProblemSteps),
mElitist(elitist)
{
}
//__________________________________________________________________________________________
void
LSwarmGA::AddAgent			(LVector *curPos, LVector *tempPos)
{
	LSwarm::AddAgent(curPos);
	mTempPos.push_back(tempPos);
}
//__________________________________________________________________________________________
LVector&
LSwarmGA::Selection			()
{
	LVector *agent1 = mAgents[gRandom.RandIndex(mAgents.size())];
	LVector *agent2 = mAgents[gRandom.RandIndex(mAgents.size())];

	return (agent1->BetterThan(agent2)) ? (*agent1) : (*agent2);
}
//__________________________________________________________________________________________
int
LSwarmGA::DoProcess			()
{
	assert(mAgents.size() == mTempPos.size());
	assert(mAgents.size()>0);

	int numAgentSteps = 0;
	int i=0;

	if (mElitist)
		i++;

	// Create the crossover-part of the new population.
	for (; i<mAgents.size(); i++)
	{
		LVector *child = mTempPos[i];
		bool valid;

		do
		{
			if (gRandom.RandUni() < kPCrossover)
			{
				child->Crossover(Selection(), Selection());
			}
			else
			{
				child->Assign(Selection());
			}

			child->Mutation(kPMutation);
			valid = child->Process();
			numAgentSteps++;
		} while (!valid);
	}

	i=0;

	// Only assign first agent if elitist, the fitness has already been calculated.
	if (mElitist)
	{
		mAgents[0]->Assign(GBestPosition());
		i++;
	}

	// Replace old population with new, process() and update best.
	for (; i<mAgents.size(); i++)
	{
		LVector *curPos = mAgents[i];
		LVector *tempPos = mTempPos[i];

		curPos->Assign(*tempPos);

		UpdateBest(*curPos);
	}

	return numAgentSteps;
}
//__________________________________________________________________________________________
void
LSwarmGA::Restart			()
{
	int numAgents = mAgents.size();

	for (int i=0; i<numAgents; i++)
	{
		LVector	*curPos = mAgents[i];

		bool valid;

		curPos->Initialize();
		valid = curPos->Process();
	}

	LSwarm::Restart();
}
//__________________________________________________________________________________________
} //end namespace SO
