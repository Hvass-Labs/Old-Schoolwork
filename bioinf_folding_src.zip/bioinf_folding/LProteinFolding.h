//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LProteinFolding
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

#include <sstream>
#include <utility>
#include <list>
#include <cassert>

namespace BioInf
{
//....................................................................................................................................................................................
class	LProteinFolding
{
public:
	LProteinFolding								(char *proteinSequence, unsigned int length);
	virtual ~LProteinFolding					();

	// Set the energy of the given folding, return whether the folding was valid.
	// If folding was invalid, set the energy to +1.
	// Assumes the directional folding is of length kN-1
	bool				Energy					(char *absoluteFolding, int &energy);

	// Same as Energy() but with relative folding.
	bool				EnergyRelative			(char *relativeFolding, int &energy);

private:
	// Allocate and de-allocate the required arrays.
	void				DoAllocate				();
	void				DoDelete				();

	// Construct the folding in the lattice. That is, fill in the appropriate cells.
	// Return whether the lattice was legal, and set the number of chars were processed.
	bool				LatticeFolding			(char *folding, unsigned int &k);

	// Compute the energy of the folding in the lattice.
	void				ComputeEnergy			(char *folding, int &energy);

	// Reset the lattice for the given folding, up to the n'th character. O(n).
	void				ResetFolding			(char *folding, unsigned int n);

	// Reset the cell at the given position.
	void				ResetCell				(unsigned int i, unsigned int j) { GetCell(i,j) = 0; }

	// Return the cell at the given position.
	char				&GetCell				(unsigned int i, unsigned int j) { assert(i<kN+1 && j<kN+1); return mLattice[i][j]; }

	// Wrap-around the given index, to fit the lattice.
	void				MapIndex				(int &index);

	// Set the indices resulting from following the given folding-direction.
	void				MapPosition				(char folding, int &i, int &j);

	// Return whether the given cell is free.
	bool				IsCellFree				(unsigned int i, unsigned int j) { return GetCell(i, j) == 0; }

	// Return whether the given cell is occupied by a hydrophilic (polar) amino-acid.
	bool				IsCellHydrophilic		(unsigned int i, unsigned int j) { return GetCell(i, j) == 'h'; }

	// Set whether the given cell is hydrophobic ('p') or hydrophilic ('h').
	void				SetCellKind				(unsigned int i, unsigned int j, char c) { GetCell(i, j) = c; }

	// Decrease the energy for all neighbours.
	void				NeighbourEnergy			(char aminoAcid, int i, int j, char prevFolding, char curFolding, int &energy);

	// Decrease the energy, if the neighbour in curDirection from position (i,j) is a hydrophilic amino-acid.
	void				EnergyContribution		(int i, int j, char prevDirection, char curDirection, char prevFolding, char curFolding, int &energy);

private:
	char				**mLattice;			// Of size (kN+1)^2

	char				*mAbsoluteFolding;	// Used for conversion from relative folding. Size kN-1.

	const char			*kProtein;			// Protein-sequence.
	const unsigned int	kN;					// Length of protein sequence.
};
} //end namespace BioInf
