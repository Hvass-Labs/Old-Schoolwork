//....................................................................................................................................................................................
//
//	Copyright�2001-2003 by Thurs. All rights reserved.
//
//	YggConstants
//
//	Constant declarations.
//
//	Mac:	Make sure to set the init entry-point to __initialize
//
//	Magnus EH Pedersen
//
//....................................................................................................................................................................................

#pragma once

#include "YggSamplePt.h"
#include <math.h>
#include <limits.h>

namespace Yggdrasil
{

const double kPi = 2*acos(0);		// pi
const double kPi2 = 2*kPi;			// 2*pi

const YggSamplePt kRMSTimeConst = 0.0001;

const float kOneF = (float) 1.0;
const bool kFalse = false;

const float kShort2Float = 1.0/SHRT_MAX;
const float kFloat2Short = SHRT_MAX;

} //end namespace Yggdrasil
