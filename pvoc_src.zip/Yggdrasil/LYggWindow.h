//....................................................................................................................................................................................
//
//	Copyright�2001 by Thurs. All rights reserved.
//
//	LYggWindow
//
//	Base-class for windows.
//
//	Set the length of the window m to the length of the array that must be windowed
//	minus one: N-1. This provides (depending on window-type)
//	w[m] = w[0]
//
//	For periodicity, set m to N, this provides (depending on window-type):
//	w[m+1] = w[0]
//
//	Magnus EH Pedersen
//
//....................................................................................................................................................................................

#pragma once

#include "YggSamplePt.h"

namespace Yggdrasil
{

//....................................................................................................................................................................................
class	LYggWindow
{
public:
	/* m is the length of the window, i.e. the array will be m+1 elements long */
	LYggWindow								(int m) :
	mM(m)
	{
		mWindow = new YggSamplePt[m+1];
	}

	~LYggWindow								()
	{
		delete [] mWindow;
	}

	/* Return the n'th element w[n] by table-lookup, assumes n in [0, m] */
	inline YggSamplePt		Lookup			(int n)
	{
		return mWindow[n];
	}

	/* Return w(n), assumes n in [0, m] */
	virtual YggSamplePt		w				(YggSamplePt n) = 0;

protected:

	/* Update window table */
	void					UpdateTable		()
	{
		for (int i=0; i<=mM; i++)
			mWindow[i]=w(i);
	}

	int						GetWindowSize	()
	{
		return mM;
	}

private:
	YggSamplePt*		mWindow;					// Array with window-values at discrete intervals.
	int					mM;							// Size of the window, array-length is mM+1.
};
} //end namespace Yggdrasil
