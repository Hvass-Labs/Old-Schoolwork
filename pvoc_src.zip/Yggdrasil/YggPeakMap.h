//....................................................................................................................................................................................
//
//	Copyright�2003 by Thurs. All rights reserved.
//
//	YggPeakMap
//
//	Magnus EH Pedersen
//
//....................................................................................................................................................................................

#pragma once

namespace Yggdrasil
{

//....................................................................................................................................................................................

// Generate an index-map into the peakmap-array from the magnitude-array,
// designating for each index where the closest surrounding peak is.
// A magnitude-point is a peak iff mag[i-1] <= mag[i] >= mag[i+1]
// Assume length of magnitude and peakmap is n.
template <class T> void YggPeakMap	(T *magnitude, int *peakmap, int n)
{
	int i;

	// Init peakmap
	for (i=0; i<n; i++)
		peakmap[i] = -n;

	// Find all peaks
	{
		if (magnitude[0]>=magnitude[1])
			peakmap[0] = 0;

		for (i=1; i<n-1; i++)
		{
			if (magnitude[i]>=magnitude[i-1] && magnitude[i]>=magnitude[i+1])
				peakmap[i] = i;
		}

		if (magnitude[n-1]>=magnitude[n-2])
			peakmap[n-1] = n-1;
	}

	// Map to left-hand peaks
	{
		int left = -n;

		for (i=0; i<n; i++)
		{
			if (peakmap[i] == i)
				left = i;
			else
				peakmap[i] = left;
		}
	}

	// Map to right-hand peaks if closer than left-hand
	{
		int right = 2*n;

		for (i=n-1; i>=0; i--)
		{
			if (peakmap[i] == i)
				right = i;
			else
			{
				int distLeft = i-peakmap[i];
				int distRight = right-i;

				if ((distLeft > distRight) || (distLeft==distRight && magnitude[peakmap[i]]<magnitude[right]))
					peakmap[i] = right;
			}
		}
	}
}

//....................................................................................................................................................................................
} //end namespace Yggdrasil
