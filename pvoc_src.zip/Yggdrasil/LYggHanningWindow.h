//....................................................................................................................................................................................
//
//	Copyright�2001 by Thurs. All rights reserved.
//
//	LYggHanningWindow
//
//	The Hanning/Hamming/Hann window, defined by:
//
//	w[n] = k-(1-k)*cos(2*pi*n/m)
//
//	With k=0.5 for Hanning, k=0.54 for Hamming.
//
//	The length m must be greater than 1 to cause no errors,
//	and greater than 2 to make sense.
//
//	Magnus EH Pedersen
//
//....................................................................................................................................................................................

#pragma once

#include "YggSamplePt.h"
#include "LYggWindow.h"

namespace Yggdrasil
{

//....................................................................................................................................................................................
class	LYggHanningWindow : public LYggWindow
{
public:
	/* m is the length of the window */
	LYggHanningWindow					(int m, YggSamplePt k=0.5);

	/* Return w(n), assumes n in [0, m] */
	YggSamplePt			w				(YggSamplePt n);

private:
	YggSamplePt				mK;
};
} //end namespace Yggdrasil
