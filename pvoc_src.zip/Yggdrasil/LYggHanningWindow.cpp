//__________________________________________________________________________________________
//
//	Copyright�2001 by Thurs. All rights reserved.
//
//	LYggHanningWindow
//
//	Magnus EH Pedersen
//
//__________________________________________________________________________________________

#include "LYggHanningWindow.h"
#include "YggConstants.h"
#include <math.h>

namespace Yggdrasil
{
//__________________________________________________________________________________________
LYggHanningWindow::LYggHanningWindow		(int m, YggSamplePt k) :
LYggWindow(m),
mK(k)
{
	UpdateTable();
}
//__________________________________________________________________________________________
YggSamplePt
LYggHanningWindow::w				(YggSamplePt n)
{
	return mK-(1-mK)*std::cos(2*kPi*n/(YggSamplePt)GetWindowSize());
}
//__________________________________________________________________________________________
} //end namespace Yggdrasil
