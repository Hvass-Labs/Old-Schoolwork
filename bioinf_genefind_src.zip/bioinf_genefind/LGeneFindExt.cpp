//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LGeneFindExt
//
//__________________________________________________________________________________________

#include "LGeneFindExt.h"
#include "DoubleArray.h"
#include <assert.h>
#include <algorithm>
#include <limits>

namespace BioInf
{

	const int kMin = std::numeric_limits<int>::min() >> 1;

//__________________________________________________________________________________________
LGeneFindExt::LGeneFindExt			(LSequenceDNA &seqDNA1, LSequenceDNA &seqDNA2, int gamma, int lambda, bool flagStartStop) :
LGeneFind(seqDNA1, seqDNA2, gamma, lambda, flagStartStop),
mCells(0),
mScoreCodon(0)
{
	DoAllocate();
}
//__________________________________________________________________________________________
LGeneFindExt::~LGeneFindExt			()
{
	DoDelete();
}
//__________________________________________________________________________________________
void
LGeneFindExt::DoAllocate			()
{
	try
	{
		int n = mSeqDNA1.Length();
		int m = mSeqDNA2.Length();

		mCells = ArrayOps::AllocateDoubleArray<LCell>(n+1, m+1);
	}
	catch (...)
	{
		DoDelete();
		throw;
	}
}
//__________________________________________________________________________________________
void
LGeneFindExt::DoDelete				()
{
	int n = mSeqDNA1.Length();

	ArrayOps::DeleteDoubleArray<LCell>(mCells, n+1); mCells = 0;
}
//__________________________________________________________________________________________
void
LGeneFindExt::UpdateIa				(int i, int j, int p)
{
	assert(i<mSeqDNA1.Length()+1);

	int max = kMin;

	if (i>0)
	{
		// Continue intron?
		max = mCells[i-1][j].mIa[p];

		// Begin new intron?
		if (mSeqDNA1.IsDonor(i))
			max = std::max(max, mCells[i-1][j].mS[p] + kGamma);
	}

	mCells[i][j].mIa[p] = max;
}
//__________________________________________________________________________________________
void
LGeneFindExt::UpdateIb				(int i, int j, int p)
{
	assert(j<mSeqDNA2.Length()+1);

	int max = kMin;

	if (j>0)
	{
		// Continue intron?
		max = mCells[i][j-1].mIb[p];

		// Begin new intron?
		if (mSeqDNA2.IsDonor(j))
			max = std::max(max, mCells[i][j-1].mS[p] + kGamma);
	}

	mCells[i][j].mIb[p] = max;
}
//__________________________________________________________________________________________
int
LGeneFindExt::CalcAlignment			()
{
	assert(mScore);

	for (int i=0; i<mSeqDNA1.Length()+1; i++)
	{
		for (int j=0; j<mSeqDNA2.Length()+1; j++)
		{
			for (int p=0; p<3; p++)
			{
				int max = kMin;
				char track = eTrackNone;

				// Only calculate score Sp(i,j) if we haven't met a stop-codon.
				if (!(p == 2 && ((i>3 && mSeqDNA1.IsGeneStop(i-3)) || (j>3 && mSeqDNA2.IsGeneStop(j-3)))))
				{
					if (i>0 && j>0)
					{
						// Character/codon match?
						int codonScore = (p == 1) ? (CodonScore(i, j)) : (0);
						UpdateTrackAndMax(max, track, mCells[i-1][j-1].mS[DecP(p)] + CharScore(i, j) + codonScore, eTrackDiagonal);

						// Gene start signal?
						if (p == 2 && mSeqDNA1.IsGeneStart(i) && mSeqDNA2.IsGeneStart(j))
							UpdateTrackAndMax(max, track, 0, eTrackNone);
					}

					if (i>2)
					{
						// Gap in string S2?
						UpdateTrackAndMax(max, track, mCells[i-3][j].mS[p] + 3*kLambda, eTrackUpE);
					}

					// End of intron in S1?
					if (i>0 && mSeqDNA1.IsAcceptor(i))
						UpdateTrackAndMax(max, track, mCells[i-1][j].mIa[p] + kGamma, eTrackUpI);

					if (j>2)
					{
						// Gap in string S1?
						UpdateTrackAndMax(max, track, mCells[i][j-3].mS[p] + 3*kLambda, eTrackLeftE);
					}

					// End of intron in S2?
					if (j>0 && mSeqDNA2.IsAcceptor(j))
						UpdateTrackAndMax(max, track, mCells[i][j-1].mIb[p] + kGamma, eTrackLeftI);
				}

				// Set score in mS-table.
				mCells[i][j].mS[p] = max;

				// Update the Ia table.
				UpdateIa(i, j, p);

				// Update the Ib table.
				UpdateIb(i, j, p);

				// Set Back-Track.
				mCells[i][j].mTrack[p] = track;
			}
		}
	}

	return 0;
}
//__________________________________________________________________________________________
void
LGeneFindExt::UpdateTrackAndMax	(int &max, char &track, int newScore, char newTrack)
{
	if (newScore>max)
	{
		// Update max.
		max = newScore;

		// Replace Track.
		track = newTrack;
	}
	else if (newScore == max)
	{
		// Add one more back-tracking arrow.
		track |= newTrack;
	}
}
//__________________________________________________________________________________________
bool
LGeneFindExt::BackTrackIa		(int i, int j, int p)
{
	bool legalGeneFound = false;

	while (i>0)
	{
		mSeqDNA1.SetIsIntron(i);

		if (mSeqDNA1.IsDonor(i) && mCells[i-1][j].mS[p] + kGamma > mCells[i-1][j].mIa[p])
		{
			legalGeneFound = BackTrackS(i-1, j, p);
			break;
		}
		else
		{
			i--;
		}
	}

	return legalGeneFound;
}
//__________________________________________________________________________________________
bool
LGeneFindExt::BackTrackIb		(int i, int j, int p)
{
	bool legalGeneFound = false;

	while (j>0)
	{
		mSeqDNA2.SetIsIntron(j);

		if (mSeqDNA2.IsDonor(j) && mCells[i][j-1].mS[p] + kGamma > mCells[i][j-1].mIb[p])
		{
			legalGeneFound = BackTrackS(i, j-1, p);
			break;
		}
		else
		{
			j--;
		}
	}

	return legalGeneFound;
}
//__________________________________________________________________________________________
bool
LGeneFindExt::BackTrackS		(int i, int j, int p)
{
	bool legalGeneFound = false;

	while (i>=0 && j>=0)
	{
		if (IsTrackDiagonal(i,j,p))
		{
			mSeqDNA1.SetIsExon(i);
			mSeqDNA2.SetIsExon(j);

			i--;
			j--;
			p = DecP(p);
		}
		else if (IsTrackUpE(i,j,p))
		{
			mSeqDNA1.SetIsExon(i);
			mSeqDNA1.SetIsExon(i-1);
			mSeqDNA1.SetIsExon(i-2);

			i-=3;
		}
		else if (IsTrackLeftE(i,j,p))
		{
			mSeqDNA2.SetIsExon(j);
			mSeqDNA2.SetIsExon(j-1);
			mSeqDNA2.SetIsExon(j-2);

			j-=3;
		}
		else if (IsTrackUpI(i,j,p))
		{
			mSeqDNA1.SetIsIntron(i);
			legalGeneFound = BackTrackIa(i-1, j, p);
			break;
		}
		else if (IsTrackLeftI(i,j,p))
		{
			mSeqDNA2.SetIsIntron(j);
			legalGeneFound = BackTrackIb(i, j-1, p);
			break;
		}
		else // eTrackNone
		{
			// Flag gene's start-signal as exons?
			if (mFlagStartStop)
			{
				mSeqDNA1.SetIsExonStartSignal(i);
				mSeqDNA2.SetIsExonStartSignal(j);
			}

			// We have now found a legal gene.
			legalGeneFound = true;

			// Terminate recursion.
			break;
		}
	}

	return legalGeneFound;
}
//__________________________________________________________________________________________
int
LGeneFindExt::CodonScore		(int i, int j)
{
	int score = 0;

	if ((i>=2 && i<mSeqDNA1.Length()) && (j>=2 && j<mSeqDNA2.Length()))
	{
		score = mScoreCodon->Score(mSeqDNA1.GetAminoAcid(i), mSeqDNA2.GetAminoAcid(j));
	}

	return score;
}
//__________________________________________________________________________________________
} //end namespace BioInf
