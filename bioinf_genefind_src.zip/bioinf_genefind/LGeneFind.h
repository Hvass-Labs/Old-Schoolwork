//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LGeneFind
//
//	Base-class for gene-finding algorithms based on local alignment.
//
//....................................................................................................................................................................................

#pragma once

#include "LSequenceDNA.h"
#include "LScore.h"

namespace BioInf
{

	enum
	{
		eTrackNone = 0,			// No trace.
		eTrackLeftI = 1,		// (i, j-1) intron
		eTrackLeftE = 2,		// (i, j-1) exon
		eTrackDiagonal = 4,		// (i-1, j-1)
		eTrackUpI = 8,			// (i-1, j) intron
		eTrackUpE = 16			// (i-1, j) exon
	};

//....................................................................................................................................................................................
class	LGeneFind
{
public:
	LGeneFind									(LSequenceDNA &seqDNA1, LSequenceDNA &seqDNA2, int gamma, int lambda, bool flagStartStop);
	virtual ~LGeneFind							();

	// Set the score-matrix.
	void				SetScoreMatrix			(LScore *score) { mScore = score; }

	// Perform the alignment and return the score.
	virtual int			CalcAlignment			() = 0;

	// Set the intron/exon flag for each character in the DNA-sequences.
	// Assume CalcAlignment() has been called first.
	// Return whether a valid gene was found in both of the strings.
	bool				CalcExons				();

protected:
	// The score of comparing two characters.
	int					CharScore				(int i, int j) { assert(mScore); return mScore->Score(mSeqDNA1.GetChar(i), mSeqDNA2.GetChar(j)); }

	// Return whether the given backtrack-arrow is pointing in the given direction.
	bool				IsTrack					(char track, char trackType) { return (track & trackType) != 0; }

	// Update track according to whether newMax>max or newMax==max.
	void				UpdateTrackAndMax		(int &max, char &track, int newMax, char newTrack);

	// Set (bestI,bestJ) to be the position that maximizes the score while having gene-stop-signals in A[bestI+1..] and B[bestJ+1..]
	void				BestGeneEnd				(int &bestI, int &bestJ);

	// Compute the actual alignment by performing back-tracking, marking introns and exons.
	// Return whether a valid gene was found in the two DNA sequences.
	virtual bool		BackTrack				(int i, int j) = 0;

	// Return the alignment score S(i,j) at a gene's stop-signals. Used by BestGeneEnd().
	virtual int			GetEndScore				(int i, int j) = 0;

protected:
	LScore			*mScore;				// Score-matrix for comparing characters.

	LSequenceDNA	&mSeqDNA1;				// First DNA-sequence.
	LSequenceDNA	&mSeqDNA2;				// Second DNA-sequence.

	const int		kLambda;				// Gap-cost. Assume kLambda<0
	const int		kGamma;					// Intron-cost. Assume kGamma<0
	bool			mFlagStartStop;			// Should start/stop-signals be flagged as exons.
};
} //end namespace BioInf
