//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LGeneFindExt
//
//	The extended local-alignment algorithm for finding eukaryotic genes.
//
//....................................................................................................................................................................................

#pragma once

#include "LGeneFind.h"
#include "LSequenceDNA.h"
#include "LScore.h"

namespace BioInf
{

//....................................................................................................................................................................................
class	LGeneFindExt : public LGeneFind
{
public:
	LGeneFindExt								(LSequenceDNA &seqDNA1, LSequenceDNA &seqDNA2, int gamma, int lambda, bool flagStartStop);
	virtual ~LGeneFindExt						();

	// Set the codon-score-matrix.
	void				SetScoreCodon			(LScore *scoreCodon) { mScoreCodon = scoreCodon; }

	// Perform the alignment and return the score.
	virtual int			CalcAlignment			();

protected:
	// Recursive back-tracking algorithms. Assume that Calculate() has been called.
	// Call BackTrackS(bestI, bestJ) where bestI and bestJ are obtained from BestGeneEnd().
	bool				BackTrackS				(int i, int j, int p);
	bool				BackTrackIa				(int i, int j, int p);
	bool				BackTrackIb				(int i, int j, int p);

	// Return the score of the codons S1[i-1..i+1] and S2[j-1..j+1], accepts i in [1..N] and j in [1..M]
	int					CodonScore				(int i, int j);

	// Compute the intron-score for sequence mSeqDNA1 at position (i,j).
	virtual void		UpdateIa				(int i, int j, int p);

	// Compute the intron-score for sequence mSeqDNA2 at position (i,j).
	virtual void		UpdateIb				(int i, int j, int p);

	// Return the back-tracking arrow for table mS and cell (i,j).
	char				GetTrack				(int i, int j, int p) { return mCells[i][j].mTrack[p]; }

	// Update track according to whether newMax>max or newMax==max.
	void				UpdateTrackAndMax		(int &max, char &track, int newMax, char newTrack);

	// Return whether the backtrack-arrow at position (i,j) is of the given type.
	bool				IsTrackUpE				(int i, int j, int p) { return IsTrack(GetTrack(i,j,p), eTrackUpE); }
	bool				IsTrackUpI				(int i, int j, int p) { return IsTrack(GetTrack(i,j,p), eTrackUpI); }
	bool				IsTrackLeftE			(int i, int j, int p) { return IsTrack(GetTrack(i,j,p), eTrackLeftE); }
	bool				IsTrackLeftI			(int i, int j, int p) { return IsTrack(GetTrack(i,j,p), eTrackLeftI); }
	bool				IsTrackDiagonal			(int i, int j, int p) { return IsTrack(GetTrack(i,j,p), eTrackDiagonal); }

	virtual bool		BackTrack				(int i, int j) { return BackTrackS(i, j, 2); }
	virtual int			GetEndScore				(int i, int j) { return mCells[i][j].mS[2]; }

private:
	// Allocation/deletion which does not leak memory in case of allocation error.
	void				DoAllocate				();
	void				DoDelete				();

	// Cyclic decremental. Return p-1, except when p<=0, then return 2.
	int					DecP					(int p) { return (p <= 0) ? (2) : (p-1); }

private:
	// Holds cell-values for S, Ia, and Ib tables, as well as back-tracking.
	class	LCell
	{
	public:
		LCell			() {}

		int				mS[3];			// Score for overall alignment.
		int				mIa[3];			// Score for intron in S1.
		int				mIb[3];			// Score for intron in S2.
		char			mTrack[3];		// Back-track direction.
		char			mUnused;		// Ensures proper alignment.
	};

protected:
	LScore			*mScoreCodon;			// Score-matrix for comparing codons.
	LCell			**mCells;				// S, Ia, and Ib tables.
};
} //end namespace BioInf
