//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LScore
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

namespace BioInf
{

//....................................................................................................................................................................................
class	LScore
{
public:
	LScore								() {}
	virtual ~LScore						() {}

	virtual int			Score			(char a, char b) = 0;

	// Return whether the character is valid.
	virtual bool		IsValid			(char a) { return true; }

	// Return the default char that is used instead of 'unknown'.
	virtual char		GetDefaultChar	() { return 'a'; }
};
} //end namespace BioInf
