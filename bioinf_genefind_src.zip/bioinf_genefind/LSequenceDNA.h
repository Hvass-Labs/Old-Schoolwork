//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LSequenceDNA
//
//	### What's it used for?
//	Either use std::bitset (is this possible?), or create specialized code for
//	condensing into a better usage of bits.
//
//....................................................................................................................................................................................

#pragma once

#include <vector>
#include <assert.h>

namespace BioInf
{

//....................................................................................................................................................................................
class	LSequenceDNA
{
public:
	// Assume all characters of s are lower-case. Does not copy s.
	LSequenceDNA								(char *s, int n);
	virtual ~LSequenceDNA						();

	// Return the length of the sequence.
	int					Length					() { return kN; }

	// Return character as position i in [1..N].
	char				GetChar					(int i) { assert(i>=1 && i<=kN); return mS[i-1]; }

	// Return the character for the amino-acid at S[i-1..i+1], with i in [1..N]
	char				GetAminoAcid			(int i) { assert(i>=1 && i<=kN); return mAminoAcids[i-1]; }

	// Return whether s[i..i+1] == "gt", with i in [1..N].
	bool				IsDonor					(int i) { assert(i>=1 && i<=kN); return mIsDonor[i-1]; }

	// Return whether s[i-1..i] == "ag", with i in [1..N].
	bool				IsAcceptor				(int i) { assert(i>=1 && i<=kN); return mIsAcceptor[i-1]; }

	// Return whether s[i-2..i] == "atg", with i in [1..N].
	bool				IsGeneStart				(int i) { assert(i>=1 && i<=kN); return mIsGeneStart[i-1]; }

	// Return whether s[i+1..i+3] == "taa", "tag", or "tga", with i in [1..N].
	bool				IsGeneStop				(int i) { assert(i>=1 && i<=kN); return mIsGeneStop[i-1]; }

	// Return whether the character at index i in [1..N] is part of an exon or intron.
	bool				IsExon					(int i) { assert(i>=1 && i<=kN); return mIsExon[i-1]; }

	// Set whether the character at index i in [1..N] is part of an exon or intron.
	void				SetIsExon				(int i) { assert(i>=1 && i<=kN); mIsExon[i-1] = true; }
	void				SetIsIntron				(int i) { assert(i>=1 && i<=kN); mIsExon[i-1] = false; }

	// Mark the start-gene signal as exon, i.e. characters at position [i-2..i]. I is in [1..N].
	void				SetIsExonStartSignal	(int i);

	// Mark the stop-gene signal as exon, i.e. characters at position [i+1..i+3]. I is in [1..N].
	void				SetIsExonStopSignal		(int i);

	// Return a list of indices for the beginning and end of exons in the sequence.
	void				GetExons				(std::vector<int> &exons);

protected:
	// Return whether s[i..i+1] == "gt"
	bool				DoIsDonor				(int i); 

	// Return whether s[i-1..i] == "ag"
	bool				DoIsAcceptor			(int i); 

	// Return whether s[i-2..i] == "atg"
	bool				DoIsGeneStart			(int i); 

	// Return whether s[i+1..i+3] == "taa", "tag", or "tga"
	bool				DoIsGeneStop			(int i);

	// Create lists of booleans to indicate whether string has the given signals.
	void				InitSignals				();

	// Create the list of potential amino acids.
	void				InitAminoAcids			();

private:
	// Allocation/deletion which does not leak memory in case of allocation error.
	void				DoAllocate				();
	void				DoDelete				();

protected:
	// The following are lists of potential signals in the DNA-sequence.
	bool			*mIsDonor;			// Is there a donor at the given position.
	bool			*mIsAcceptor;		// Is there an acceptor at the given position.
	bool			*mIsGeneStart;		// Is there a start-signal at the give position.
	bool			*mIsGeneStop;		// Is there a stop-signal at the given position.

	bool			*mIsExon;			// Are characters in exons or introns.

	char			*mS;				// The string,
	char			*mAminoAcids;		// String of potential amino-acids, length is also kN
	const int		kN;					// and its length.
};
} //end namespace BioInf
