//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LGeneFind
//
//__________________________________________________________________________________________

#include "LGeneFind.h"
#include <assert.h>
#include <algorithm>

namespace BioInf
{

//__________________________________________________________________________________________
LGeneFind::LGeneFind			(LSequenceDNA &seqDNA1, LSequenceDNA &seqDNA2, int gamma, int lambda, bool flagStartStop) :
kGamma(gamma),
kLambda(lambda),
mSeqDNA1(seqDNA1),
mSeqDNA2(seqDNA2),
mFlagStartStop(flagStartStop),
mScore(0)
{
}
//__________________________________________________________________________________________
LGeneFind::~LGeneFind			()
{
}
//__________________________________________________________________________________________
void
LGeneFind::UpdateTrackAndMax	(int &max, char &track, int newScore, char newTrack)
{
	if (newScore>max)
	{
		// Update max.
		max = newScore;

		// Replace Track.
		track = newTrack;
	}
	else if (newScore == max)
	{
		// Add one more back-tracking arrow.
		track |= newTrack;
	}
}
//__________________________________________________________________________________________
void
LGeneFind::BestGeneEnd			(int &bestI, int &bestJ)
{
	int i, j, bestScore;

	bestI = bestJ = 0;
	bestScore = GetEndScore(bestI, bestJ);

	// Find the position where back-tracking is to begin from.
	for (i=1; i<mSeqDNA1.Length()+1; i++)
	{
		for (j=1; j<mSeqDNA2.Length()+1; j++)
		{
			if (mSeqDNA1.IsGeneStop(i) && mSeqDNA2.IsGeneStop(j))
			{
				int tempScore = GetEndScore(i,j);

				if (tempScore > bestScore)
				{
					bestScore = tempScore;
					bestI = i;
					bestJ = j;
				}
			}
		}
	}
}
//__________________________________________________________________________________________
bool
LGeneFind::CalcExons			()
{
	int bestI, bestJ;
	bool legalGeneFound;

	BestGeneEnd(bestI, bestJ);
	legalGeneFound = BackTrack(bestI, bestJ);

	// Flag gene's stop-signal as exons?
	if (legalGeneFound && mFlagStartStop)
	{
		mSeqDNA1.SetIsExonStopSignal(bestI);
		mSeqDNA2.SetIsExonStopSignal(bestJ);
	}

	return legalGeneFound;
}
//__________________________________________________________________________________________
} //end namespace BioInf
