// bioinf_genefind.cpp : Defines the entry point for the console application.
//

//#define TESTING

#include "stdafx.h"

#include "seqio.h"
#include "LGeneFindBas.h"
#include "LGeneFindExt.h"
#include "LScoreMatrix.h"
#include <fstream>
#include <ctime>
#include <cctype>

using namespace BioInf;

const kInputBufSize = 256;

char	gFilenameScore[kInputBufSize];
char	gFilenameScoreCodon[kInputBufSize];
char	gFiletypeInput[kInputBufSize];
char	gFilenameInput1[kInputBufSize];
char	gFilenameInput2[kInputBufSize];
char	gFilenameOutput1[kInputBufSize];
char	gFilenameOutput2[kInputBufSize];

int		gLambda;
int		gGamma;
int		gMaxSquareLength;

bool	gUseExtendedModel;

LScoreMatrix gScore;
LScoreMatrix gScoreCodon;

// Make sequence in lowercase.
void LowerCaseString(char *s, int length)
{
	for (int i=0; i<length; i++)
	{
		s[i] = std::tolower(s[i]);
	}
}

void GetParameters()
{
#ifndef TESTING

	int input;
	std::cout << "Use basic or extended alignment model (0 for basic, 1 for extended): ";
	std::cin >> input;
	gUseExtendedModel = (input != 0);

	std::cout << "Filename for score-matrix (in Phylip format): ";
	std::cin >> gFilenameScore;

	if (gUseExtendedModel)
	{
		std::cout << "Filename for codon-score-matrix (in Phylip format): ";
		std::cin >> gFilenameScoreCodon;
	}

	std::cout << "Filetype for input (e.g. GenBank or FASTA): ";
	std::cin >> gFiletypeInput;

	std::cout << "Filename for input sequence-file 1: ";
	std::cin >> gFilenameInput1;

	std::cout << "Filename for input sequence-file 2: ";
	std::cin >> gFilenameInput2;

	std::cout << "Filename for exon output file 1 (GFF-format): ";
	std::cin >> gFilenameOutput1;

	std::cout << "Filename for exon output file 2 (GFF-format): ";
	std::cin >> gFilenameOutput2;

	std::cout << "Lambda (gap-penalty e.g. -12): ";
	std::cin >> gLambda;

	std::cout << "Gamma (intron-penlaty e.g. -60): ";
	std::cin >> gGamma;

	std::cout << "Max sequence-length multiplum accepted (e.g. 100000000, or -1 for unlimited): ";
	std::cin >> gMaxSquareLength;

#else

	strcpy(gFilenameScore, "score01.txt");
	strcpy(gFilenameScoreCodon, "pam250.txt");

	strcpy(gFiletypeInput, "GenBank");
	strcpy(gFilenameInput1, "human_train.seq");
	strcpy(gFilenameInput2, "mouse_train.seq");
	strcpy(gFilenameOutput1, "human_train_pred.GFF");
	strcpy(gFilenameOutput2, "mouse_train_pred.GFF");

	gLambda = -12;
	gGamma = 5*gLambda;
	gMaxSquareLength = 5000*5000; //10000*10000;
	gUseExtendedModel = true;

#endif

	LowerCaseString(gFiletypeInput, std::strlen(gFiletypeInput));
}

// Make sequence in lowercase and replace unknown char n with a
void ProcessSequence(char *seq, int length)
{
	LowerCaseString(seq, length);

	for (int i=0; i<length; i++)
	{
		// Assign default char to all invalid (i.e. unknown) characters in the sequence.
		if (!gScore.IsValid(seq[i]))
			seq[i] = gScore.GetDefaultChar();
	}
}

// Return stripped version of a gene's name. E.g. gb:HSCD14G simply becomes HSCD14G.
// Does not allocate new memory.
char *StripGeneName(char *name)
{
	char *geneName = name;

	for (int i=0; name[i] != 0; i++)
	{
		if (name[i] == ':')
		{
			geneName = name+i+1;;
			break;
		}
	}

	return geneName;
}

void OutputExons(std::fstream &out, std::vector<int> &exons, char *name, int geneLength)
{
	char *geneName = StripGeneName(name);

	// We need a tab \t at the end of each line. Must be a bug in the GFF format?

	out << geneName << "\t" << gFiletypeInput << "\tgene\t1\t" << geneLength << "\t.\t.\t.\t" << std::endl;

	for (int i=0; i<exons.size(); i+=2)
	{
		int exonBegin = exons[i];
		int exonEnd = exons[i+1];

		out << geneName << "\t" << gFiletypeInput << "\texon\t" << exonBegin << "\t" << exonEnd << "\t.\t.\t.\t" << std::endl;
	}
}

LGeneFind *NewGeneFind(LSequenceDNA &seqDNA1, LSequenceDNA &seqDNA2)
{
	LGeneFind *geneFind=0;

	try
	{
		if (gUseExtendedModel)
		{
			LGeneFindExt *geneFindExt;
			geneFind = geneFindExt = new LGeneFindExt(seqDNA1, seqDNA2, gGamma, gLambda, true);
			geneFindExt->SetScoreCodon(&gScoreCodon);
		}
		else
		{
			geneFind = new LGeneFindBas(seqDNA1, seqDNA2, gGamma, gLambda, true);
		}

		geneFind->SetScoreMatrix(&gScore);
	}
	catch (...)
	{
		delete geneFind;
		throw;
	}

	return geneFind;
}

int _tmain(int argc, _TCHAR* argv[])
{
	std::cout << "Gene Finder - Magnus E. H. Pedersen, Algortihms in BioInformatics 2004.\nUsing SEQIO (c) 1996 James Knight, for reading sequences.\n" << std::endl;
	GetParameters();

	int len1, len2;
	char *seq1, *seq2;
	SEQFILE *sfp1, *sfp2;
	int numSeq = 0, numSeqProcessed = 0, numSeqGenesFound = 0;
	std::clock_t totalTime=0;

	std::fstream exonOut1(gFilenameOutput1, std::ios_base::out|std::ios_base::trunc);
	std::fstream exonOut2(gFilenameOutput2, std::ios_base::out|std::ios_base::trunc);

	gScore.ReadFromFile(gFilenameScore, false);

	if (gUseExtendedModel)
		gScoreCodon.ReadFromFile(gFilenameScoreCodon, false);

	// open input sequence files.
	if ((sfp1 = seqfopen(gFilenameInput1, "r", gFiletypeInput)) == NULL)
		exit (1);

	if ((sfp2 = seqfopen(gFilenameInput2, "r", gFiletypeInput)) == NULL)
		exit (1);

	do
	{
		try
		{
			// Read the next sequences from the input files.
			seq1 = seqfgetseq(sfp1, &len1, 0);
			seq2 = seqfgetseq(sfp2, &len2, 0);

			// If there were two sequences, process them.
			if (seq1 != NULL && seq2 != NULL)
			{
				numSeq++;

				std::cout << "\nFinding genes for sequence-pair no. " << numSeq << " (" << seqfmainid(sfp1, 0) << " and " << seqfmainid(sfp2, 0) << ")." << std::endl;
				std::cout << "- of length: " << len1 << " and " << len2 << ", respectively." << std::endl;

				if (gMaxSquareLength==-1 || len1*len2<=gMaxSquareLength)
				{
					std::clock_t beginTime, endTime, diffTime;

					// Ensure all chars are lowercase, and they are valid.
					ProcessSequence(seq1, len1);
					ProcessSequence(seq2, len2);

					std::cout << "- Allocating data-structures .. ";
					LSequenceDNA seqDNA1(seq1, len1);
					LSequenceDNA seqDNA2(seq2, len2);

					LGeneFind *geneFind = NewGeneFind(seqDNA1, seqDNA2);

					std::cout << "done." << std::endl << "- Aligning and back-tracking .. ";
					beginTime = std::clock();

					geneFind->CalcAlignment();
					bool validGeneFound = geneFind->CalcExons();

					endTime = std::clock();
					diffTime = endTime-beginTime;
					totalTime += diffTime;

					std::cout << "done in " << ((double) diffTime)/1000 << " seconds." << std::endl;

					std::cout << "- Deleting gene-finder object .. ";
					delete geneFind;
					std::cout << "done." << std::endl;

					if (validGeneFound)
					{
						numSeqGenesFound++;

						std::cout << "- Genes were found. Writing the exons to file .. ";

						std::vector<int> exons1, exons2;

						seqDNA1.GetExons(exons1);
						OutputExons(exonOut1, exons1, seqfmainid(sfp1, 0), len1);

						seqDNA2.GetExons(exons2);
						OutputExons(exonOut2, exons2, seqfmainid(sfp2, 0), len2);

						std::cout << "done." << std::endl;
					}
					else
					{
						std::cout << "- No valid genes were found." << std::endl;
					}

					numSeqProcessed++;
				}
				else
				{
					std::cout << "- Sequences too long, skipping this pair!" << std::endl;
				}
			}
		}
		catch (...)
		{
			std::cout << "Exception occured, skipping this pair!" << std::endl;
		}
	} while (seq1 != NULL && seq2 != NULL);

	// close sequence files.
	seqfclose(sfp1);
	seqfclose(sfp2);

	// Close streams.
	exonOut1.close();
	exonOut2.close();

	// Display various run-statistics.
	std::cout << "\nNumber of sequence pairs: " << numSeq << ", processed: " << numSeqProcessed << ", where genes were found in: " << numSeqGenesFound << std::endl;
	std::cout << "Total time usage: " << ((double) totalTime)/1000 << " seconds, average usage per processed pair: " << ((double) totalTime)/(1000*numSeqProcessed) << std::endl;

	return 0;
}
