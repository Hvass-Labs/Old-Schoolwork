//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	DoubleArray
//
//	Allocates and deletes double-arrays, used for matrices, etc.
//
//....................................................................................................................................................................................

#pragma once

#include <assert.h>

namespace ArrayOps
{

//....................................................................................................................................................................................

	// Delete array of array. size is the number of arrays, each of which is subSize long.
	template <class T> T** AllocateDoubleArray(int size, int subSize)
	{
		T **array = new T*[size]; assert(array);
		int i;

		// Ensure all sub-array pointers are zero,
		// in case of exception in the allocation of one of them.
		for (i=0; i<size; i++)
		{
			array[i] = 0;
		}

		// Now allocate the sub-arrays.
		for (i=0; i<size; i++)
		{
			array[i] = new T[subSize]; assert(array[i]);
		}

		return array;
	}

	// Delete array of array. size is the number of sub-arrays.
	template <class T> void DeleteDoubleArray(T **array, int size)
	{
		if (array)
		{
			assert(size>=0);

			for (int i=0; i<size; i++)
			{
				delete [] array[i];
			}

			delete [] array;
		}
	}

//....................................................................................................................................................................................
} //end namespace ArrayOps
