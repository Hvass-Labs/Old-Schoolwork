//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	AminoAcid
//
//__________________________________________________________________________________________

#include "AminoAcid.h"
#include <assert.h>

namespace BioInf
{

//__________________________________________________________________________________________
int
GetAminoAcidEnum						(char a[3])
{
	int aminoAcid;

	switch (a[0])
	{
	case 'g':
		switch (a[1])
		{
		case 'g': aminoAcid = eGly; break;
		case 'a': aminoAcid = (a[2] == 'g' || a[2] == 'a') ? (eGlu) : (eAsp); break;
		case 'c': aminoAcid = eAla; break;
		case 't': aminoAcid = eVal; break;
		default: aminoAcid = eUnknown;
		}
		break;

	case 'a':
		switch (a[1])
		{
		case 'g': aminoAcid = (a[2] == 'g' || a[2] == 'a') ? (eArg) : (eSer); break;
		case 'a': aminoAcid = (a[2] == 'g' || a[2] == 'a') ? (eLys) : (eAsn); break;
		case 'c': aminoAcid = eThr; break;
		case 't': aminoAcid = (a[2] == 'g') ? (eMet) : (eIle); break;
		default: aminoAcid = eUnknown;
		}
		break;

	case 'c':
		switch (a[1])
		{
		case 'g': aminoAcid = eArg; break;
		case 'a': aminoAcid = (a[2] == 'g' || a[2] == 'a') ? (eGln) : (eHis); break;
		case 'c': aminoAcid = ePro; break;
		case 't': aminoAcid = eLeu; break;
		default: aminoAcid = eUnknown;
		}
		break;

	case 't':
		switch (a[1])
		{
		case 'g':
			switch (a[2])
			{
			case 'g': aminoAcid = eTrp; break;
			case 'a': aminoAcid = eStop; break;
			case 'c':
			case 't': aminoAcid = eCys; break;
			default: aminoAcid = eUnknown;
			}
			break;
		case 'a': aminoAcid = (a[2] == 'g' || a[2] == 'a') ? (eStop) : (eTyr); break;
		case 'c': aminoAcid = eSer; break;
		case 't': aminoAcid = (a[2] == 'g' || a[2] == 'a') ? (eLeu) : (ePhe); break;
		default: aminoAcid = eUnknown;
		}

	default:
		aminoAcid = eUnknown;
	}

	return aminoAcid;
}
//__________________________________________________________________________________________
char
GetAminoAcidChar						(int e)
{
	char ch;

	switch (e)
	{
	case eAla: ch = 'a'; break;
	case eCys: ch = 'c'; break;
	case eAsp: ch = 'd'; break;
	case eGlu: ch = 'e'; break;
	case ePhe: ch = 'f'; break;
	case eGly: ch = 'g'; break;
	case eHis: ch = 'h'; break;
	case eIle: ch = 'i'; break;
	case eLys: ch = 'k'; break;
	case eLeu: ch = 'l'; break;
	case eMet: ch = 'm'; break;
	case eAsn: ch = 'n'; break;
	case ePro: ch = 'p'; break;
	case eGln: ch = 'q'; break;
	case eArg: ch = 'r'; break;
	case eSer: ch = 's'; break;
	case eThr: ch = 't'; break;
	case eVal: ch = 'v'; break;
	case eTrp: ch = 'w'; break;
	case eTyr: ch = 'y'; break;
	case eStop: ch = 'x'; break;
	case eUnknown:
	default: ch = '*';
	}

	return ch;
}
//__________________________________________________________________________________________
} //end namespace BioInf
