//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LGeneFindBas
//
//__________________________________________________________________________________________

#include "LGeneFindBas.h"
#include "DoubleArray.h"
#include <assert.h>
#include <algorithm>
#include <limits>

namespace BioInf
{

	const int kMin = std::numeric_limits<int>::min() >> 1;

//__________________________________________________________________________________________
LGeneFindBas::LGeneFindBas			(LSequenceDNA &seqDNA1, LSequenceDNA &seqDNA2, int gamma, int lambda, bool flagStartStop) :
LGeneFind(seqDNA1, seqDNA2, gamma, lambda, flagStartStop),
mCells(0),
mTrack(0)
{
	DoAllocate();
}
//__________________________________________________________________________________________
LGeneFindBas::~LGeneFindBas			()
{
	DoDelete();
}
//__________________________________________________________________________________________
void
LGeneFindBas::DoAllocate			()
{
	try
	{
		int n = mSeqDNA1.Length();
		int m = mSeqDNA2.Length();

		mCells = ArrayOps::AllocateDoubleArray<LCell>(n+1, m+1);
		mTrack = ArrayOps::AllocateDoubleArray<char>(n+1, m+1);
	}
	catch (...)
	{
		DoDelete();
		throw;
	}
}
//__________________________________________________________________________________________
void
LGeneFindBas::DoDelete				()
{
	int n = mSeqDNA1.Length();

	ArrayOps::DeleteDoubleArray<LCell>(mCells, n+1); mCells = 0;
	ArrayOps::DeleteDoubleArray<char>(mTrack, n+1); mTrack = 0;
}
//__________________________________________________________________________________________
void
LGeneFindBas::UpdateIa				(int i, int j)
{
	assert(i<mSeqDNA1.Length()+1);

	int max = kMin;

	if (i>0)
	{
		// Continue intron?
		max = mCells[i-1][j].mIa;

		// Begin new intron?
		if (mSeqDNA1.IsDonor(i))
			max = std::max(max, mCells[i-1][j].mS + kGamma);
	}

	mCells[i][j].mIa = max;
}
//__________________________________________________________________________________________
void
LGeneFindBas::UpdateIb				(int i, int j)
{
	assert(j<mSeqDNA2.Length()+1);

	int max = kMin;

	if (j>0)
	{
		// Continue intron?
		max = mCells[i][j-1].mIb;

		// Begin new intron?
		if (mSeqDNA2.IsDonor(j))
			max = std::max(max, mCells[i][j-1].mS + kGamma);
	}

	mCells[i][j].mIb = max;
}
//__________________________________________________________________________________________
int
LGeneFindBas::CalcAlignment			()
{
	assert(mScore);

	for (int i=0; i<mSeqDNA1.Length()+1; i++)
	{
		for (int j=0; j<mSeqDNA2.Length()+1; j++)
		{
			int max = kMin;
			char track = eTrackNone;

			if (i>0 && j>0)
			{
				// Character match?
				UpdateTrackAndMax(max, track, mCells[i-1][j-1].mS + CharScore(i, j), eTrackDiagonal);

				// Gene start signal?
				if (mSeqDNA1.IsGeneStart(i) && mSeqDNA2.IsGeneStart(j))
					UpdateTrackAndMax(max, track, 0, eTrackNone);
			}

			if (i>0)
			{
				// Gap in string S2?
				UpdateTrackAndMax(max, track, mCells[i-1][j].mS + kLambda, eTrackUpE);

				// End of intron in S1?
				if (mSeqDNA1.IsAcceptor(i))
					UpdateTrackAndMax(max, track, mCells[i-1][j].mIa + kGamma, eTrackUpI);
			}

			if (j>0)
			{
				// Gap in string S1?
				UpdateTrackAndMax(max, track, mCells[i][j-1].mS + kLambda, eTrackLeftE);

				// End of intron in S2?
				if (mSeqDNA2.IsAcceptor(j))
					UpdateTrackAndMax(max, track, mCells[i][j-1].mIb + kGamma, eTrackLeftI);
			}

			// Set score in mS-table.
			mCells[i][j].mS = max;

			// Update the Ia table.
			UpdateIa(i, j);

			// Update the Ib table.
			UpdateIb(i, j);

			// Set Back-Track.
			mTrack[i][j] = track;
		}
	}

	return 0;
}
//__________________________________________________________________________________________
bool
LGeneFindBas::BackTrackIa		(int i, int j)
{
	bool legalGeneFound = false;

	while (i>0)
	{
		mSeqDNA1.SetIsIntron(i);

		if (mSeqDNA1.IsDonor(i) && mCells[i-1][j].mS + kGamma > mCells[i-1][j].mIa)
		{
			legalGeneFound = BackTrackS(i-1, j);
			break;
		}
		else
		{
			i--;
		}
	}

	return legalGeneFound;
}
//__________________________________________________________________________________________
bool
LGeneFindBas::BackTrackIb		(int i, int j)
{
	bool legalGeneFound = false;

	while (j>0)
	{
		mSeqDNA2.SetIsIntron(j);

		if (mSeqDNA2.IsDonor(j) && mCells[i][j-1].mS + kGamma > mCells[i][j-1].mIb)
		{
			legalGeneFound = BackTrackS(i, j-1);
			break;
		}
		else
		{
			j--;
		}
	}

	return legalGeneFound;
}
//__________________________________________________________________________________________
bool
LGeneFindBas::BackTrackS		(int i, int j)
{
	bool legalGeneFound = false;

	while (i>=0 && j>=0)
	{
		if (IsTrackDiagonal(i,j))
		{
			mSeqDNA1.SetIsExon(i);
			mSeqDNA2.SetIsExon(j);

			i--;
			j--;
		}
		else if (IsTrackUpE(i,j))
		{
			mSeqDNA1.SetIsExon(i);

			i--;
		}
		else if (IsTrackLeftE(i,j))
		{
			mSeqDNA2.SetIsExon(j);

			j--;
		}
		else if (IsTrackUpI(i,j))
		{
			mSeqDNA1.SetIsIntron(i);
			legalGeneFound = BackTrackIa(i-1, j);
			break;
		}
		else if (IsTrackLeftI(i,j))
		{
			mSeqDNA2.SetIsIntron(j);
			legalGeneFound = BackTrackIb(i, j-1);
			break;
		}
		else // eTrackNone
		{
			// Flag gene's start-signal as exons?
			if (mFlagStartStop)
			{
				mSeqDNA1.SetIsExonStartSignal(i);
				mSeqDNA2.SetIsExonStartSignal(j);
			}

			// We have now found a legal gene.
			legalGeneFound = true;

			// Terminate recursion.
			break;
		}
	}

	return legalGeneFound;
}
//__________________________________________________________________________________________
} //end namespace BioInf
