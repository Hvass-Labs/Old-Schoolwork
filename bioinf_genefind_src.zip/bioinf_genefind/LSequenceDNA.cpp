//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LSequenceDNA
//
//__________________________________________________________________________________________

#include "LSequenceDNA.h"
#include "AminoAcid.h"

namespace BioInf
{

//__________________________________________________________________________________________
LSequenceDNA::LSequenceDNA			(char *s, int n) :
mS(s),
kN(n),
mIsDonor(0),
mIsAcceptor(0),
mIsGeneStart(0),
mIsGeneStop(0),
mIsExon(0),
mAminoAcids(0)
{
	DoAllocate();
	InitSignals();
	InitAminoAcids();
}
//__________________________________________________________________________________________
LSequenceDNA::~LSequenceDNA			()
{
	DoDelete();
}
//__________________________________________________________________________________________
void
LSequenceDNA::DoAllocate			()
{
	try
	{
		mIsDonor = new bool[kN]; assert(mIsDonor);
		mIsAcceptor = new bool[kN]; assert(mIsAcceptor);
		mIsGeneStart = new bool[kN]; assert(mIsGeneStart);
		mIsGeneStop = new bool[kN]; assert(mIsGeneStop);
		mIsExon = new bool[kN]; assert(mIsExon);
		mAminoAcids = new char[kN]; assert(mIsExon);
	}
	catch (...)
	{
		DoDelete();
		throw;
	}
}
//__________________________________________________________________________________________
void
LSequenceDNA::DoDelete				()
{
	delete [] mIsDonor; mIsDonor = 0;
	delete [] mIsAcceptor; mIsAcceptor = 0;
	delete [] mIsGeneStart; mIsGeneStart = 0;
	delete [] mIsGeneStop; mIsGeneStop = 0;
	delete [] mIsExon; mIsExon = 0;
	delete [] mAminoAcids; mAminoAcids = 0;
}
//__________________________________________________________________________________________
bool
LSequenceDNA::DoIsDonor				(int i)
{
	assert(i>=0 && i<kN-1);

	return (mS[i] == 'g' && mS[i+1] == 't');
}
//__________________________________________________________________________________________
bool
LSequenceDNA::DoIsAcceptor			(int i)
{
	assert(i>=1 && i<kN);

	return (mS[i-1] == 'a' && mS[i] == 'g');
}
//__________________________________________________________________________________________
bool
LSequenceDNA::DoIsGeneStart			(int i)
{
	assert(i>=2 && i<kN);

	return (mS[i-2] == 'a' && mS[i-1] == 't' && mS[i] == 'g');
}
//__________________________________________________________________________________________
bool
LSequenceDNA::DoIsGeneStop			(int i)
{
	assert(i>=0 && i<kN-3);

	// This should be simplified by the compiler.
	bool taa = (mS[i+1] == 't' && mS[i+2] == 'a' && mS[i+3] == 'a');
	bool tag = (mS[i+1] == 't' && mS[i+2] == 'a' && mS[i+3] == 'g');
	bool tga = (mS[i+1] == 't' && mS[i+2] == 'g' && mS[i+3] == 'a');

	return (taa || tag || tga);
}
//__________________________________________________________________________________________
void
LSequenceDNA::SetIsExonStartSignal	(int i)
{
	assert(i>=2 && i<kN);

	SetIsExon(i);
	SetIsExon(i-1);
	SetIsExon(i-2);
}
//__________________________________________________________________________________________
void
LSequenceDNA::SetIsExonStopSignal	(int i)
{
	assert(i>=0 && i<kN-3);

	SetIsExon(i+1);
	SetIsExon(i+2);
	SetIsExon(i+3);
}
//__________________________________________________________________________________________
void
LSequenceDNA::InitSignals		()
{
	assert(mS);

	for (int i=0; i<kN; i++)
	{
		mIsDonor[i] = (i<kN-1) ? (DoIsDonor(i)) : (false);
		mIsAcceptor[i] = (i>=1) ? (DoIsAcceptor(i)) : (false);
		mIsGeneStart[i] = (i>=2) ? (DoIsGeneStart(i)) : (false);
		mIsGeneStop[i] = (i<kN-3) ? (DoIsGeneStop(i)) : (false);
		mIsExon[i] = false;
	}
}
//__________________________________________________________________________________________
void
LSequenceDNA::InitAminoAcids		()
{
	assert(mAminoAcids);

	mAminoAcids[0] = mAminoAcids[kN-1] = eUnknown;

	for (int i=1; i<kN-1; i++)
	{
		mAminoAcids[i] = GetAminoAcidChar(GetAminoAcidEnum(&mS[i-1]));
	}
}
//__________________________________________________________________________________________
void
LSequenceDNA::GetExons			(std::vector<int> &exons)
{
	int i;
	bool wasExon;

	for (i=1, wasExon=false; i<=Length(); i++)
	{
		bool isExon = IsExon(i);

		if (isExon && !wasExon)
		{
			exons.push_back(i);
		}
		else if (wasExon && !isExon)
		{
			exons.push_back(i-1);
		}

		wasExon = isExon;
	}

	// Was the last character of the sequence part of an exon?
	if (wasExon && Length()>0)
	{
		exons.push_back(Length());
	}
}
//__________________________________________________________________________________________
} //end namespace BioInf
