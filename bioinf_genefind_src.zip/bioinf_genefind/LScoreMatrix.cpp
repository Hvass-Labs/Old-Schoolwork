//__________________________________________________________________________________________
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LScoreMatrix
//
//__________________________________________________________________________________________

#include "LScoreMatrix.h"
#include "DoubleArray.h"
#include <limits>
#include <fstream>
#include <cctype>
#include <assert.h>

namespace BioInf
{

//__________________________________________________________________________________________
LScoreMatrix::LScoreMatrix				() :
LScore(),
mAlphabetSize(0),
mScores(0),
mIndexMap(0),
mAlphabet(0)
{
}
//__________________________________________________________________________________________
LScoreMatrix::~LScoreMatrix				()
{
	DoDelete();
}
//__________________________________________________________________________________________
void
LScoreMatrix::DoAllocate				()
{
	try
	{
		assert(mAlphabetSize>0);

		int maxNumChars = std::numeric_limits<unsigned char>::max();
		int i;

		mIndexMap = new int[maxNumChars]; assert(mIndexMap);
		mAlphabet = new char[mAlphabetSize]; assert(mAlphabet);
		mScores = ArrayOps::AllocateDoubleArray<int>(mAlphabetSize, mAlphabetSize);

		// Initialize index-map
		for (i=0; i<maxNumChars; i++)
		{
			mIndexMap[i] = -1;
		}
	}
	catch (...)
	{
		DoDelete();
		throw;
	}
}
//__________________________________________________________________________________________
void
LScoreMatrix::DoDelete					()
{
	ArrayOps::DeleteDoubleArray(mScores, mAlphabetSize); mScores = 0;

	delete [] mIndexMap; mIndexMap = 0;
	delete [] mAlphabet; mAlphabet = 0;

	mAlphabetSize = 0;
}
//__________________________________________________________________________________________
void
LScoreMatrix::ReadFromFile				(char *filename, bool symmetric)
{
	assert(filename);
	int i, j;

	std::ifstream infile(filename); assert(infile);

	infile >> mAlphabetSize; infile.ignore(std::numeric_limits<int>::max(), '\n'); assert(mAlphabetSize>0);

	DoAllocate();

	for (i=0; i<mAlphabetSize; i++)
	{
		char ch;
		infile.get(ch);
		SetCharIndex(std::tolower(ch), i);

		int upTo = (symmetric) ? (i+1) : (mAlphabetSize);
		for (j=0; j<upTo; j++)
		{
			int score;
			infile >> score;
			SetScore(i, j, score);
		}

		infile.ignore(std::numeric_limits<int>::max(), '\n');
	}

	// Duplicate scores to upper triangle, if matrix is symmetric.
	if (symmetric)
	{
		for (i=0; i<mAlphabetSize; i++)
		{
			for (j=i+1; j<mAlphabetSize; j++)
			{
				SetScore(i, j, GetScore(j, i));
			}
		}
	}
}
//__________________________________________________________________________________________
void
LScoreMatrix::SetCharIndex				(char a, int index)
{
	assert(index>=0 && index<mAlphabetSize);	// Check that the index is valid.
	assert(GetIndex(a) == -1);					// Check that the index isn't used.

	mIndexMap[a] = index;
	mAlphabet[index] = a;
}
//__________________________________________________________________________________________
void
LScoreMatrix::SetScore					(int aIndex, int bIndex, int score)
{
	assert(aIndex>= 0 && aIndex<mAlphabetSize);
	assert(bIndex>= 0 && bIndex<mAlphabetSize);

	mScores[aIndex][bIndex] = score;
}
//__________________________________________________________________________________________
int
LScoreMatrix::GetScore					(int aIndex, int bIndex)
{
	assert(aIndex>= 0 && aIndex<mAlphabetSize);
	assert(bIndex>= 0 && bIndex<mAlphabetSize);

	return mScores[aIndex][bIndex];
}
//__________________________________________________________________________________________
int
LScoreMatrix::Score						(char a, char b)
{
	int aIndex = GetIndex(a);
	int bIndex = GetIndex(b);

	assert(aIndex != -1);
	assert(bIndex != -1);

	return mScores[aIndex][bIndex];
}
//__________________________________________________________________________________________
} //end namespace BioInf
