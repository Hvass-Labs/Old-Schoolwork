//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LGeneFindBas
//
//	The basic local-alignment algorithm for finding eukaryotic genes.
//
//....................................................................................................................................................................................

#pragma once

#include "LGeneFind.h"
#include "LSequenceDNA.h"
#include "LScore.h"

namespace BioInf
{

//....................................................................................................................................................................................
class	LGeneFindBas : public LGeneFind
{
public:
	LGeneFindBas								(LSequenceDNA &seqDNA1, LSequenceDNA &seqDNA2, int gamma, int lambda, bool flagStartStop);
	virtual ~LGeneFindBas						();

	// Perform the alignment and return the score.
	virtual int			CalcAlignment			();

protected:
	// Recursive back-tracking algorithms. Assume that Calculate() has been called.
	// Call BackTrackS(bestI, bestJ) where bestI and bestJ are obtained from BestGeneEnd().
	bool				BackTrackS				(int i, int j);
	bool				BackTrackIa				(int i, int j);
	bool				BackTrackIb				(int i, int j);

	// Compute the intron-score for sequence mSeqDNA1 at position (i,j).
	virtual void		UpdateIa				(int i, int j);

	// Compute the intron-score for sequence mSeqDNA2 at position (i,j).
	virtual void		UpdateIb				(int i, int j);

	// Return the back-tracking arrow for table mS and cell (i,j).
	char				GetTrack				(int i, int j) { return mTrack[i][j]; }

	// Return whether the backtrack-arrow at position (i,j) is of the given type.
	bool				IsTrackUpE				(int i, int j) { return IsTrack(GetTrack(i,j), eTrackUpE); }
	bool				IsTrackUpI				(int i, int j) { return IsTrack(GetTrack(i,j), eTrackUpI); }
	bool				IsTrackLeftE			(int i, int j) { return IsTrack(GetTrack(i,j), eTrackLeftE); }
	bool				IsTrackLeftI			(int i, int j) { return IsTrack(GetTrack(i,j), eTrackLeftI); }
	bool				IsTrackDiagonal			(int i, int j) { return IsTrack(GetTrack(i,j), eTrackDiagonal); }

	virtual bool		BackTrack				(int i, int j) { return BackTrackS(i, j); }
	virtual int			GetEndScore				(int i, int j) { return mCells[i][j].mS; }

private:
	// Allocation/deletion which does not leak memory in case of allocation error.
	void				DoAllocate				();
	void				DoDelete				();

private:
	// Holds cell-values for S, Ia, and Ib tables.
	class	LCell
	{
	public:
		LCell			() {}

		int				mS;						// Score for overall alignment.
		int				mIa;					// Score for intron in S1.
		int				mIb;					// Score for intron in S2.
	};

protected:
	LCell			**mCells;				// S, Ia, and Ib tables.
	char			**mTrack;				// Back-tracking table.
};
} //end namespace BioInf
