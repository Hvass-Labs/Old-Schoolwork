//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LScoreMatrix
//
//	### What's it used for?
//
//....................................................................................................................................................................................

#pragma once

#include "LScore.h"
#include <limits>

namespace BioInf
{

//....................................................................................................................................................................................
class	LScoreMatrix : public LScore
{
public:
	LScoreMatrix								();
	virtual ~LScoreMatrix						();

	virtual int			Score					(char a, char b);

	virtual bool		IsValid					(char a) { return mIndexMap[a] != -1; }

	virtual char		GetDefaultChar			() { return mAlphabet[0]; }

	void				ReadFromFile			(char *filename, bool symmetric);

protected:
	// Set the character a to be the index'th element of the alphabet
	void				SetCharIndex			(char a, int index);

	void				SetScore				(int aIndex, int bIndex, int score);

	int					GetScore				(int aIndex, int bIndex);

private:
	int					GetIndex				(char a) { return mIndexMap[a]; }

	void				DoAllocate				();

	void				DoDelete				();

private:
	int			**mScores;
	int			*mIndexMap;
	char		*mAlphabet;

	int			mAlphabetSize;
};
} //end namespace BioInf
