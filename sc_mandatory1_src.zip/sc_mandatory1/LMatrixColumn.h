//....................................................................................................................................................................................
//
//	Copyright (C) 2005, Magnus EH Pedersen
//
//	LMatrixColumn
//
//	Abstract reference to a certain column in a certain matrix.
//	Allows addressing elements of that column as if it were a vector/array.
//
//....................................................................................................................................................................................

#pragma once

#include <cassert>

namespace MatrixOps
{

//....................................................................................................................................................................................
// Forward declaration
template <typename T> class LMatrix; 
//....................................................................................................................................................................................
template <typename T>
class LMatrixColumn
{
public:
	LMatrixColumn							(LMatrix<T>& matrix, const int j) : mMatrix(matrix), kIndexJ(j) {}

	inline T&					operator[]	(const int i) { return mMatrix.Elm(i, kIndexJ); }

protected:
	LMatrix<T>&		mMatrix;
	const int		kIndexJ;
};
//....................................................................................................................................................................................
} //end namespace MatrixOps
