//__________________________________________________________________________________________
//
//	Copyright (C) 2003-2005 by Thurs. All rights reserved.
//
//	LYggRandom1
//
//	Magnus EH Pedersen
//
//__________________________________________________________________________________________

#include "LYggRandom1.h"
#include <limits.h>
#include <math.h>

namespace Yggdrasil
{

const long		IA = 16807;
const long		IQ = 127773;
const long		IR = 2836;
const long		IM = LONG_MAX; // 2147483647 for 32-bit signed long
const long		NDIV = 1 + (IM-1)/LYggRandom1::NTAB;

//__________________________________________________________________________________________
LYggRandom1::LYggRandom1		(long seed) :
LYggRandom(),
mIdum(seed),
mIy(0)
{
	Initialize(seed);
}
//__________________________________________________________________________________________
void
LYggRandom1::Initialize			(long seed)
{
	LYggRandom::Initialize(seed);

	mIdum = seed;

	// Ensure initial (i.e. seed) mIdum>0
	if (mIdum == 0)
		mIdum = 1;
	else if (mIdum < 0)
		mIdum = -mIdum;

	// Generate initial shuffle table
	DoInitialize();
}
//__________________________________________________________________________________________
void
LYggRandom1::DoInitialize			()
{
	int j;

	// Generate the shuffle table (after 8 warm-ups).
	for (j=0; j<8; j++)
		DoRand();

	for (j=NTAB-1;j>=0;j--)
	{
		DoRand();
		mIv[j] = mIdum;
	}

	mIy=mIv[0];
}
//__________________________________________________________________________________________
void
LYggRandom1::DoRand				()
{
	assert(mIdum != 0);

	long k=mIdum/IQ;
	mIdum=IA*(mIdum-k*IQ)-IR*k;			// Compute idum=(IA*idum) % IM without over-
	if (mIdum < 0) mIdum += IM;			// flows by Schrage's method.
}
//__________________________________________________________________________________________
long
LYggRandom1::Rand				()
{
	DoRand();

	{
		int j=mIy/NDIV; assert(j>=0 && j<NTAB);		// Will be in the range 0..NTAB-1.
		mIy=mIv[j];									// Output previously stored value and refill the shuffle table.
		mIv[j] = mIdum;
	}

	return mIy;
}
//__________________________________________________________________________________________
} //end namespace Yggdrasil
