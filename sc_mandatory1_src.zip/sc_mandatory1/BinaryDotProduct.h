//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	BinaryDotProduct.
//
//	Computes the dot product of two vectors. Computation is organized as a binary tree,
//	so as to lower rounding errors. A recursive implementation is given.
//
//	Not all C++ compilers may optimize and/or generate numerically precise code for
//	template functions, so you may need to implement as non-template function for the
//	data-type you need. Use with care, and conduct thorough testing.
//
//	In any case, it is recommended that double-precision is used. On new computers this
//	should not cause any (significant) degradation in performance.
//
//....................................................................................................................................................................................

#pragma once

#include <cassert>

namespace ArrayOps
{

//....................................................................................................................................................................................

// Compute and return the dot-product of x and y, both of length n, and offset by index i.
template <typename T, class T1, class T2>
T		BinaryDotProduct		(T1& x, T2& y, unsigned int n, unsigned int i = 0)
{
	if (n == 1)
	{
		return x[i] * y[i];
	}
	else if (n >= 2)
	{
		// Split array into two sub-arrays of size m1 and m2, and call recursively.

		const unsigned int m1 = n >> 1; // m1 = n/2
		const unsigned int m2 = n-m1;

		return BinaryDotProduct<T>(x, y, m1, i) + BinaryDotProduct<T>(x, y, m2, m1);
	}
	else // n == 0
	{
		return 0;
	}
}

//....................................................................................................................................................................................
} //end namespace ArrayOps
