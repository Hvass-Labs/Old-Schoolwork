//__________________________________________________________________________________________
//
//	Copyright (C) 2005, Magnus EH Pedersen
//
//	MatrixInitialize
//
//__________________________________________________________________________________________

#include "MatrixInitialize.h"

namespace MatrixOps
{

//__________________________________________________________________________________________
void InitializeZero(double* A, unsigned int n, unsigned int m)
{
	for (int k=0; k<n*m; k++)
		A[k] = 0;
}
//__________________________________________________________________________________________
void InitializeRandom(double* A, unsigned int n, unsigned int m)
{
	// Assign uniform values between (-1,1), that is ~U(-1,1).

	for (int k=0; k<n*m; k++)
		A[k] = gRandom.RandBi();
}
//__________________________________________________________________________________________
int InitializeEnumerate(double* A, unsigned int n, unsigned int m, int k)
{
	for (int i=0; i<n*m; i++)
	{
		A[i] = k;
		k++;
	}

	return k;
}
//__________________________________________________________________________________________
int InitializeEnumerate_Reverse(double* A, unsigned int n, unsigned int m, int k)
{
	for (int i=0; i<n; i++)
	{
		for (int j=0; j<m; j++)
		{
			A[j*n+i] = k;
			k++;
		}
	}

	return k;
}
//__________________________________________________________________________________________
} //end namespace MatrixOps
