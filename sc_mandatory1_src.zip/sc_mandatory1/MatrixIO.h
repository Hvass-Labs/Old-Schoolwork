//....................................................................................................................................................................................
//
//	Copyright (C) 2005, Magnus EH Pedersen
//
//	MatrixIO
//
//	Stream input/output in MatLab format of an LMatrix object.
//
//....................................................................................................................................................................................

#pragma once

#include "LMatrix.h"
#include <ostream>
#include <cassert>

namespace MatrixOps
{
//....................................................................................................................................................................................
template <typename T>
std::ostream&
operator<<(std::ostream& out, LMatrix<T>& A)
{
	// Dimensionalities.
	const int n = A.GetN();
	const int m = A.GetM();

	// Output matrix start-delimiter.
	out << "[";

	for (int i=0; i<n; i++)
	{
		for (int j=0; j<m; j++)
		{
			// Output element at (i,j)'th position.
			out << A.Elm(i,j);

			// Output new-element-spacing if needed.
			if (j<m-1)
				out << " ";
		}

		// Output new-row-spacing if needed.
		if (i<n-1)
			out << ";";
	}

	// Output matrix end-delimiter.
	out << "]";

	return out;
};
//....................................................................................................................................................................................
} //end namespace MatrixOps
