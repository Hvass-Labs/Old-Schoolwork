// sc_mandatory1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "MatrixIO.h"
#include "MatrixMultiply.h"
#include "MatrixInitialize.h"
#include "LMatrixSingleArray.h"
#include "LMatrixDoubleArray.h"
#include "LMatrixReverse.h"

#include "LYggRandom1.h"

#include <ctime>

Yggdrasil::LYggRandom1 gRandom(87358739);

using namespace MatrixOps;

int _tmain(int argc, _TCHAR* argv[])
{
	// Matrix sizes.
	//const int kN = 16, kM = 8, kP = 32, kNumRuns = 100000;
	//const int kN = 64, kM = 512, kP = 128, kNumRuns = 100;
	const int kN = 2048, kM = 512, kP = 1024, kNumRuns = 1;
	//const int kN = 3, kM = 3, kP = 2, kNumRuns = 1;

	// Abstract storage.
	//LMatrixDoubleArray<double> A(kN, kP), C(kN, kM);
	//LMatrixReverse<double, LMatrixDoubleArray<double> > B(kP, kM);
	//LMatrixDoubleArray<double> B(kP, kM);

	// Two-dimensional arrays.
	//double** A = ArrayOps::AllocateDoubleArray<double>(kN, kP);
	//double** C = ArrayOps::AllocateDoubleArray<double>(kN, kM);
	//double** B = ArrayOps::AllocateDoubleArray<double>(kP, kM);

	// One-dimensional arrays.
	double* A = new double[kN*kP];
	double* C = new double[kN*kM];
	double* B = new double[kP*kM];

	std::clock_t beginTime, endTime;

	// Initialization for performance testing.
	InitializeRandom(A, kN, kP);
	InitializeRandom(B, kP, kM);

	// Initialization for testing of correctness.
	//int k = InitializeEnumerate(A, kN, kP);
	//InitializeEnumerate(B, kP, kM, k);
	//InitializeEnumerate_Reverse(B, kP, kM, k);

	beginTime = std::clock();
	for (int i=0; i<kNumRuns; i++)
	{
		//Multiply(C, A, B);
		//Multiply_BinDotProduct(C, A, B);
		//Multiply_ijk(C, A, B);
		//Multiply_ikj(C, A, B);
		//Multiply_jki(C, A, B);
		//Multiply_jik(C, A, B);
		//Multiply_kij(C, A, B);
		//Multiply_kji(C, A, B);
		//Multiply_ikj(C, A, B, kN, kM, kP);
		//Multiply_Reverse(C, A, B, kN, kM, kP);
		Multiply_Block_ikj(C, A, B, kN, kM, kP);
		//Multiply_ikj<double**>(C, A, B, kN, kM, kP);
	}
	endTime = std::clock();

	std::cout << "(n, m, p) = (" << kN << ", " << kM << ", " << kP << ")\n";
	//std::cout << "A = " << A << "\n";
	//std::cout << "B = " << B << "\n";
	//std::cout << "C = " << C << "\n";

	// Test for correctness against Multiply_ikj() which is assumed to be correct.
	{
		std::cout << "Checking with control matrix .. ";
		double* D = new double[kN*kM];
		Multiply_ikj(D, A, B, kN, kM, kP);
		bool identical = true;

		for (int i=0; i<kN*kM && identical; i++)
			identical = (C[i] == D[i]);

		if (identical)
			std::cout << "identical.\n";
		else
			std::cout << "Mismatch!\n";
	}

	std::cout << "Time spent: " << (double) (endTime-beginTime)/kNumRuns << " milli-seconds per multiplication" << std::endl;

	return 0;
}

