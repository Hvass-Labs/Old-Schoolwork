//....................................................................................................................................................................................
//
//	Copyright (C) 2005, Magnus EH Pedersen
//
//	LMatrix
//
//	Base-class for storage of a matrix.
//	n is the number of rows, m is the number of columns.
//
//....................................................................................................................................................................................

#pragma once

#include "LMatrixRow.h"
#include "LMatrixColumn.h"
#include <cassert>

namespace MatrixOps
{
//....................................................................................................................................................................................
template <typename T>
class LMatrix
{
public:
	LMatrix									(const int n, const int m) : kN(n), kM(m)
	{
		assert(n>0 && m>0);
	}

	virtual ~LMatrix						() {}

	// Same as the Row() function below, but allows addressing elements as A[i][j].
	inline LMatrixRow<T>		operator[]	(const int i) { return Row(i); }

	// Return an abstract representation for the i'th row of the matrix.
	inline LMatrixRow<T>		Row			(const int i) { return LMatrixRow<T>(*this, i); }

	// Return an abstract representation for the j'th column of the matrix.
	inline LMatrixColumn<T>		Column		(const int j) { return LMatrixColumn<T>(*this, j); }

	// Return a reference to the element stored at the i'th row and j'th column.
	virtual T&					Elm			(const int i, const int j) = 0;

	// Return number of rows.
	virtual int					GetN		() { return kN; }

	// Return number of columns.
	virtual int					GetM		() { return kM; }

protected:
	const int	kN, kM;		// Dimensionality of matrix.
};
//....................................................................................................................................................................................
} //end namespace MatrixOps
