//....................................................................................................................................................................................
//
//	Copyright (C) 2005, Magnus EH Pedersen
//
//	LMatrixReverse
//
//	Stores a matrix as its transpose, yet matrix size and element indices are non-transposed.
//	This allows the traversal of columns in a matrix, in the order in which the elements
//	are actually stored in memory, so as to increase cache performance.
//
//....................................................................................................................................................................................

#pragma once

#include "LMatrix.h"
#include <cassert>

namespace MatrixOps
{
//....................................................................................................................................................................................
template <typename T, class M>
class LMatrixReverse : public M
{
public:
	LMatrixReverse							(const int n, const int m) : M(m, n) {}

	// Return a reference to the element stored at the i'th row and j'th column.
	virtual T&					Elm			(const int i, const int j) { return M::Elm(j,i); }

	// Return number of rows.
	virtual int					GetN		() { return kM; }

	// Return number of columns.
	virtual int					GetM		() { return kN; }
};
//....................................................................................................................................................................................
} //end namespace MatrixOps
