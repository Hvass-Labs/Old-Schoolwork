//__________________________________________________________________________________________
//
//	Copyright (C) 2005, Magnus EH Pedersen
//
//	MatrixMultiply
//
//__________________________________________________________________________________________

#include "MatrixMultiply.h"
#include "MatrixInitialize.h"
#include <algorithm>

namespace MatrixOps
{

//__________________________________________________________________________________________
void Multiply_ikj(double** C, double** A, double** B, int n, int m, int p)
{
	assert(C && A && B && n>=0 && m>=0 && p>=0);

	InitializeZero(C, n, m);

	for (int i=0; i<n; i++)
		for (int k=0; k<p; k++)
			for (int j=0; j<m; j++)
				C[i][j] += A[i][k] * B[k][j];
}
//__________________________________________________________________________________________
void Multiply_ikj(double* C, double* A, double* B, int n, int m, int p)
{
	assert(C && A && B && n>=0 && m>=0 && p>=0);

	InitializeZero(C, n, m);

	for (int i=0; i<n; i++)
		for (int k=0; k<p; k++)
			for (int j=0; j<m; j++)
				C[i*m+j] += A[i*p+k] * B[k*m+j];
}
//__________________________________________________________________________________________
// Assumes B is stored as its own tranpose.
void Multiply_Reverse(double* C, double* A, double* B, int n, int m, int p)
{
	assert(C && A && B && n>=0 && m>=0 && p>=0);

	for (int i=0; i<n; i++)
	{
		for (int j=0; j<m; j++)
		{
			double c = 0;

			for (int k=0; k<p; k++)
			{
				c += A[i*p+k] * B[j*p+k];
			}

			C[i*m+j] = c;
		}
	}
}
//__________________________________________________________________________________________
void Do_Multiply_Block_ikj(double* C, double* A, double* B,
						   int n,  int m,  int p,	// Actual matrix sizes.
						   int n0, int m0, int p0,	// Start-indices for block.
						   int n1, int m1, int p1)	// End-indices for block.
{
	assert(C && A && B && n>=0 && m>=0 && p>=0);
	assert(n0 >= 0 && n0<n1 && n1 <= n);
	assert(m0 >= 0 && m0<m1 && m1 <= m);
	assert(p0 >= 0 && p0<p1 && p1 <= p);

	for (int i=n0; i<n1; i++)
		for (int k=p0; k<p1; k++)
			for (int j=m0; j<m1; j++)
				C[i*m+j] += A[i*p+k] * B[k*m+j];
}
//__________________________________________________________________________________________
void Multiply_Block_ikj(double* C, double* A, double* B,
						int n, int m, int p,
						int blockSize)
{
	assert(C && A && B && n>=0 && m>=0 && p>=0 && blockSize>0);

	InitializeZero(C, n, m);

	for (int n0=0; n0<n;)
	{
		int n1 = std::min(n0+blockSize, n);

		for (int p0=0; p0<p;)
		{
			int p1 = std::min(p0+blockSize, p);

			for (int m0=0; m0<m;)
			{
				int m1 = std::min(m0+blockSize, m);

				Do_Multiply_Block_ikj(C, A, B, n, m, p, n0, m0, p0, n1, m1, p1);

				m0 = m1;
			}

			p0 = p1;
		}

		n0 = n1;
	}
}
//__________________________________________________________________________________________
} //end namespace MatrixOps
