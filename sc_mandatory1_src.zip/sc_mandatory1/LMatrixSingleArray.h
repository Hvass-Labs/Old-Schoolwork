//....................................................................................................................................................................................
//
//	Copyright (C) 2005, Magnus EH Pedersen
//
//	LMatrixSingleArray
//
//	Storage of a matrix in a single-dimensional array.
//
//....................................................................................................................................................................................

#pragma once

#include "LMatrix.h"
#include <cassert>

namespace MatrixOps
{

//....................................................................................................................................................................................
template <typename T>
class LMatrixSingleArray : public LMatrix<T>
{
public:
	LMatrixSingleArray						(const int n, const int m) : LMatrix<T>(n, m), mElms(0)
	{
		mElms = new T[n*m];
	}

	virtual ~LMatrixSingleArray				()
	{
		delete [] mElms;
	}

	// Return a reference to the element stored at the i'th row and j'th column.
	virtual T&					Elm			(const int i, const int j)
	{
		assert(i>=0 && i<kN);
		assert(j>=0 && j<kM);

		return mElms[i*kM + j];
	}

protected:
	T*			mElms;		// Array storing elements of matrix.
};
//....................................................................................................................................................................................
} //end namespace MatrixOps
