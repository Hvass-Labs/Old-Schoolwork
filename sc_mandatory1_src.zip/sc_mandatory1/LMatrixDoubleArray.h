//....................................................................................................................................................................................
//
//	Copyright (C) 2005, Magnus EH Pedersen
//
//	LMatrixDoubleArray
//
//	Storage of a matrix in a two-dimensional array (i.e. array of arrays).
//
//....................................................................................................................................................................................

#pragma once

#include "LMatrix.h"
#include "DoubleArray.h"
#include <cassert>

namespace MatrixOps
{
//....................................................................................................................................................................................
template <typename T>
class LMatrixDoubleArray : public LMatrix<T>
{
public:
	LMatrixDoubleArray						(const int n, const int m) : LMatrix<T>(n, m), mElms(0)
	{
		mElms = ArrayOps::AllocateDoubleArray<T>(n, m, 0);
	}

	virtual ~LMatrixDoubleArray				()
	{
		ArrayOps::DeleteDoubleArray<T>(mElms, kN);
	}

	// Return a reference to the element stored at the i'th row and j'th column.
	virtual T&					Elm			(const int i, const int j)
	{
		assert(i>=0 && i<kN);
		assert(j>=0 && j<kM);

		return mElms[i][j];
	}

protected:
	T**			mElms;		// Double-array storing elements of matrix.
};
//....................................................................................................................................................................................
} //end namespace MatrixOps
