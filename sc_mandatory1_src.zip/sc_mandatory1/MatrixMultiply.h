//....................................................................................................................................................................................
//
//	Copyright (C) 2005, Magnus EH Pedersen
//
//	MatrixMultiply
//
//	Various algorithms for performing matrix-matrix multiplication: C = A*B
//
//	C has n rows and m columns.
//	A has n rows and p columns.
//	B has p rows and m columns.
//
//....................................................................................................................................................................................

#pragma once

#include "LMatrix.h"
#include "MatrixInitialize.h"
#include "BinaryDotProduct.h"
#include <cassert>

namespace MatrixOps
{

//....................................................................................................................................................................................
void Multiply_ikj(double** C, double** A, double** B, int n, int m, int p);
//....................................................................................................................................................................................
void Multiply_ikj(double* C, double* A, double* B, int n, int m, int p);
//....................................................................................................................................................................................
void Multiply_Block_ikj(double* C, double* A, double* B, int n, int m, int p, int blockSize = 256);
//....................................................................................................................................................................................
// Assumes B is stored as its own tranpose.
void Multiply_Reverse(double* C, double* A, double* B, int n, int m, int p);
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply(LMatrix<T>& C, LMatrix<U>& A, LMatrix<V>& B)
{
	// Dimensionalities.
	const int n = C.GetN();
	const int m = C.GetM();
	const int p = A.GetM();

	// Ensure dimensionalities of supplied matrices are correct.
	assert(n == A.GetN() && m == B.GetM() && p == B.GetN());

	for (int i=0; i<n; i++)
	{
		for (int j=0; j<m; j++)
		{
			T elm = 0;

			for (int k=0; k<p; k++)
			{
				elm += A[i][k] * B[k][j];
			}

			C[i][j] = elm;
		}
	}
};
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_ijk(T& C, U& A, V& B)
{
	// Dimensionalities.
	const int n = C.GetN();
	const int m = C.GetM();
	const int p = A.GetM();

	// Ensure dimensionalities of supplied matrices are correct.
	assert(n == A.GetN() && m == B.GetM() && p == B.GetN());

	Multiply_ijk(C, A, B, n, m, p);
}
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_ijk(T& C, U& A, V& B, int n, int m, int p)
{
	assert(n>=0 && m>=0 && p>=0);

	InitializeZero(C, n, m);

	for (int i=0; i<n; i++)
		for (int j=0; j<m; j++)
			for (int k=0; k<p; k++)
				C[i][j] += A[i][k] * B[k][j];
}
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_ikj(LMatrix<T>& C, LMatrix<U>& A, LMatrix<V>& B)
{
	// Dimensionalities.
	const int n = C.GetN();
	const int m = C.GetM();
	const int p = A.GetM();

	// Ensure dimensionalities of supplied matrices are correct.
	assert(n == A.GetN() && m == B.GetM() && p == B.GetN());

	Multiply_ikj(C, A, B, n, m, p);
}
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_ikj(T& C, U& A, V& B, int n, int m, int p)
{
	assert(n>=0 && m>=0 && p>=0);

	InitializeZero(C, n, m);

	for (int i=0; i<n; i++)
		for (int k=0; k<p; k++)
			for (int j=0; j<m; j++)
				C[i][j] += A[i][k] * B[k][j];
}
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_jki(T& C, U& A, V& B)
{
	// Dimensionalities.
	const int n = C.GetN();
	const int m = C.GetM();
	const int p = A.GetM();

	// Ensure dimensionalities of supplied matrices are correct.
	assert(n == A.GetN() && m == B.GetM() && p == B.GetN());

	Multiply_jki(C, A, B, n, m, p);
}
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_jki(T& C, U& A, V& B, int n, int m, int p)
{
	assert(n>=0 && m>=0 && p>=0);

	InitializeZero(C, n, m);

	for (int j=0; j<m; j++)
		for (int k=0; k<p; k++)
			for (int i=0; i<n; i++)
				C[i][j] += A[i][k] * B[k][j];
}
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_jik(T& C, U& A, V& B)
{
	// Dimensionalities.
	const int n = C.GetN();
	const int m = C.GetM();
	const int p = A.GetM();

	// Ensure dimensionalities of supplied matrices are correct.
	assert(n == A.GetN() && m == B.GetM() && p == B.GetN());

	Multiply_jik(C, A, B, n, m, p);
}
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_jik(T& C, U& A, V& B, int n, int m, int p)
{
	assert(n>=0 && m>=0 && p>=0);

	InitializeZero(C, n, m);

	for (int j=0; j<m; j++)
		for (int i=0; i<n; i++)
			for (int k=0; k<p; k++)
				C[i][j] += A[i][k] * B[k][j];
}
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_kij(T& C, U& A, V& B)
{
	// Dimensionalities.
	const int n = C.GetN();
	const int m = C.GetM();
	const int p = A.GetM();

	// Ensure dimensionalities of supplied matrices are correct.
	assert(n == A.GetN() && m == B.GetM() && p == B.GetN());

	Multiply_kij(C, A, B, n, m, p);
}
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_kij(T& C, U& A, V& B, int n, int m, int p)
{
	assert(n>=0 && m>=0 && p>=0);

	InitializeZero(C, n, m);

	for (int k=0; k<p; k++)
		for (int i=0; i<n; i++)
			for (int j=0; j<m; j++)
				C[i][j] += A[i][k] * B[k][j];
}
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_kji(T& C, U& A, V& B)
{
	// Dimensionalities.
	const int n = C.GetN();
	const int m = C.GetM();
	const int p = A.GetM();

	// Ensure dimensionalities of supplied matrices are correct.
	assert(n == A.GetN() && m == B.GetM() && p == B.GetN());

	Multiply_kji(C, A, B, n, m, p);
}
//....................................................................................................................................................................................
template <typename T, typename U, typename V>
void Multiply_kji(T& C, U& A, V& B, int n, int m, int p)
{
	assert(n>=0 && m>=0 && p>=0);

	InitializeZero(C, n, m);

	for (int k=0; k<p; k++)
		for (int j=0; j<m; j++)
			for (int i=0; i<n; i++)
				C[i][j] += A[i][k] * B[k][j];
}
//....................................................................................................................................................................................
template <typename T>
void Multiply_BinDotProduct(LMatrix<T>& C, LMatrix<T>& A, LMatrix<T>& B)
{
	// Dimensionalities.
	const int n = C.GetN();
	const int m = C.GetM();
	const int p = A.GetM();

	// Ensure dimensionalities of supplied matrices are correct.
	assert(n == A.GetN() && m == B.GetM() && p == B.GetN());

	for (int i=0; i<n; i++)
		for (int j=0; j<m; j++)
			C[i][j] = ArrayOps::BinaryDotProduct<T>(A.Row(i), B.Column(j), p);
}
//....................................................................................................................................................................................
} //end namespace MatrixOps
