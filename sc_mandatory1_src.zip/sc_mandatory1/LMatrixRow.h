//....................................................................................................................................................................................
//
//	Copyright (C) 2005, Magnus EH Pedersen
//
//	LMatrixRow
//
//	Abstract reference to a certain row in a certain matrix.
//	Allows addressing elements of that row as if it were a vector/array.
//
//....................................................................................................................................................................................

#pragma once

#include <cassert>

namespace MatrixOps
{

//....................................................................................................................................................................................
// Forward declaration
template <typename T> class LMatrix; 
//....................................................................................................................................................................................
template <typename T>
class LMatrixRow
{
public:
	LMatrixRow								(LMatrix<T>& matrix, const int i) : mMatrix(matrix), kIndexI(i) {}

	inline T&					operator[]	(const int j) { return mMatrix.Elm(kIndexI, j); }

protected:
	LMatrix<T>&		mMatrix;
	const int		kIndexI;
};
//....................................................................................................................................................................................
} //end namespace MatrixOps
