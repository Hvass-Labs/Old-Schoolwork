//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LHeapNode
//
//	Objects of this class are used to build the binary tree used in the heap data-structure,
//	as implemented in LHeap. LHeapNode is straightforward, only tricky part is perhaps the
//	GetRightSibling() function and its use in LHeap. GetRightSibling() returns a pointer
//	to the parent's member-field for the right-child.
//
//	Note how the constructor and destructor are protected, and may therefore only be called
//	by the friend class LHeap.
//
//....................................................................................................................................................................................

#pragma once

#include "LBinaryTreeNode.h"
#include <set>
#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................

// Forward declarations.
// LHeap is required for friend-declaration. LHeapNode for the TNode type-definition.
template <typename TElm, typename TKey, class LEQ> class LHeap;
template <typename TElm, typename TKey, class LEQ> class LHeapNode;

//....................................................................................................................................................................................

template <typename TElm, typename TKey, class LEQ>
class LHeapNode : protected LBinaryTreeNode<LHeapNode>
{
	// Let LHeap access this class.
	friend class LHeap<TElm,TKey,LEQ>;

	// Let LBinaryTreeNode access this class.
	// Required because of protected inheritance.
	friend class LBinaryTreeNode<LHeapNode>;

	// Convenient type-definition.
	typedef LHeapNode<TElm,TKey,LEQ> TNode;

protected:
	LHeapNode								(TElm const& elm, TKey const& key, TNode* parent) : mElm(elm), mKey(key), LBinaryTreeNode<TNode>(parent) {}
	virtual ~LHeapNode						() {}

	// Return the element and key, respectively.
	TElm const&		GetElm					() { return mElm; }
	TKey const&		GetKey					() { return mKey; }

	// Set the contents (i.e. the element and the key) of the node.
	void			Set						(TElm const& elm, TKey const& key) { mElm = elm; mKey = key; }

	// Swap the contents of this node with the node that is given as parameter.
	void			Swap					(TNode* node)
	{
		assert(node);
		std::swap<TElm>(mElm, node->mElm);
		std::swap<TKey>(mKey, node->mKey);
	}

	bool			IsHeapOrdered			()
	{
		LEQ less_equal;
		bool retVal;

		if (mLeftChild)
		{
			if (!less_equal(mKey, mLeftChild->mKey))
			{
				retVal = false;
			}
			else
			{
				retVal = mLeftChild->IsHeapOrdered();

				if (retVal && mRightChild && !less_equal(mKey, mRightChild->mKey))
				{
					retVal = mRightChild->IsHeapOrdered();
				}
			}
		}
		return true;
	}

protected:
	TElm					mElm;			// Node's element.
	TKey					mKey;			// Node's key.
};

//....................................................................................................................................................................................
} //end namespace Yggdrasil
