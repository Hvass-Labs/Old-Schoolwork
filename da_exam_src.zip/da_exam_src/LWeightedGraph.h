//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LWeightedGraph
//
//	???
//
//....................................................................................................................................................................................

#pragma once

#include "LWeightedGraphEdge.h"
#include <list>
#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................

template <typename T>
class LWeightedGraph
{
public:
	typedef LWeightedGraphEdge<T>	TEdge;			// Convenient type-definition.
	typedef std::list<TEdge>		TEdges;			// Convenient type-definition.

public:
	LWeightedGraph							(int n) : kN(n) { assert(n>0); }
	virtual ~LWeightedGraph					() {}

protected:
	const int			kN;				// Number of vertices in the tree/forest.
};

//....................................................................................................................................................................................
} //end namespace Yggdrasil
