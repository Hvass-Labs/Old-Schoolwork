//....................................................................................................................................................................................
//
//	Copyright (C) 2003-2005 by Thurs. All rights reserved.
//
//	LYggRandom
//
//	Magnus EH Pedersen
//
//....................................................................................................................................................................................

#pragma once

#include "YggRound.h"
#include <limits>
#include <cassert>

namespace Yggdrasil
{

	const double kLong2DoubleExcl = 1.0/(1+(double)LONG_MAX);	// The 'plus one' ensures range is U(0,1) and not U(0,1], thus excluding the endpoint 1.

//....................................................................................................................................................................................
class	LYggRandom
{
public:
	LYggRandom							();

	// Re-initialize.
	virtual void			Initialize	(long seed) {}

	// Generates and returns a new pseudo-random value. Assumes value is in range (0, LONG_MAX].
	virtual long			Rand		() = 0;

	// Return a random boolean value, uniformly chosen between 'true' and 'false'.
	inline bool				RandBool	() { return (Rand() > (LONG_MAX/2)); }

	// Range is U(0,1)
	inline double			RandUni		() { double val = Rand() * kLong2DoubleExcl; assert(val>0 && val<1); return val; }

	// Range is (min,max) - and center around the middle between max and min.
	inline double			RandUni		(double min, double max, double centering=1)
	{
		assert(max>=min);

		double halfDifference = (max-min)*0.5;
		double mid = min + halfDifference;

		return centering * RandBi() * halfDifference + mid;
	}

	// Range is U(-1,1)
	inline double			RandBi		() { return 2*RandUni() - 1; }

	// Return uniform random integer from [0, n-1]
	inline int				RandIndex	(int n) { return YggRound(RandUni()*(n-1)); }

	// Return a Gaussian (normal) Deviate random number with the given mean and standard deviation.
	double					Gaussian	(double mean, double stdDeviation) { return DoGaussian()*stdDeviation+mean; }

protected:
	// Return a Gaussian (normal) Deviate, distributed as N(0,1)
	double					DoGaussian	();

private:
	double				mGaussian;			// The pending Gaussian random number.
	bool				mGaussianPending;	// Does mGaussian hold a value.
};
} //end namespace Yggdrasil
