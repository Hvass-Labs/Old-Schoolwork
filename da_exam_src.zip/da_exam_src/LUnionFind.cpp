//__________________________________________________________________________________________
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LUnionFind
//
//__________________________________________________________________________________________

#include "LUnionFind.h"

namespace Yggdrasil
{

//__________________________________________________________________________________________
LUnionFind::LUnionFind			()
{
}
//__________________________________________________________________________________________
LUnionFind::~LUnionFind			()
{
	TNodes::iterator itor;

	for (itor = mNodes.begin(); itor != mNodes.end(); itor++)
	{
		delete *itor;
	}
}
//__________________________________________________________________________________________
LUnionFindSet*
LUnionFind::MakeSet				()
{
	LUnionFindSet* node = new LUnionFindSet();
	mNodes.push_back(node);
	return node;
}
//__________________________________________________________________________________________
LUnionFindSet*
LUnionFind::UnionRoots			(LUnionFindSet* a, LUnionFindSet* b)
{
	return (a->GetNumChildren() < b->GetNumChildren()) ? (DoUnion(a,b)) : (DoUnion(b,a));
}
//__________________________________________________________________________________________
LUnionFindSet*
LUnionFind::DoFind				(LUnionFindSet* a)
{
	assert(a);

	LUnionFindSet* parent = a->GetParent();
	LUnionFindSet* root;

	if (parent)
	{
		// Unhook node 'a' from its parent.
		parent->SubNumChildren(a->GetNumChildren()+1);
		a->SetParent(0); // This is not necessary, but makes it easier to understand.

		// Recursively traverse upwards the tree.
		root = DoFind(parent);

		// Hook node 'a' up to the real root.
		a->SetParent(root);
		root->AddNumChildren(a->GetNumChildren()+1);
	}
	else
	{
		// This means 'a' is the root.
		root = a;
	}

	return root;
}
//__________________________________________________________________________________________
LUnionFindSet*
LUnionFind::DoUnion				(LUnionFindSet* a, LUnionFindSet* b)
{
	// Assert that nodes exist, are different, and are root-nodes.
	assert(a && b && a!=b);
	assert(a->GetParent() == 0 && b->GetParent() == 0);

	a->SetParent(b);
	b->AddNumChildren(a->GetNumChildren() + 1);

	return b;
}
//__________________________________________________________________________________________
} //end namespace Yggdrasil
