//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LUnionFind
//
//	Implementation of the Union-Find data-structure. The data-structure does not contain
//	any data in the usual sense, but is merely used as a fast and convenient way of
//	creating and merging abstract sets, and querying whether two sets are identical.
//
//	Therefore, one must store the handles which are used internally by LUnionFind,
//	and supply the appropriate handles when querying or manipulating the data-structure.
//
//	This class is not strictly necessary, as all of its functionality could have been
//	implemented as normal functions, working on LUnionFindSet-objects. The class does
//	however maintain a list of the nodes that are being used, and automatically deletes
//	those nodes upon destruction of the LUnionFind object.
//
//	This implementation is based on the description given in:
//	'Data Structures and Algorithms in Java' section 12.1.5, by Goodrich and Tamassia
//	ISBN: 0-471-19308-9
//
//....................................................................................................................................................................................

#pragma once

#include "LUnionFindSet.h"
#include <list>
#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................

class LUnionFind
{
public:
	LUnionFind						();
	virtual ~LUnionFind				();

	// Make and return a new set. O(1)
	LUnionFindSet*		MakeSet		();

	// Return the set which contains a. O(a(n)) where a(n) is the inverse of the Ackerman function.
	LUnionFindSet*		Find		(LUnionFindSet* a) { return DoFind(a); }

	// Similar to UnionRoots(), but does not assume nodes a and b are roots. O(a(n))
	LUnionFindSet*		Union		(LUnionFindSet* a, LUnionFindSet* b) { return UnionRoots(Find(a), Find(b)); }

	// Make and return the union of sets a and b. O(1)
	// Nodes a and b are assumed to be roots!
	// No new nodes are created for this, it is implemented strictly by pointer manipulation.
	LUnionFindSet*		UnionRoots	(LUnionFindSet* a, LUnionFindSet* b);

	// Return whether nodes a and b are in the same set.
	bool				SameSet		(LUnionFindSet* a, LUnionFindSet* b) { return Find(a) == Find(b); }

protected:
	// In the traversal to find the root, make the intermediate nodes point to the root.
	LUnionFindSet*		DoFind		(LUnionFindSet* a);

	// Hook node a up to node b. Node b then becomes the new root.
	LUnionFindSet*		DoUnion		(LUnionFindSet* a, LUnionFindSet* b);

protected:
	typedef std::list<LUnionFindSet*>	TNodes;		// Datatype for mNodes.
	TNodes								mNodes;		// List of nodes.
};

//....................................................................................................................................................................................
} //end namespace Yggdrasil
