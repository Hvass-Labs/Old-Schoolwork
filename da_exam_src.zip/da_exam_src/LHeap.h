//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LHeap
//
//	Implements a heap data-structure, which may be used as a priority queue with insertions
//	and removals having O(log(n)) time complexity.
//
//	A heap is essentially a balanced binary tree (i.e. of logarithmic height), satisfying
//	the heap property; which is, that the key at each node, is less than or equal to the
//	keys of its children.
//
//	You may change the ordering of the heap, by changing the template parameter LEQ,
//	for example, we could have double-typed elements, int-typed keys, and order the
//	priority queue descendingly instead of the default ascendingly, by instantiating as:
//
//		LHeap<double, int, std::greater_equal<int> > heap;
//
//	This implementation is based on the description given in:
//	'Data Structures and Algorithms in Java' section 6.3, by Goodrich and Tamassia
//	ISBN: 0-471-19308-9
//
//....................................................................................................................................................................................

#pragma once

#include "LHeapNode.h"
#include <functional>
#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................

template <typename TElm, typename TKey, class LEQ=std::less_equal<TKey> >
class LHeap
{
	// Convenient type-definition.
	typedef LHeapNode<TElm,TKey,LEQ> TNode;

public:
	LHeap							() : mTopNode(0), mLastNode(0) {}
	virtual ~LHeap					() { delete mTopNode; }

	// Insert the given element with the given key. O(log(n))
	void			Insert			(TElm const& elm, TKey const& key);

	// Peek at the top-element. O(1)
	// Assumes the heap is non-empty. Use IsEmpty() to manually check.
	TElm const&		Peek			();

	// Remove the top-element. O(log(n))
	// Assumes the heap is non-empty. Use IsEmpty() to manually check.
	void			Remove			();

	// Return whether the heap is empty. O(1)
	bool			IsEmpty			() { return mTopNode == 0; }

protected:
	// Used for maintaining a balanced binary tree. ???
	void			InsertLast		(TNode* newLastNode);

	// Bubbles mLastNode upwards in heap, until heap-property is satisfied.
	void			UpHeapBubble	(TNode* node);

	// Bubbles mTopNode downwards in heap, until heap-property is satisfied.
	void			DownHeapBubble	(TNode* node);

	// Various assertions whether the binary tree is valid and balanced.
	// Useful for debuggin.
	inline void			AssertValid			();

protected:
	TNode*						mTopNode;		// Top of the heap.
	TNode*						mLastNode;		// Last node in the heap.
};

//....................................................................................................................................................................................
template <typename TElm, typename TKey, class LEQ>
TElm const& LHeap<TElm,TKey,LEQ>::Peek		()
{
	assert(!IsEmpty());

	return mTopNode->GetElm();
}
//....................................................................................................................................................................................
template <typename TElm, typename TKey, class LEQ>
void LHeap<TElm,TKey,LEQ>::Insert			(TElm const& elm, TKey const& key)
{
	TNode* newLastNode = new TNode(elm, key, 0);

	if (IsEmpty())
	{
		mTopNode = mLastNode = newLastNode;
	}
	else
	{
		InsertLast(newLastNode);
		mLastNode = newLastNode;
		UpHeapBubble(mLastNode);
	}

	AssertValid();
}
//....................................................................................................................................................................................
template <typename TElm, typename TKey, class LEQ>
void LHeap<TElm,TKey,LEQ>::Remove		()
{
	assert(!IsEmpty());

	// Note that nodes always have empty right-child if their left-child is empty,
	// because we are ensuring that the binary tree is balanced.
	if (mTopNode->GetLeftChild())
	{
		mTopNode->Set(mLastNode->GetElm(), mLastNode->GetKey());

		// Find the (new) last node.
		TNode* newLastNode = mLastNode->FindLast();

		// Unhook and delete the last node.
		mLastNode->UnhookFromParent();
		delete mLastNode;

		// Assign new last node.
		mLastNode = newLastNode;

		// Restore the heap-order.
		DownHeapBubble(mTopNode);
	}
	else
	{
		delete mTopNode;
		mTopNode = mLastNode = 0;
	}

	AssertValid();
}
//....................................................................................................................................................................................
template <typename TElm, typename TKey, class LEQ>
void LHeap<TElm,TKey,LEQ>::DownHeapBubble	(TNode* node)
{
	assert(node);
	TNode* child = node->GetLeftChild();

	// Make a functional object used for comparison.
	LEQ less_equal;

	while (child)
	{
		TNode* rightChild = node->GetRightChild();

		if (rightChild && less_equal(rightChild->GetKey(), child->GetKey()))
		{
			child = rightChild;
		}

		if (less_equal(child->GetKey(), node->GetKey()))
		{
			// Swap the contents of the two nodes.
			node->Swap(child);

			// Move on to the next node/child pair.
			node = child;
			child = node->GetLeftChild();
		}
		else
		{
			child = 0;
		}
	}
}
//....................................................................................................................................................................................
template <typename TElm, typename TKey, class LEQ>
void LHeap<TElm,TKey,LEQ>::UpHeapBubble	(TNode* node)
{
	assert(node);
	TNode* parent = node->GetParent();

	// Make a functional object used for comparison.
	LEQ less_equal;

	// Bubble element upwards until heap-property is satisfied.
	while (parent && less_equal(node->GetKey(), parent->GetKey()))
	{
		// Swap the elements.
		parent->Swap(node);

		// Move upward in tree.
		node = parent;
		parent = node->GetParent();
	}
}
//....................................................................................................................................................................................
template <typename TElm, typename TKey, class LEQ>
void LHeap<TElm,TKey,LEQ>::InsertLast		(TNode* newLastNode)
{
	assert(mLastNode);
	TNode* w = mLastNode;

	// Go up the tree until root or a left-child is found.
	while (!(w->IsRoot() || (w->IsLeftChild())))
	{
		w = w->GetParent();
	}

	TNode* node;
	TNode** child;

	// Find start-node for down-traversal of the tree.
	if (w->IsRoot())
	{
		node = w;
		child = &(w->mLeftChild);
	}
	else // w is left-child of some parent-node.
	{
		node = w->GetParent();
		child = w->GetRightSiblingPtr();
	}

	// Traverse down the tree until an empty left-child is found.
	while (*child != 0)
	{
		node = *child;
		child = &node->mLeftChild;
	}

	// Insert the new last-node in the empty left-child that was just found.
	*child = newLastNode;

	// Update the new last-node's parent.
	newLastNode->SetParent(node);
}
//....................................................................................................................................................................................
template <typename TElm, typename TKey, class LEQ>
void LHeap<TElm,TKey,LEQ>::AssertValid			()
{
	if (IsEmpty())
	{
		assert(mTopNode == 0 && mLastNode == 0);
	}
	else
	{
		assert(mTopNode->ConsistentParent(0));
		assert(mTopNode->IsBalanced());
		assert(mTopNode->IsHeapOrdered());
	}
}
//....................................................................................................................................................................................
} //end namespace Yggdrasil
