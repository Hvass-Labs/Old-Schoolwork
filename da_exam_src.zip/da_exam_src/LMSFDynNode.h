//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LMinSpanForestDynamic
//
//	???
//
//....................................................................................................................................................................................

#pragma once

#include "LMinSpanForestKruskal.h"
#include "LMinSpanForest.h"
#include "LWeightedGraphEdge.h"
#include <list>
#include <algorithm>
#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................

// Forward declaration needed for subclassing of LBinaryTreeNode.
template <typename T> class LMSFDynNode;

// Forward declarations needed for node's friend-classes.
template <typename T> class LMSFDynNodeInternal;
template <typename T> class LMinSpanForestDynamic;

//....................................................................................................................................................................................

template <typename T>
class LMSFDynNode : public LBinaryTreeNode<LMSFDynNode<T> >
{
	friend class LMinSpanForestDynamic<T>;
	friend class LMSFDynNodeInternal<T>;
	friend class LBinaryTreeNode<LMSFDynNode<T> >;

protected:
	// Convenient type-definitions.
	typedef LMSFDynNode<T>			TNode;
	typedef LWeightedGraphEdge<T>	TEdge;
	typedef std::list<TEdge>		TEdges;

protected:
	LMSFDynNode							(TNode* parent) : LBinaryTreeNode<TNode>(parent) {}
	virtual ~LMSFDynNode				() {}

	// Append edges in node's MSF to the given list of edges.
	virtual void	GetMSF				(TEdges& edges) = 0;

	// Compute the MSF of this node from the MSF's of the node's children.
	virtual void	ComputeMSF			(int const n)
	{
		if (GetParent())
		{
			GetParent()->ComputeMSF(n);
		}
	}
};

//....................................................................................................................................................................................

template <typename T>
class LMSFDynNodeInternal : protected LMSFDynNode<T>
{
	friend class LMSFDynNode<T>;
	friend class LMinSpanForestDynamic<T>;

protected:
	LMSFDynNodeInternal					(TNode* parent) : LMSFDynNode<T>(parent) {}
	virtual ~LMSFDynNodeInternal		() {}

	virtual void	GetMSF				(TEdges& edges)
	{
		edges.insert(edges.begin(), mEdgesMSF.begin(), mEdgesMSF.end());
	}

	// This implements the main function of Eppstein's sparsification.
	virtual void	ComputeMSF			(int const n)
	{
		// Get MSF's for children.
		TNode* leftChild = GetLeftChild();
		TNode* rightChild = GetRightChild();
		TEdges edges;

		// ... add MSF edges from left child (if any).
		if (leftChild)
		{
			leftChild->GetMSF(edges);
		}

		// ... add MSF edges from right child (if any).
		if (rightChild)
		{
			rightChild->GetMSF(edges);
		}

		// Create and execute offline MSF-algorithm (Kruskal).
		LMinSpanForestKruskal<T> msfOffline(n);
		msfOffline.Insert(edges);
		mEdgesMSF.clear();
		msfOffline.MSF(mEdgesMSF);

		// Call overloaded function to recurse up through tree.
		LMSFDynNode<T>::ComputeMSF(n);
	}

	TEdges			mEdgesMSF;
};

//....................................................................................................................................................................................

template <typename T>
class LMSFDynNodeLeaf : protected LMSFDynNode<T>
{
	friend class LMSFDynNode<T>;
	friend class LMinSpanForestDynamic<T>;

protected:
	LMSFDynNodeLeaf						(TEdge const& edge, TNode* parent) : LMSFDynNode<T>(parent), mEdge(edge) {}
	virtual ~LMSFDynNodeLeaf			()
	{
		// Just used for debugging.
	}

	virtual void	GetMSF				(TEdges& edges) { edges.push_back(mEdge); }

public:
	// Return whether the given leaf's edge is the same as this' edge.
	virtual bool		operator==		(LMSFDynNodeLeaf<T> const& leaf) { return mEdge == leaf.mEdge; }

protected:
	TEdge			mEdge;
};
//....................................................................................................................................................................................
} //end namespace Yggdrasil
