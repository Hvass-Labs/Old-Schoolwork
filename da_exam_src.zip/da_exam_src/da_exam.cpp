// da_exam.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "LMinSpanForestKruskal.h"
#include "LMinSpanForestDynamic.h"
#include "LWeightedGraphEdge.h"
#include "LYggRandom2.h"
#include <functional>
#include <list>
#include <ctime>

using namespace Yggdrasil;

LYggRandom2 gRandom(872357);

void TestCorrectness()
{
	typedef LWeightedGraphEdge<int> TEdge;
	const int kNumVertices = 8;
	const int kNumEdges = 7;

#if 1
	LMinSpanForestDynamic<int> msf(kNumVertices);
	LMSFDynNodeLeaf<int>* leafs[kNumEdges];

	leafs[0] = msf.Insert(TEdge(0,1,2));
	leafs[1] = msf.Insert(TEdge(0,4,4));
	leafs[2] = msf.Insert(TEdge(0,7,8));
	leafs[3] = msf.Insert(TEdge(1,4,3));
	leafs[4] = msf.Insert(TEdge(1,7,6));
	leafs[5] = msf.Insert(TEdge(3,5,1));
	leafs[6] = msf.Insert(TEdge(4,7,7));

/*	msf.Delete(leafs[0]);
	msf.Delete(leafs[1]);
	msf.Delete(leafs[2]);
	msf.Delete(leafs[3]);
	msf.Delete(leafs[4]);
	msf.Delete(leafs[5]);
*/
#else
	LMinSpanForestKruskal<int> msf(kNumVertices);

	msf.Insert(TEdge(0,1,2));
	msf.Insert(TEdge(0,4,4));
	msf.Insert(TEdge(0,7,8));
	msf.Insert(TEdge(1,4,3));
	msf.Insert(TEdge(1,7,6));
	msf.Insert(TEdge(3,5,1));
	msf.Insert(TEdge(4,7,7));
#endif

	typedef std::list<LWeightedGraphEdge<int> > TList;
	TList msfEdges;
	msf.MSF(msfEdges);

	TList::iterator itor;
	for (itor=msfEdges.begin(); itor!=msfEdges.end(); itor++)
	{
		LWeightedGraphEdge<int> const& edge = *itor;
		std::cout << "(" << edge.GetI() << "," << edge.GetJ() << ")\n";
	}
}

typedef LWeightedGraphEdge<double>		TEdge;
typedef std::list<TEdge>				TEdges;

void TestPerformanceKruskal(int n, TEdges const& edges)
{
	LMinSpanForestKruskal<double> msf(n);

	msf.Insert(edges);

	TEdges msfEdges;
	msf.MSF(msfEdges);
}

void TestPerformanceDynamic(int n, TEdges const& edges)
{
	LMinSpanForestDynamic<double> msf(n);

	TEdges::const_iterator itor;
	for (itor = edges.begin(); itor != edges.end(); itor++)
	{
		TEdge const& edge = *itor;
		msf.Insert(edge);
	}

	TEdges msfEdges;
	msf.MSF(msfEdges);
}

void TestPerformance(int minN, int maxN, int numSteps, bool testingKruskal)
{
	if (testingKruskal)
	{
		std::cout << "Kruskal\nm\tmsecs\n";
	}
	else
	{
		std::cout << "Dynamic MSF (sparsification)\nm*n\tmsecs\n";
	}

	int stepSize = (maxN-minN)/numSteps;

	for (int k=0; k<numSteps; k++)
	{
		int n = (k+1)*stepSize;

		TEdges edges;
		int maxNumEdges = n*(n+1)/2 - n;
		double probability = n*1.5/maxNumEdges;

		for (int i=0; i<n; i++)
		{
			for (int j=0; j<i; j++)
			{
				if (gRandom.RandUni() < probability)
				{
					double weight = gRandom.RandUni();
					edges.push_back(TEdge(i, j, weight));
				}
			}
		}

		std::clock_t beginTime, endTime;
		beginTime = std::clock();
		if (testingKruskal)
		{
			TestPerformanceKruskal(n, edges);
		}
		else
		{
			TestPerformanceDynamic(n, edges);
		}
		endTime = std::clock();

		if (testingKruskal)
		{
			std::cout << edges.size();
		}
		else
		{
			std::cout << n*edges.size();
		}

		std::cout << "\t" << endTime-beginTime << std::endl;
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	long seed;
	std::cout << "Random seed: ";
	std::cin >> seed;
	gRandom.Initialize(seed);

	int input;
	std::cout << "Test performance for Kruskal or dynamic MSF? (0 for Kruskal, 1 for dynamic): ";
	std::cin >> input;

	if (input != 0)
	{
		TestPerformance(10, 1000, 30, false);
	}
	else
	{
		TestPerformance(10, 40000, 30, true);
	}

//	TestCorrectness();

	return 0;
}

