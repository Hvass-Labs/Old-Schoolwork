//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LUnionFindSet
//
//	An object of this class, represents an abstract set in the Union-Find data-structure,
//	as implemented in LUnionFind. The class provides various basic operations, that are
//	needed to maintain the nodes of the internal trees of the Union-Find data-structure.
//
//	Note how the constructor and destructor are protected, and may therefore only be called
//	by the friend class LUnionFind.
//
//....................................................................................................................................................................................

#pragma once

#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................

class LUnionFindSet
{
	friend class LUnionFind;

protected:
	LUnionFindSet							() : mParent(0), mNumChildren(0) {}
	virtual ~LUnionFindSet					() {}

	// Return the node's parent.
	LUnionFindSet*		GetParent			() { return mParent; }

	// Set the node's parent.
	void				SetParent			(LUnionFindSet* parent) { mParent = parent; }

	// Return the number of children the node has.
	int					GetNumChildren		() { assert(mNumChildren>=0); return mNumChildren; }

	// Add the given number of children, to this node's count of children.
	void				AddNumChildren		(int numChildren) { assert(numChildren>=0); mNumChildren += numChildren; }

	// Subtract the given number of children, from this node's count of children.
	void				SubNumChildren		(int numChildren) { assert(numChildren>=0); mNumChildren -= numChildren; }

private:
	LUnionFindSet*		mParent;			// The node's parent-node.
	int					mNumChildren;		// The number of children this node has.
};

//....................................................................................................................................................................................
} //end namespace Yggdrasil
