//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LWeightedGraphEdge
//
//	Internal representation of an edge in a weighted graph. Edge stores the vertices
//	that are connected and the weight of the edge. Class furthermore provides comparison
//	operator, which is used by various find()-based operations.
//
//....................................................................................................................................................................................

#pragma once

#include <set>
#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................

template <typename T>
class LWeightedGraphEdge
{
public:
	LWeightedGraphEdge					(int i, int j) : mI(i), mJ(j) { OrderVertices(); }
	LWeightedGraphEdge					(int i, int j, T weight) : mI(i), mJ(j), mWeight(weight) { OrderVertices(); }

	int					GetI			() const { return mI; }
	int					GetJ			() const { return mJ; }
	int					GetWeight		() const { return mWeight; }

	// Return whether connected vertices for the two edges are the same.
	virtual bool		operator==		(LWeightedGraphEdge<T> const& a)
	{
		return mI == a.mI && mJ == a.mJ;
	}

	// Overloaded assignment operator.
	virtual LWeightedGraphEdge<T>&		operator=		(LWeightedGraphEdge<T> const& a)
	{
		mI = a.mI;
		mJ = a.mJ;
		mWeight = a.mWeight;

		return *this;
	}

protected:
	// Ensure that i<=j.
	void				OrderVertices		()
	{
		if (mI>mJ)
		{
			std::swap<int>(mI,mJ);
		}
	}

protected:
	int				mI, mJ;		// Vertices which the edge connects. mI <= mJ
	T				mWeight;	// The weight on the edge.
};

//....................................................................................................................................................................................
} //end namespace Yggdrasil
