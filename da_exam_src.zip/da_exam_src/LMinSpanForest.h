//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LMinSpanForest
//
//	???
//
//....................................................................................................................................................................................

#pragma once

#include "LWeightedGraph.h"
#include <list>
#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................

template <typename T>
class LMinSpanForest : public LWeightedGraph<T>
{
public:
	LMinSpanForest							(int n) : LWeightedGraph<T>(n) { }
	virtual ~LMinSpanForest					() {}

	// Return in the given list, the edges for the Minimum Spanning Forest.
	virtual	void		MSF					(TEdges& edgeList) = 0;
};

//....................................................................................................................................................................................
} //end namespace Yggdrasil
