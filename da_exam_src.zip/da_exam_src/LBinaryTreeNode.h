//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LBinaryTreeNode
//
//	???
//
//....................................................................................................................................................................................

#pragma once

#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................

template <class TNode>
class LBinaryTreeNode
{
	friend class TNode;

public:
	LBinaryTreeNode							(TNode* parent) : mParent(parent), mLeftChild(0), mRightChild(0) {}
	virtual ~LBinaryTreeNode				()
	{
		delete mLeftChild;
		delete mRightChild;
	}

	// Return the node's parent-node, left-, and right-children, respectively.
	TNode*			GetParent				() { return mParent; }
	TNode*			GetLeftChild			() { return mLeftChild; }
	TNode*			GetRightChild			() { return mRightChild; }

	// Set the node's parent-node, left-, and right-children, respectively.
	void			SetParent				(TNode* node) { mParent = node; }
	void			SetLeftChild			(TNode* node) { mLeftChild = node; }
	void			SetRightChild			(TNode* node) { mRightChild = node; }

	// Return whether the given node is the root.
	bool			IsRoot					() { return GetParent() == 0; }

	// Return whether the node is the left-child of its parent.
	// Assumes the node has a parent.
	bool			IsLeftChild				()
	{
		assert(mParent);

		return mParent->GetLeftChild() == this;
	}

	// Return whether the node is the right-child of its parent.
	// Assumes the node has a parent.
	bool			IsRightChild			()
	{
		assert(mParent);

		return mParent->GetRightChild() == this;
	}

	// Return the left sibling of the node.
	// Assumes the node has a parent.
	TNode*			GetLeftSibling			()
	{
		assert(mParent);

		return mParent->mLeftChild;
	}

	// Return the right sibling of the node.
	TNode*			GetRightSibling			()
	{
		assert(mParent);

		return mParent->mRightChild;
	}

	// Return pointer to the right sibling of the node.
	// Assumes the node has a parent.
	TNode**			GetRightSiblingPtr		()
	{
		assert(mParent);

		return &(mParent->mRightChild);
	}

	// If the node has curChild as one of its children, then it is replaced with newChild.
	// Debug-version assumes curChild is actually a child of this node.
	void			ReplaceChild			(TNode* curChild, TNode* newChild)
	{
		assert(mLeftChild == curChild || mRightChild == curChild);

		if (mLeftChild == curChild)
		{
			mLeftChild = newChild;
		}
		else if (mRightChild == curChild)
		{
			mRightChild = newChild;
		}
	}

	// Unhook this node from parent-node, provided it has a parent.
	void			UnhookFromParent		()
	{
		if (mParent)
		{
			if (IsLeftChild())
			{
				mParent->SetLeftChild(0);
			}
			else
			{
				mParent->SetRightChild(0);
			}

			SetParent(0);
		}
	}

	// Used for maintaining a balanced binary tree. Finds the node that will be the
	// bottom- and right-most node in the binary tree, after removal of the current
	// node (which is assumed to be the currently last node in the tree).
	TNode*			FindLast		();

	// Recursively return whether the parent is consistent.
	// Used for debugging.
	bool			ConsistentParent		(LBinaryTreeNode<TNode>* parent)
	{
		return (mParent == parent) && DoConsistentParent(mLeftChild) && DoConsistentParent(mRightChild);
	}

	// Auxiliary function for ConsistentParent().
	bool			DoConsistentParent		(LBinaryTreeNode<TNode>* child)
	{
		return (child) ? (child->ConsistentParent(this)) : (true);
	}

	bool			IsBalanced				() const
	{
		bool doingLeftPart = true;
		int leftDepth = LeftDepth();
		return DoIsBalanced(doingLeftPart, leftDepth);
	}

protected:
	// Recursively find the depth of the left path down to a leaf.
	int				LeftDepth				() const
	{
		return (mLeftChild == 0) ? (1) : (1+mLeftChild->LeftDepth());
	}

	bool			DoIsBalanced			(bool& doingLeftPart, int const maxDepth, int curDepth=1) const
	{
		bool retVal;

		if (mLeftChild)
		{
			// Internal node, do a left-to-right depth-first traversal of tree.

			// First traverse left-child.
			retVal = mLeftChild->DoIsBalanced(doingLeftPart, maxDepth, curDepth+1);

			// Then traverse right-child.
			if (retVal && mRightChild)
			{
				retVal = mRightChild->DoIsBalanced(doingLeftPart, maxDepth, curDepth+1);
			}
		}
		else // This must be a leaf-node.
		{
			// If node has right-child but no left-child, then not balanced.
			if (mRightChild)
			{
				// Not balanced.
				retVal = false;
			}
			else // OK, this is a leaft.
			{
				// See if balanced.
				if (curDepth == maxDepth && doingLeftPart)
				{
					// OK.
					retVal = true;
				}
				else if (curDepth == maxDepth-1)
				{
					// Also OK.
					retVal = true;

					// Now we must be doing right part of tree.
					doingLeftPart = false;
				}
				else
				{
					retVal = false;
				}
			}
		}

		return retVal;
	}

protected:
	TNode*					mParent;		// Node's parent-node.
	TNode*					mLeftChild;		// Node's left-child-node.
	TNode*					mRightChild;	// Node's right-child-node.
};

//....................................................................................................................................................................................
template <class TNode>
TNode* LBinaryTreeNode<TNode>::FindLast		()
{
	TNode* w = static_cast<TNode*>(this);

	// Go up the tree until root or a right-child is found.
	while (!(w->IsRoot() || (w->IsRightChild())))
	{
		w = w->GetParent();
	}

	TNode* node;

	// Find start-node for down-traversal of the tree.
	if (w->IsRoot())
	{
		node = w;
	}
	else // w is right-child of some parent-node.
	{
		node = w->GetLeftSibling();
	}

	// Traverse down the tree until the last right-child is found.
	while (node->GetRightChild() != 0)
	{
		node = node->GetRightChild();
	}

	return node;
}
//....................................................................................................................................................................................
} //end namespace Yggdrasil
