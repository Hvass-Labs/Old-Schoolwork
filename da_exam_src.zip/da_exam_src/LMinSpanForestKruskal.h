//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LMinSpanForestKruskal
//
//	Implementation of the Kruskal algorithm for finding the 'Minimum Spanning Forest'.
//	The Kruskal algorithm is 'offline', meaning that it calculates the MSF from scratch.
//	The functions are annotated with their time complexities, where n is the number of
//	vertices in the graph, and m is the number of edges. Since we do not allow multiple
//	edges between two vertices, we have that m <= n*(n+1)/2 = O(n^2).
//
//	Although not a strict requirement by the Kruskal algorithm, this implementation only
//	allows one edge between any two vertices, that is, duplicate edges are not allowed,
//	regardless of any difference in weights.
//
//	This implementation is based on the description given in:
//	'Data Structures and Algorithms in Java' section 10.2.1, by Goodrich and Tamassia
//	ISBN: 0-471-19308-9
//
//....................................................................................................................................................................................

#pragma once

#include "LMinSpanForest.h"
#include "LWeightedGraphEdge.h"
#include "LUnionFind.h"
#include "LHeap.h"
#include <list>
#include <algorithm>
#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................

template <typename T>
class LMinSpanForestKruskal : public LMinSpanForest<T>
{
public:
	LMinSpanForestKruskal					(int n);

	virtual ~LMinSpanForestKruskal			();

	// Return whether the edge (i,j) exists. Ignores weight. O(m)
	bool				HasEdge				(TEdge const& edge);

	// Insert the edge (i,j) with weight w. O(1)
	// Assumes the edge is not already in the graph.
	// In debug-mode, the assertive call to HasEdge() has time-complexity O(m).
	void				Insert				(TEdge const& edge);

	// Insert the list of edges. O(k) where k is the length of the edgelist.
	// Does not check whether edges are already in the graph!
	void				Insert				(TEdges const& edges);

	// Delete the edge (i,j). O(m)
	// Does not require for the edge to be in the graph.
	void				Delete				(TEdge const& edge);

	// Return in the given list, the edges for the Minimum Spanning Forest. O(m*(log(m)+a(n)))
	// Assuming n-1 <= m <= n*(n+1)/2, we have time-complexity O(m*log(n)).
	// Time-complexity assumes that the supplied edgeList is empty already.
	virtual	void		MSF					(TEdges& edges);

protected:
	TEdges							mEdges;			// Edges in the graph.
	LUnionFindSet**					mVerticeSets;	// Sets or clusters of vertices.
};

//....................................................................................................................................................................................
template <typename T>
LMinSpanForestKruskal<T>::LMinSpanForestKruskal		(int n) :
LMinSpanForest<T>(n)
{
	mVerticeSets = new LUnionFindSet*[n];
}
//....................................................................................................................................................................................
template <typename T>
LMinSpanForestKruskal<T>::~LMinSpanForestKruskal	()
{
	delete [] mVerticeSets;
}
//....................................................................................................................................................................................
template <typename T>
bool LMinSpanForestKruskal<T>::HasEdge				(TEdge const& edge)
{
	TEdges::iterator itor = std::find(mEdges.begin(), mEdges.end(), edge);
	return itor != mEdges.end();
}
//....................................................................................................................................................................................
template <typename T>
void LMinSpanForestKruskal<T>::Insert				(TEdge const& edge)
{
	assert(!HasEdge(edge));
	mEdges.push_back(edge);
}
//....................................................................................................................................................................................
template <typename T>
void LMinSpanForestKruskal<T>::Insert				(TEdges const& edges)
{
	mEdges.insert(mEdges.begin(), edges.begin(), edges.end());
}
//....................................................................................................................................................................................
template <typename T>
void LMinSpanForestKruskal<T>::Delete				(TEdge const& edge)
{
	mEdges.remove(edge);
}
//....................................................................................................................................................................................
template <typename T>
void LMinSpanForestKruskal<T>::MSF					(TEdges& edges)
{
	// Ensure that the supplied list is empty.
	edges.clear();

	// Create the Union-Find data-structure. O(1)
	LUnionFind unionFind;

	// ... and create a Union-Find set for each vertice in the graph. O(n)
	for (int i=0; i<kN; i++)
	{
		mVerticeSets[i] = unionFind.MakeSet();
	}

	// Create the heap that is to contain the edges. O(1)
	LHeap<TEdge, T> heap;

	// ... and fill the heap with the edges. O(m*log(m))
	TEdges::iterator itor;
	for (itor=mEdges.begin(); itor != mEdges.end(); itor++)
	{
		TEdge& edge = *itor;
		heap.Insert(edge, edge.GetWeight());
	}

	// Empty the heap of edges, thus finding the MSF. O(m*(log(m)+a(n)))
	while (!heap.IsEmpty())
	{
		// Remove from the heap, the edge with the lowest weight. O(log(m))
		TEdge edge = heap.Peek();
		heap.Remove();

		// The sets associated with the vertices connected by the edge. O(1)
		LUnionFindSet* iSet = mVerticeSets[edge.GetI()];
		LUnionFindSet* jSet = mVerticeSets[edge.GetJ()];

		// If the vertices are in different sets, then edge is in MSF. O(a(n))
		if (!unionFind.SameSet(iSet, jSet))
		{
			// Add edge to MSF. O(1)
			edges.push_back(edge);

			// Union or merge the sets for the two vertices. O(a(n))
			unionFind.Union(iSet, jSet);
		}
	}
}
//....................................................................................................................................................................................
} //end namespace Yggdrasil
