//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LMinSpanForestDynamic
//
//	???
//
//....................................................................................................................................................................................

#pragma once

#include "LMSFDynNode.h"
#include "LMinSpanForestKruskal.h"
#include "LMinSpanForest.h"
#include <list>
#include <algorithm>
#include <cassert>

namespace Yggdrasil
{

//....................................................................................................................................................................................

template <typename T>
class LMinSpanForestDynamic : public LMinSpanForest<T>
{
public:
	LMinSpanForestDynamic					(int n);

	virtual ~LMinSpanForestDynamic			();

	// Return whether the graph contains any edges. O(1)
	bool				IsEmpty				() { return mTopNode == 0; }

	// Insert the edge (i,j) with weight w. O(n*log(n))
	LMSFDynNodeLeaf<T>*	Insert				(TEdge const& edge);

	// Delete the edge (i,j). O(n*log(n))
	void				Delete				(LMSFDynNodeLeaf<T>* leaf);

	// Return the Min. Span. Forest. O(n)
	virtual	void		MSF					(TEdges& edges)
	{
		assert(mTopNode);

		edges.clear();
		mTopNode->GetMSF(edges);
	}

protected:
	// Convenient type-definitions.
	typedef LMSFDynNode<T>			TNode;
	typedef LMSFDynNodeInternal<T>	TNodeInternal;
	typedef LMSFDynNodeLeaf<T>		TLeaf;
	typedef std::list<TLeaf>		TLeafs;

	// Unhook last-node (but don't delete it), and update mLastNode.
	void				UnhookLast			();

	// ???
	void				InsertLast			(TLeaf* newLeaf);

	// Various assertions whether the binary tree is valid and balanced.
	// Useful for debuggin.
	inline void			AssertValid			();

protected:
	TNode*					mTopNode;
	TNode*					mLastNode;
};

//....................................................................................................................................................................................
template <typename T>
LMinSpanForestDynamic<T>::LMinSpanForestDynamic		(int n) :
LMinSpanForest<T>(n),
mTopNode(0),
mLastNode(0)
{
}
//....................................................................................................................................................................................
template <typename T>
LMinSpanForestDynamic<T>::~LMinSpanForestDynamic	()
{
}
//....................................................................................................................................................................................
template <typename T>
void LMinSpanForestDynamic<T>::AssertValid			()
{
	if (IsEmpty())
	{
		assert(mTopNode == 0 && mLastNode == 0);
	}
	else
	{
		assert(mTopNode->ConsistentParent(0));
		assert(mTopNode->IsBalanced());
	}
}
//....................................................................................................................................................................................
template <typename T>
LMSFDynNodeLeaf<T>* LMinSpanForestDynamic<T>::Insert	(TEdge const& edge)
{
	TLeaf* leaf = new TLeaf(edge, 0);

	// Insert in binary tree.
	if (IsEmpty())
	{
		// Make leaf the only node in the tree.
		// No MSF-recomputation is necessary.
		mTopNode = leaf;
	}
	else // !IsEmpty()
	{
		// Insert the leaf as the bottom- and right-most leaf.
		// MSF-recomputation is done.
		InsertLast(leaf);
	}

	// Update pointer to the bottom- and right-most leaf.
	mLastNode = leaf;

	// Ensure tree is valid after leaf-insertion.
	AssertValid();

	return leaf;
}
//....................................................................................................................................................................................
template <typename T>
void LMinSpanForestDynamic<T>::InsertLast		(TLeaf* newLeaf)
{
	assert(mLastNode);
	TNode* w = mLastNode;

	// Go up the tree until root or a left-child is found.
	while (!(w->IsRoot() || w->IsLeftChild()))
	{
		w = w->GetParent();
	}

	TNode* node;

	// Find start-node for down-traversal of the tree.
	if (w->IsRoot())
	{
		node = w;
	}
	else // w is left-child of some parent-node.
	{
		node = w->GetRightSibling();
	}

	// Traverse down the tree until a leaf is found.
	while (node->GetLeftChild() != 0)
	{
		node = node->GetLeftChild();
	}

	// Find parent (if any), and create new inner node in place of existing leaf.
	TNode* parent = node->GetParent();
	TNodeInternal* innerNode = new TNodeInternal(parent);

	// Hook previous leaf up as new inner-node's left child.
	node->SetParent(innerNode);
	innerNode->SetLeftChild(node);

	// Hook new leaf up as new inner-node's right child.
	newLeaf->SetParent(innerNode);
	innerNode->SetRightChild(newLeaf);

	if (parent)
	{
		parent->ReplaceChild(node, innerNode);
	}
	else
	{
		mTopNode = innerNode;
	}

	// Re-compute MSFs on the way to the binary tree's root.
	innerNode->ComputeMSF(kN);
}
//....................................................................................................................................................................................
template <typename T>
void LMinSpanForestDynamic<T>::Delete				(LMSFDynNodeLeaf<T>* leaf)
{
	assert(leaf);

	if (leaf->IsRoot())
	{
		// Only a single node exists in the tree, it will be deleted below.
		mTopNode = mLastNode = 0;
	}
	else // More than one node exists in the tree.
	{
		// Unhook and update mLastNode, but don't delete current one.
		TNode* oldLastNode = mLastNode;
		UnhookLast();

		// Only replace leaf with oldLastNode, if
		// leaf was not the previous last-node.
		if (oldLastNode != leaf)
		{
			// Get the leaf's parent (if any).
			TNode* parent = leaf->GetParent();

			// Hookup oldLastNode to leaf's parent (may be zero).
			oldLastNode->SetParent(parent);

			// Hookup oldLastNode instead of leaf.
			if (parent)
			{
				// Replace leaf in parent with oldLastNode.
				parent->ReplaceChild(leaf, oldLastNode);

				// Re-compute MSFs on the way to the binary tree's root.
				parent->ComputeMSF(kN);

				// Correct new last-node if it was the leaf which
				// we are deleting.
				if (mLastNode == leaf)
				{
					mLastNode = oldLastNode;
				}
			}
			else // no parent
			{
				// Leaf is the only remaining node in the tree,
				// so replace it with oldLastNode.
				mTopNode = mLastNode = oldLastNode;
			}
		}
	}

	// Delete the leaf.
	delete leaf;

	// Ensure tree is valid after leaf-deletion.
	AssertValid();
}
//....................................................................................................................................................................................
template <typename T>
void LMinSpanForestDynamic<T>::UnhookLast			()
{
	assert(!IsEmpty());
	assert(!mLastNode->IsRoot() && mLastNode->IsRightChild());

	TNode* parent = mLastNode->GetParent();
	TNode* leftSibling = mLastNode->GetLeftSibling();
	TNode* parentParent = parent->GetParent();

	// Unhook the last-node and its sibling from their mutual parent.
	mLastNode->UnhookFromParent();
	leftSibling->UnhookFromParent();

	if (parentParent)
	{
		parentParent->ReplaceChild(parent, leftSibling);
	}

	// Hook up the remaining leaf to the parent's parent (which may be zero).
	leftSibling->SetParent(parentParent);

	// Delete the inner-node which is no longer used.
	delete parent;

	// Find out which nodes are now the top- and last-nodes of the binary tree.
	if (leftSibling->IsRoot())
	{
		// leftSibling is the only node left in tree; make it top- and last-node.
		// Since it is the only node left in tree, it is therefore also a leaf.
		mTopNode = mLastNode = leftSibling;
		mLastNode = leftSibling;
	}
	else
	{
		// Traverse tree to find new last-node.
		TNode* newLastNode = leftSibling->FindLast();
		mLastNode = newLastNode;

		// Re-compute MSFs from the last-node just removed to root of tree.
		leftSibling->ComputeMSF(kN);
	}

	// Ensure tree is valid after mLastNode unhooking.
	AssertValid();
}
//....................................................................................................................................................................................
} //end namespace Yggdrasil
