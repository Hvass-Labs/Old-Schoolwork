//....................................................................................................................................................................................
//
//	Copyright (C) 2005 by Thurs, Magnus EH Pedersen.
//	All rights reserved. Non-commercial use allowed.
//
//	LPoisson
//
//	Implements various algorithms (or 'iteration-kinds') for numerically solving
//	the 2-dimensional Poisson problem. All variants are based on the socalled
//	'Gauss-Seidel' formula (see the CalcU()-function).
//
//	The complete 2D-grid contains N*N inner-points, and has a boundary all the
//	way around. One instance of the LPoisson-class, may store only a sub-grid (also
//	having a boundary), thus supporting the distribution of computation. The sub-grid
//	has kSizeM*kSizeN inner grid-points (kSizeM rows, kSizeN columns, both excluding
//	boundary), and are offset by kOffsetM and kOffsetN, both ranging from 0 to N-1.
//
//	Rows are indexed by 'i' which goes from 0 to kSizeM+1 (incl. boundaries), and
//	index 'i' maps to coordinate 'y', which has range [-1,1]. This mapping is done
//	linearly such that: i+kOffsetM==0 => y==-1, and i+kOffsetM==N+1 => y=1.
//
//	Likewise, columns are indexed by 'j', going from 0 to kSizeN+1 (incl. boundaries),
//	and mapping to coordinate 'x' with range [-1,1], same as above (only with kOffsetN
//	instead).
//
//	Implementation makes use of nested OpenMP parallel-regions, see e.g. OpenMP
//	Specification version 2.5, section 2.4.1
//
//....................................................................................................................................................................................

#pragma once

#include <ostream>

namespace Poisson
{

//....................................................................................................................................................................................
class	LPoisson
{
	friend class LPoissonMPI;

public:
	LPoisson							(int N,						// Complete grid is N*N
										 int sizeM, int offsetM,	// Sub-grid size and offset (rows).
										 int sizeN, int offsetN);	// Sub-grid size and offset (columns).

	virtual ~LPoisson					();

	// Non block-decomposed iterations.
	void			Iterate				();
	void			IterateRedBlack		();

	// Block-decomposed iterations.
	void			Iterate				(int blockWidth);
	void			IterateRedBlack		(int blockWidth, int blockHeight);

	// Outputs grid-values in a format readable by GnuPlot and the splot command.
	virtual void	OutputGnuPlot		(std::ostream& out) const;

protected:
	// Initialization of boundaries and (initial) solution.
	void			InitBoundaries		();
	void			InitSolution		();

	// The 'source-term' for the Poisson problem. The function 'f'.
	inline double	f					(double x, double y) const;

	// Gauss-Seidel iteration for all points u(i,j), with j going from J1 up to J2 (incl.).
	inline void		DoIterate			(const int J1, const int J2);

	// Perform iteration of row i (with coordinate y), from index J1 up to and including J2.
	// The stride is the step-size between j-indices. Stride=1 for the normal algorithm, and stride=2 for Red-Black.
	inline void		DoIterateRow		(const int i, const double y, const int J1, const int J2, const int stride=1);

	// Red-Black iteration of the block of grid-points where I1 <= i <= I2 and J1 <= j <=J2.
	inline void		DoIterateRedBlack	(const int I1, const int I2, const int J1, const int J2);

	// Compute and return the new value for the grid-point at position (row,col) = (i,j).
	inline double	CalcU				(double x, double y, int i, int j) const;

	// Simply return the value of the grid-point at position (row,col) = (i,j).
	inline double	GetU				(int i, int j) const;

	// Simply Set the value of the grid-point at position (row,col) = (i,j).
	inline void		SetU				(int i, int j, double u);

	// Map index i to y-coordinate with range [-1,1].
	inline double	MapIndexI2Y			(int i) const;

	// Map index j to x-coordinate with range [-1,1].
	inline double	MapIndexJ2X			(int j) const;

protected:
	const double		kDelta2;			// Grid-spacing (squared).
	const double		kMappingFactor;		// Used by MapIndex().
	const int			kN;					// Grid is kN*kN (plus bounds).

	const int			kSizeM;				// Number of rows in sub-grid.
	const int			kOffsetM;			// Index-offset for sub-grid (i).

	const int			kSizeN;				// Number of columns in sub-grid.
	const int			kOffsetN;			// Index-offset for sub-grid (j).

	double**			mU;					// Grid storing u-values.
};
//....................................................................................................................................................................................
} //end namespace Poisson
