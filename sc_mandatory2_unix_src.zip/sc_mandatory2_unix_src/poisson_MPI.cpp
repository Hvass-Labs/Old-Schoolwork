// poisson_MPI.cpp : Defines the entry point for the application.
//

#include "LPoissonMPI.h"
#include "mpi.h"
#include <fstream>
#include <string>
#include <iostream>

// Wall-clock routines for non-OpenMP and OpenMP.
#ifdef _OPENMP

#include <omp.h>
typedef double TTime;

TTime GetClock()
{
	return omp_get_wtime();
}

double TimeDiff_Seconds(TTime beginTime, TTime endTime)
{
	return endTime-beginTime;
}

#else // Not OpenMP.

#include <ctime>
typedef std::clock_t TTime;

TTime GetClock()
{
	return std::clock();
}

double TimeDiff_Seconds(TTime beginTime, TTime endTime)
{
	return (double)(endTime-beginTime)/1000;
}
#endif

// Parameters.
int				gN = 0;						// Grid-size.
int				gNumIterations = 0;			// Number of iterations.
bool			gMustOutput = false;		// Output result to a file?
std::string		gOutputFilename;			// Filename for that output.

// MPI variables.
int				gRank;						// Rank of node.
int				gP;							// Number of nodes.

// Return whether or not to display status to std::cout.
bool Display()
{
	return gRank == 0;
}

bool GetParameters(int argc, char* argv[])
{
	bool hasN = false;
	bool hasNumIterations = false;

	for (int i=1; i<argc; i++)
	{
		std::string arg(argv[i]);

		if (i<argc-1 && (arg == "-n" || arg == "-N"))
		{
			// Grid-size.
			gN = atoi(argv[i+1]);
			i++;
			hasN = true;

			if (Display())
			{
				std::cout << "Grid-size (excl. boundaries): " << gN << std::endl;
			}
		}
		else if (i<argc-1 && (arg == "-k" || arg == "-K"))
		{
			// Number of iterations to perform.
			gNumIterations = atoi(argv[i+1]);
			i++;
			hasNumIterations = true;

			if (Display())
			{
				std::cout << "Number of iterations: " << gNumIterations << std::endl;
			}
		}
		else if (i<argc-1 && (arg == "-o" || arg == "-O"))
		{
			// Output-file.
			gMustOutput = true;
			gOutputFilename = argv[i+1];
			i++;

			if (Display())
			{
				std::cout << "Output to file with name: " << gOutputFilename << std::endl;
			}
		}
	}

	bool retVal;

	if (hasN && hasNumIterations)
	{
		// Arguments appear OK.

		retVal = true;
	}
	else
	{
		// Arguments are erroneous, print help-message.

		if (Display())
		{
			std::cout << "poisson_MPI -n <int> -k <int> [-o <outfile>]\n";
			std::cout << "-n is the grid-size.\n";
			std::cout << "-k is the number of iterations.\n";
			std::cout << "-o is the optional output filename.\n";
			std::cout << std::endl;
		}

		retVal = false;
	}

	return retVal;
}

using namespace Poisson;

int main(int argc, char* argv[])
{
	MPI_Init(&argc, &argv);

	MPI_Comm_rank(MPI_COMM_WORLD, &gRank);
	MPI_Comm_size(MPI_COMM_WORLD, &gP);

	bool parametersOK = GetParameters(argc, argv);

	if (parametersOK)
	{
		LPoissonMPI poisson(gN, gP, gRank);

		if (Display())
		{
			// Display time-usage for the first node only.

			TTime beginTime, endTime;
			std::cout << "Number of nodes: " << gP << std::endl;
			std::cout << "Processing .. ";

			beginTime = GetClock();

			for (int i=0; i<gNumIterations; i++)
			{
				poisson.Iterate();
			}

			endTime = GetClock();

			std::cout << "done in " << TimeDiff_Seconds(beginTime, endTime) << " secs." << std::endl;
		}
		else
		{
			// For all other nodes than the first, only process.

			for (int i=0; i<gNumIterations; i++)
			{
				poisson.Iterate();
			}
		}

		// All nodes must output their data.
		if (gMustOutput)
		{
			std::ofstream fout(gOutputFilename.c_str(), std::ios_base::app);
			poisson.OutputGnuPlot(fout);
			fout.close();
		}
	}

	MPI_Finalize();

	return 0;
}
