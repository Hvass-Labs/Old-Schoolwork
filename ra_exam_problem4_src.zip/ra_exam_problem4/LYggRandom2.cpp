//__________________________________________________________________________________________
//
//	Copyright (C) 2003-2005 by Thurs. All rights reserved.
//
//	LYggRandom2
//
//	Magnus EH Pedersen
//
//__________________________________________________________________________________________

#include "LYggRandom2.h"
#include <math.h>

namespace Yggdrasil
{

const long		IM1 = 2147483563;
const long		IM2 = 2147483399;
const long		IMM1 = IM1-1;
const long		IA1 = 40014;
const long		IA2 = 40692;
const long		IQ1 = 53668;
const long		IQ2 = 52774;
const long		IR1 = 12211;
const long		IR2 = 3791;
const long		NDIV = 1 + IMM1/LYggRandom2::NTAB;

//__________________________________________________________________________________________
LYggRandom2::LYggRandom2		(long seed) :
mIdum(seed),
mIdum2(123456789),
mIy(0)
{
	// Generate initial shuffle table
	Initialize(seed);
}
//__________________________________________________________________________________________
void
LYggRandom2::Initialize			(long seed)
{
	int j;

	LYggRandom::Initialize(seed);

	mIdum = seed;

	// Ensure initial (i.e. seed) mIdum>0
	if (mIdum == 0)
		mIdum = 1;
	else if (mIdum < 0)
		mIdum = -mIdum;

	mIdum2 = mIdum;

	// Generate the shuffle table (after 8 warm-ups).
	for (j=0; j<8; j++)
		DoRand1();

	for (j=NTAB-1;j>=0;j--)
	{
		DoRand1();
		mIv[j] = mIdum;
	}

	mIy=mIv[0];
}
//__________________________________________________________________________________________
void
LYggRandom2::DoRand1			()
{
	long k=mIdum/IQ1;
	mIdum=IA1*(mIdum-k*IQ1)-IR1*k;		// Compute idum=(IA1*idum) % IM1 without over-
	if (mIdum < 0) mIdum += IM1;		// flows by Schrage's method.
}
//__________________________________________________________________________________________
void
LYggRandom2::DoRand2			()
{
	long k=mIdum2/IQ2;
	mIdum2=IA2*(mIdum2-k*IQ2)-IR2*k;	// Compute idum2=(IA2*idum2) % IM2 without over-
	if (mIdum2 < 0) mIdum2 += IM2;		// flows by Schrage's method.
}
//__________________________________________________________________________________________
long
LYggRandom2::Rand				()
{
	DoRand1();
	DoRand2();

	{
		int j=mIy/NDIV; assert(j>=0 && j<NTAB);		// Will be in the range 0..NTAB-1.
		mIy=mIv[j]-mIdum2;							// Here idum is shuffled, idum and idum2 are
		mIv[j] = mIdum;								// combined to generate output.
		if (mIy < 1) mIy += IMM1;
	}

	return mIy;
}
//__________________________________________________________________________________________
} //end namespace Yggdrasil
