//....................................................................................................................................................................................
//
//	Copyright (C) 2003-2005 by Thurs. All rights reserved.
//
//	LYggRandom2
//
//	Taken from Numerical Recipes in C, chapter 7.1
//	
//	Long period (> 2 * 10^18) random number generator of L'Ecuyer with Bays-Durham shuffle
//	and added safeguards. Returns a uniform random deviate.
//
//	Magnus EH Pedersen
//
//....................................................................................................................................................................................

#pragma once

#include "LYggRandom.h"

namespace Yggdrasil
{

//....................................................................................................................................................................................
class	LYggRandom2 : public LYggRandom
{
public:
	LYggRandom2							(long seed=1);

	virtual void			Initialize	(long seed=1);

	// Generates and returns a new pseudo-random value.
	virtual long			Rand		();

private:
	inline void				DoRand1		();

	inline void				DoRand2		();

public:
	static const long	NTAB=32;

private:
	long				mIdum;				// Iterative variable.
	long				mIdum2;
	long				mIy;
	long				mIv[NTAB];
};
} //end namespace Yggdrasil
