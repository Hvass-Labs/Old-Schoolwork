// ra_exam_problem2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "random.h"
#include <cmath>
#include <cassert>

Yggdrasil::LYggRandom2 gRandom(1234567);

typedef int T;

T			*gX = 0, *gY = 0;				// The two multisets X and Y to be compared.
int			gMaxWordValue;					// Max value a word in X and Y can take.
int			gN;								// Number of elements in X and Y.
int			gNumEqual;						// The number of elements in X and Y that are equal.
int			gFingerprintType;				// Polynomial or congruence?
int			gNumIterations;					// Number of independent trials to perform.

const int	kPrimeCount = 45;				// Max number of primes for our simple generator.
int			gPrimeCount = 0;				// How many distinct primes have been generated.

enum
{
	ePolynomial = 1,
	eCongruence
};

void GetRandomSeed()
{
	long seed;

	std::cout << "Random seed: ";
	std::cin >> seed;

	gRandom.Initialize(seed);
}

void GetParameters()
{
	std::cout << "Number of elements in multisets X and Y (denoted n): ";
	std::cin >> gN; assert(gN>=1);

	std::cout << "How many of these should be equal in X and Y: ";
	std::cin >> gNumEqual; assert(gNumEqual>=0 && gNumEqual<=gN);

	std::cout << "Words in X and Y should be less than what value (denoted 2^C): ";
	std::cin >> gMaxWordValue; assert(gMaxWordValue>=2);

	std::cout << "What kind of fingerprint type (" << ePolynomial << " for polynomial, " << eCongruence << " for congruence): ";
	std::cin >> gFingerprintType;

	if (gFingerprintType == ePolynomial)
	{
		std::cout << "How many iterations/trials: ";
		std::cin >> gNumIterations;
	}
	else
	{
		gNumIterations = kPrimeCount;
	}
}

// Allocate and randomly initialize multisets.
void AllocateMultisets()
{
	gX = new T[gN];
	gY = new T[gN];

	int i;

	for (i = 0; i<gNumEqual; i++)
	{
		gX[i] = gRandom.RandIndex(gMaxWordValue);
		gY[i] = gX[i];
	}

	for (i = gNumEqual; i<gN; i++)
	{
		gX[i] = gRandom.RandIndex(gMaxWordValue);
		gY[i] = gMaxWordValue - gX[i] - 1;
	}
}

void DeleteMultisets()
{
	delete [] gX;
	delete [] gY;
}

// Return a prime. This method can only return 45 distinct.
int GetPrime()
{
	int prime = 36 * gPrimeCount*gPrimeCount - 810 * gPrimeCount + 2753;

	gPrimeCount++;
	gPrimeCount %= kPrimeCount;

	return prime;
}

T MultisetPolynomial(T *X, T z, int n)
{
	T prod = 1;

	for (int i=0; i<n; i++)
	{
		prod *= (z - X[i]);
	}

	return prod;
}

// Return x^k mod p
T RepeatedSquaring(const int x, const T k, const T p)
{
	T retVal;

	if (k == 0)
	{
		retVal = 1;
	}
	else if (k % 2 == 1)
	{
		retVal = (x * RepeatedSquaring(x, k-1, p)) % p;
	}
	else
	{
		T t = RepeatedSquaring(x, k>>1, p) % p;
		retVal = (t * t) % p;
	}

	return retVal;
}

T MultisetCongruence(T *X, int n, int p)
{
	int m = n+1;
	T sum = 0;

	for (int i=0; i<n; i++)
	{
		sum += RepeatedSquaring(m % p, X[i], p);
		sum %= p;
	}

	return sum;
}

bool MultisetEqualityPolynomial()
{
	T z = gRandom.RandIndex(gMaxWordValue);
	T f = MultisetPolynomial(gX, z, gN);
	T g = MultisetPolynomial(gY, z, gN);

	return f == g;
}

bool MultisetEqualityCongruence()
{
	T p = GetPrime();
	T FpX = MultisetCongruence(gX, gN, p);
	T FpY = MultisetCongruence(gY, gN, p);

	return  FpX == FpY;
}

bool MultisetEquality()
{
	bool retVal;

	switch (gFingerprintType)
	{
	case ePolynomial:	retVal = MultisetEqualityPolynomial(); break;
	case eCongruence:
	default:			retVal = MultisetEqualityCongruence();
	}

	return retVal;
}

int _tmain(int argc, _TCHAR* argv[])
{
	std::cout << "Randomized Algorithms - Takehome Exam 2005, Problem 4.\nMagnus Pedersen (u971055@daimi.au.dk)" << std::endl << std::endl;

	GetRandomSeed();
	GetParameters();
	AllocateMultisets();

	int numTrue = 0;

	for (int i=0; i<gNumIterations; i++)
	{
		if (MultisetEquality())
			numTrue++;
	}

	DeleteMultisets();

	std::cout << "A total of " << gNumIterations << " iterations were performed, of which " << numTrue << " had equal fingerprints." << std::endl;

	return 0;
}

