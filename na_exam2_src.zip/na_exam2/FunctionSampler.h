//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	FunctionSampler
//
//....................................................................................................................................................................................

#pragma once

#include <cassert>
#include <cfloat>

namespace NA
{

//....................................................................................................................................................................................

	// Used below for weeding out bad floating point numbers, by setting them to zero.
	template <class T>
	T ValidFloat(T x)
	{
		return x;
	}

	template <>
	double ValidFloat(double x)
	{
		return (_isnan(x) || _fpclass(x) == _FPCLASS_PINF || _fpclass(x) == _FPCLASS_NINF) ? (0) : (x);
	}

	template <>
	float ValidFloat(float x)
	{
		return (float) ValidFloat<double>(x);
	}

//....................................................................................................................................................................................

	// Fill the given array with samples from f, as follows: array[i] = f(a+(2*i-1)*h), for i=1,..,n
	// Replaces invalid samples with zeros.
	template <class T>
	void FunctionSampler(T *array, T a, T h, unsigned int n, T (*f)(T))
	{
		assert(array && n>0);
		assert(f);

		for (int i=0; i<n; i++)
		{
			// Remember that C++ indexes arrays from 0 to n-1, so we need to adjust for this.
			int j = i+1;
			T y = f(a+(2*j-1)*h);
			array[i] = ValidFloat(y);
		}
	}

//....................................................................................................................................................................................
} //end namespace NA
