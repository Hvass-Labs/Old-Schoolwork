//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LRombergMidpoint
//
//....................................................................................................................................................................................

#pragma once

#include "LRichardsonExtrapolation.h"
#include "FunctionSampler.h"
#include "BinarySummation.h"
#include <assert.h>

namespace NA
{

//....................................................................................................................................................................................
template <class T>
class	LRombergMidpoint : public LRichardsonExtrapolation<T>
{
public:
	LRombergMidpoint							() : LRichardsonExtrapolation<T>()
	{
	}

protected:
	// Compute n integrals of f and place them in the array for 'estimates'.
	virtual void		ComputeEstimates		(T *estimates, T a, T b, int n, T (*f)(T))
	{
		assert(estimates && n>0);
		assert(a < b);
		assert(f);

		// Allocate an array that is big enough to hold samples for all integrals,
		// that is, allocate enough samples for the integral with finest resolution.
		T *samples = new T[1<<(n-1)];

		// Initialize the step-size.
		T h = b-a;

		// Compute the midpoint integrals, by doubling the number of samples in each
		// iteration, and thus halving the step-size for the value sampling.
		for (int i=0; i<n; i++)
		{
			int numSamples = 1<<i;	// numSamples = pow(2, i)
			T h2 = h;				// Store the step-size.

			// Halve the step-size for the sampling.
			h *= 0.5;

			// Compute the samples of f.
			FunctionSampler(samples, a, h, numSamples, f);

			// Sum the samples, and compute the integral.
			estimates[i] = h2*ArrayOps::BinarySummation<T>(samples, numSamples);
		}

		// Delete the locally used array for the samples.
		delete [] samples;
	}
};
} //end namespace NA
