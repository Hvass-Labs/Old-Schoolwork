//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	BinarySummation
//
//....................................................................................................................................................................................

#pragma once

#include <cassert>

namespace ArrayOps
{

//....................................................................................................................................................................................

	// Compute the sum of the elements in the given array.
	// Reduces the error for summing floating point elements.
	// Assume n is a power of 2 (n=1 is allowed).
	// Destroys the elements in the array (but does not delete it).
	template <class T>
	T BinarySummation(T *array, int n)
	{
		assert(array && n>0);

		int k=n;

		while (k>1)
		{
			// Ensure n is a power of 2.
			assert(k%2 == 0);

			for (int i=0, j=0; i<k; i+=2, j++)
			{
				T t = array[i] + array[i+1];
				array[j] = t;
			}

			k >>= 1; // k /= 2
		}

		return array[0];
	}

//....................................................................................................................................................................................
} //end namespace ArrayOps
