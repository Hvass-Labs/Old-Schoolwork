//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LRombergTrapezoid
//
//....................................................................................................................................................................................

#pragma once

#include "LRichardsonExtrapolation.h"
#include "FunctionSampler.h"
#include "BinarySummation.h"
#include <assert.h>

namespace NA
{

//....................................................................................................................................................................................
template <class T>
class	LRombergTrapezoid : public LRichardsonExtrapolation<T>
{
public:
	LRombergTrapezoid							() : LRichardsonExtrapolation<T>()
	{
	}

protected:
	// Compute n integrals of f and place them in the array for 'estimates'.
	virtual void		ComputeEstimates		(T *estimates, T a, T b, int n, T (*f)(T))
	{
		assert(estimates && n>0);
		assert(a < b);
		assert(f);

		// Allocate an array that is big enough to hold samples for all integrals,
		// that is, allocate enough samples for the integral with finest resolution.
		T *samples = new T[1<<(n-2)];

		// Initialize the step-size.
		T h = b-a;

		// Compute the first trapezoid integral.
		estimates[0] = 0.5*h*(ValidFloat(f(a)) + ValidFloat(f(b)));

		// Compute the rest of the trapezoid integrals, by doubling the number of samples,
		// and thus halving the step-size for the value sampling.
		for (int i=1; i<n; i++)
		{
			int numSamples = 1<<(i-1); // numSamples = pow(2, i-1)

			// Halve the step-size for the sampling.
			h *= 0.5;

			// Compute the samples of f.
			FunctionSampler(samples, a, h, numSamples, f);

			// Sum the samples, and compute the integral.
			estimates[i] = 0.5 * estimates[i-1] + h*ArrayOps::BinarySummation<T>(samples, numSamples);
		}

		// Delete the locally used array for the samples.
		delete [] samples;
	}
};
} //end namespace NA
