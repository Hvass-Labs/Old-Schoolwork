//....................................................................................................................................................................................
//
//	Copyright (C) 2004, Magnus EH Pedersen
//
//	LRichardsonExtrapolation
//
//....................................................................................................................................................................................

#pragma once

#include <iostream>
#include <cassert>

namespace NA
{

//....................................................................................................................................................................................
template <class T>
class	LRichardsonExtrapolation
{
public:
	LRichardsonExtrapolation					() {}

	virtual ~LRichardsonExtrapolation			() {}

	void				Extrapolate				(T a, T b, const int n, T (*f)(T))
	{
		T *estimates = new T[n];
		T *estimates2 = new T[n];		// One more than needed, easens indexing.
		T *differences = new T[n];		// One more than needed.
		T *quotients = new T[n];		// Two more than needed.

		// Call specialization to get initial estimates.
		ComputeEstimates(estimates, a, b, n, f);

		for (int m=1; m<n; m++)
		{
			int k;

			// Compute differences.
			for (k=m; k<n; k++)
			{
				differences[k] = estimates[k] - estimates[k-1];
			}

			// Compute quotients.
			for (k=2; k<n; k++)
			{
				quotients[k] = differences[k-1] / differences[k];
			}

			Output(m, n, estimates, differences, quotients);

			// Get corrective factor from user.
			T factor;
			std::cout << "Enter factor: ";
			std::cin >> factor;

			// Compute next series of estimates/approximations.
			for (k=m; k<n; k++)
			{
				estimates2[k] = estimates[k] + (estimates[k] - estimates[k-1]) / (factor-1);
			}

			// Swap arrays.
			std::swap(estimates, estimates2);
		}

		Output(n, n, estimates, differences, quotients);

		delete [] estimates;
		delete [] estimates2;
		delete [] differences;
		delete [] quotients;
	}

private:
	void				Output					(int m, int n, T* estimates, T* differences, T* quotients)
	{
		// Output description.
		std::cout << "k\tN(f,h)\tdiff\tquotient\n";

		// Output estimates, errors and quotients.
		for (int k=m-1; k<n; k++)
		{
			// Set precision for display of floating point numbers.
			std::cout << setprecision(25);

			std::cout << k << "\t" << estimates[k];

			// Display difference.
			if (k>=m)
			{
				std::cout << "\t" << differences[k];

				// Display quotient.
				if (k>m)
				{
					std::cout << setprecision(5);
					std::cout << "\t" << quotients[k];
				}
			}

			// Newline and flush.
			std::cout << std::endl;
		}
	}

protected:
	// Compute estimates into the given array.
	virtual void		ComputeEstimates		(T *estimates, T a, T b, int n, T (*f)(T)) = 0;
};
} //end namespace NA
