// na_exam2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <cmath>
#include <cassert>
#include <iomanip>

#include "LRombergTrapezoid.h"
#include "LRombergMidpoint.h"

using namespace std;

enum
{
	eTrapezoid = 1,
	eMidpoint
};

typedef double FTYPE;
typedef FTYPE (*FPTR)(FTYPE);

int				gRomberg;			// Use trapezoid or midpoint.
int				gFunction;			// Which function to integrate.
unsigned int	gNumIterations;		// Number of Romberg iterations.
FTYPE			gA, gB;				// Endpoints for integration.

FTYPE FunctionI(FTYPE x) { return x; }

FTYPE Function1(FTYPE x) { return sin(x); }

FTYPE Function2(FTYPE x) { return pow(x, 1.0/3.0); }

FTYPE Function3(FTYPE x) { return sqrt(x)*log(x); }

FTYPE Function4(FTYPE x)
{
	FTYPE c = cos(x*x);
	return exp(-x)*c*c;
}

FTYPE Function5(FTYPE x) { return 1.0/sqrt(1-x*x); }

void InputFunction()
{
	cout << endl;
	cout << "1: f(x) = sin(x)" << endl;
	cout << "2: f(x) = pow(x, 1.0/3.0)" << endl;
	cout << "3: f(x) = sqrt(x)*log(x)" << endl;
	cout << "4: f(x) = exp(-x)*cos(x*x)*cos(x*x)" << endl;
	cout << "5: f(x) = 1.0/sqrt(1-x*x)" << endl;
	cout << "Enter function to integrate: ";
	cin >> gFunction; assert(gFunction>=1 && gFunction<=5);

	cout << "Enter left endpoint a: ";
	cin >> gA;
	cout << "Enter right endpoint b: ";
	cin >> gB;
}

void InputRomberg()
{
	cout << eTrapezoid << ": Trapezoid" << endl;
	cout << eMidpoint << ": Midpoint" << endl;
	cout << "Enter type of Romberg integration: ";
	cin >> gRomberg; assert(gRomberg == eTrapezoid || gRomberg == eMidpoint);
	cout << "Number of iterations: ";
	cin >> gNumIterations;
}

FPTR
GetFunction()
{
	switch (gFunction)
	{
	case 1: return *Function1;
	case 2: return *Function2;
	case 3: return *Function3;
	case 4: return *Function4;
	case 5:
	default: return *Function5;
	}
}

NA::LRichardsonExtrapolation<FTYPE>*
GetRomberg()
{
	switch (gRomberg)
	{
	case eTrapezoid:	return new NA::LRombergTrapezoid<FTYPE>();
	case eMidpoint:
	default:			return new NA::LRombergMidpoint<FTYPE>();
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	cout << "Romberg Integration, 2004-2005 Magnus Erik Hvass Pedersen (u971055@daimi.au.dk)\n\n";
	InputRomberg();
	InputFunction();

	NA::LRichardsonExtrapolation<FTYPE>* romberg = GetRomberg();
	
	romberg->Extrapolate(gA, gB, gNumIterations, GetFunction());

	delete romberg;

	return 0;
}
